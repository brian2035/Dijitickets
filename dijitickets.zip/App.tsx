
import React, { useState, useEffect } from 'react';
import { HashRouter as Router, Routes, Route, Navigate, Link } from 'react-router-dom';
import { User, UserRole } from './types';
import { authService } from './services/authService';
import { seedData } from './db';
import { Facebook, Twitter, Instagram, Music2 } from 'lucide-react';

import Navbar from './components/Navbar';
import Home from './pages/Home';
import EventDetails from './pages/EventDetails';
import Dashboard from './pages/Dashboard';
import OrganizerDashboard from './pages/OrganizerDashboard';
import CreateEvent from './pages/CreateEvent';
import Login from './pages/Login';
import Logo from './components/Logo';
import DijiExperience from './pages/DijiExperience';
import WithdrawalRequest from './pages/WithdrawalRequest';
import AdminLogin from './pages/AdminLogin';
import AdminPanel from './pages/AdminPanel';

// Info Pages
import HowItWorks from './pages/HowItWorks';
import Pricing from './pages/Pricing';
import MPesaInfo from './pages/MPesaInfo';
import ContactUs from './pages/ContactUs';
import PrivacyPolicy from './pages/PrivacyPolicy';
import TermsOfService from './pages/TermsOfService';

const App: React.FC = () => {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    seedData();
    const currentUser = authService.getCurrentUser();
    setUser(currentUser);
    setLoading(false);
  }, []);

  const handleLoginSuccess = (userData: User) => {
    setUser(userData);
  };

  const handleLogout = () => {
    authService.logout();
    setUser(null);
  };

  if (loading) return (
    <div className="min-h-screen flex items-center justify-center bg-white">
      <div className="animate-pulse flex flex-col items-center">
        <Logo className="mb-6 drop-shadow-xl" />
        <div className="flex space-x-2">
           <div className="h-1.5 w-1.5 bg-red-600 rounded-full animate-bounce [animation-delay:-0.3s]"></div>
           <div className="h-1.5 w-1.5 bg-red-600 rounded-full animate-bounce [animation-delay:-0.15s]"></div>
           <div className="h-1.5 w-1.5 bg-red-600 rounded-full animate-bounce"></div>
        </div>
      </div>
    </div>
  );

  return (
    <Router>
      <div className="min-h-screen flex flex-col font-['Bricolage_Grotesque']">
        <Navbar user={user} onLogout={handleLogout} />
        <main className="flex-grow">
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/event/:id" element={<EventDetails />} />
            <Route path="/experience" element={<DijiExperience />} />
            <Route 
              path="/login" 
              element={user ? <Navigate to="/" /> : <Login onLoginSuccess={handleLoginSuccess} />} 
            />
            <Route 
              path="/signup" 
              element={user ? <Navigate to="/" /> : <Login onLoginSuccess={handleLoginSuccess} />} 
            />
            
            {/* Hidden Admin Entry Routes */}
            <Route 
              path="/internal/system-access-node" 
              element={user?.role === UserRole.ADMIN ? <Navigate to="/internal/system-node-7412" /> : <AdminLogin onLoginSuccess={handleLoginSuccess} />} 
            />
            <Route 
              path="/internal/system-node-7412" 
              element={user?.role === UserRole.ADMIN ? <AdminPanel /> : <Navigate to="/internal/system-access-node" />} 
            />
            
            {/* Protected Routes */}
            <Route 
              path="/dashboard" 
              element={user ? <Dashboard /> : <Navigate to="/login" />} 
            />
            
            <Route 
              path="/organizer" 
              element={user?.role === UserRole.ORGANIZER ? <OrganizerDashboard /> : <Navigate to="/" />} 
            />
            
            <Route 
              path="/organizer/withdraw" 
              element={user?.role === UserRole.ORGANIZER ? <WithdrawalRequest /> : <Navigate to="/" />} 
            />

            <Route 
              path="/create-event" 
              element={user?.role === UserRole.ORGANIZER ? <CreateEvent /> : <Navigate to="/" />} 
            />
            <Route 
              path="/edit-event/:id" 
              element={user?.role === UserRole.ORGANIZER ? <CreateEvent /> : <Navigate to="/" />} 
            />

            {/* Info Pages */}
            <Route path="/how-it-works" element={<HowItWorks />} />
            <Route path="/pricing" element={<Pricing />} />
            <Route path="/mpesa" element={<MPesaInfo />} />
            <Route path="/contact" element={<ContactUs />} />
            <Route path="/privacy" element={<PrivacyPolicy />} />
            <Route path="/terms" element={<TermsOfService />} />
          </Routes>
        </main>
        
        <footer className="bg-gray-900 text-white py-20">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-16 mb-16">
              <div className="md:col-span-2">
                <Logo variant="white" className="mb-8 opacity-90" />
                <p className="text-gray-400 max-w-sm leading-relaxed text-lg">
                  The premier digital ticketing solution for the vibrant events landscape of Kenya. Secure, fast, and built for everyone.
                </p>
              </div>
              <div>
                <h4 className="text-xs font-black uppercase tracking-widest text-gray-500 mb-6">Platform</h4>
                <ul className="space-y-4 text-gray-300 font-bold text-sm">
                  <li><Link to="/how-it-works" className="hover:text-red-500 transition-colors">How it Works</Link></li>
                  <li><Link to="/pricing" className="hover:text-red-500 transition-colors">Pricing</Link></li>
                  <li><Link to="/mpesa" className="hover:text-red-500 transition-colors">M-Pesa Integration</Link></li>
                </ul>
              </div>
              <div>
                <h4 className="text-xs font-black uppercase tracking-widest text-gray-500 mb-6">Support</h4>
                <ul className="space-y-4 text-gray-300 font-bold text-sm">
                  <li><Link to="/contact" className="hover:text-red-500 transition-colors">Contact Us</Link></li>
                  <li><Link to="/privacy" className="hover:text-red-500 transition-colors">Privacy Policy</Link></li>
                  <li><Link to="/terms" className="hover:text-red-500 transition-colors">Terms of Service</Link></li>
                </ul>
              </div>
            </div>
            <div className="pt-12 border-t border-gray-800 flex flex-col md:flex-row items-center justify-between gap-6 text-gray-500 text-[10px] font-black uppercase tracking-widest">
              <p>© 2026 Dijitickets. All Rights Reserved.</p>
              <div className="flex items-center gap-8">
                <span className="lowercase">Nairobi,Kenya</span>
                <div className="flex gap-5">
                  <a href="https://x.com/dijitickets?s=21" target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-white transition-colors" title="Twitter">
                    <Twitter size={18} />
                  </a>
                  <a href="https://www.instagram.com/dijitickets?igsh=MXBsYnRzeWp1NmZjbQ==" target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-white transition-colors" title="Instagram">
                    <Instagram size={18} />
                  </a>
                  <a href="https://www.facebook.com/share/1AfAGttDVn/?mibextid=wwXIfr" target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-white transition-colors" title="Facebook">
                    <Facebook size={18} />
                  </a>
                  <a href="https://www.tiktok.com/@dijitickets?_r=1&_t=ZS-93hNIz249xp" target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-white transition-colors" title="TikTok">
                    <Music2 size={18} />
                  </a>
                </div>
              </div>
            </div>
          </div>
        </footer>
      </div>
    </Router>
  );
};

export default App;
