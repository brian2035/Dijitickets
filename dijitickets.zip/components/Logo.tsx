
import React from 'react';

interface LogoProps {
  className?: string;
  variant?: 'default' | 'white';
}

const Logo: React.FC<LogoProps> = ({ className = "", variant = 'default' }) => {
  const textColor = variant === 'white' ? 'text-white' : 'text-red-600';

  return (
    <div className={`${className} flex items-center gap-x-2.5 md:gap-x-3 select-none shrink-0 group`}>
      <div className="relative flex items-center justify-center transition-all duration-500 group-hover:scale-105 h-8 w-8 md:h-10 md:w-10 shrink-0">
        <img 
          src="https://i.ibb.co/WpzPhHVJ/DIJITICKETS-LOGO.png" 
          alt="Dijitickets Icon" 
          className="w-full h-full object-contain drop-shadow-md"
        />
      </div>
      <span 
        className={`${textColor} font-[800] tracking-tighter text-2xl md:text-3xl leading-none flex items-center pt-0.5`}
        style={{ 
          fontFamily: "'Bricolage Grotesque', sans-serif",
          textShadow: variant === 'white' ? '0 2px 8px rgba(0,0,0,0.15)' : 'none'
        }}
      >
        Dijitickets
      </span>
    </div>
  );
};

export default Logo;
