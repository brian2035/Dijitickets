
import React, { useState, useRef } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { LogOut, LayoutDashboard, PlusCircle, Compass, ShieldCheck } from 'lucide-react';
import { User, UserRole } from '../types';
import Logo from './Logo';
import NotificationMenu from './NotificationMenu';

interface NavbarProps {
  user: User | null;
  onLogout: () => void;
}

const Navbar: React.FC<NavbarProps> = ({ user, onLogout }) => {
  const navigate = useNavigate();
  const [clickCount, setClickCount] = useState(0);
  // Fix: Use ReturnType<typeof setTimeout> instead of NodeJS.Timeout to resolve 'Cannot find namespace NodeJS' error in browser environments
  const clickTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  // Hidden Secret: Click logo 5 times to jump to Admin Access
  const handleLogoClick = () => {
    const newCount = clickCount + 1;
    setClickCount(newCount);

    if (clickTimerRef.current) clearTimeout(clickTimerRef.current);

    if (newCount === 5) {
      setClickCount(0);
      navigate('/internal/system-access-node');
    } else {
      clickTimerRef.current = setTimeout(() => {
        setClickCount(0);
      }, 3000);
    }
  };

  return (
    <nav className="bg-white border-b border-gray-200 sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-20 gap-x-2 md:gap-x-4">
          <div className="flex items-center shrink-0 min-w-0 mr-2 cursor-pointer select-none" onClick={handleLogoClick}>
            <Logo className="hover:opacity-90 transition-opacity" />
          </div>

          <div className="flex items-center space-x-2 md:space-x-4 shrink-0">
            {user ? (
              <div className="flex items-center space-x-2 md:space-x-6">
                {user.role === UserRole.ADMIN && (
                   <Link to="/internal/system-node-7412" className="text-red-600 hover:text-red-700 flex items-center space-x-1 text-sm font-black uppercase tracking-widest transition-colors p-1" title="Admin Portal">
                    <ShieldCheck className="h-5 w-5 md:h-4 md:w-4" />
                    <span className="hidden sm:inline">Admin</span>
                  </Link>
                )}

                {user.role === UserRole.ORGANIZER && (
                  <>
                    <Link to="/organizer" className="text-gray-600 hover:text-red-600 flex items-center space-x-1 text-sm font-medium transition-colors p-1" title="Org Dashboard">
                      <LayoutDashboard className="h-5 w-5 md:h-4 md:w-4" />
                      <span className="hidden sm:inline">Dashboard</span>
                    </Link>
                    <Link to="/create-event" className="bg-red-600 text-white p-2 md:px-4 md:py-2 rounded-full hover:bg-red-700 flex items-center md:space-x-2 text-sm font-medium transition-all shadow-md shadow-red-100">
                      <PlusCircle className="h-5 w-5 md:h-4 md:w-4" />
                      <span className="hidden sm:inline">Create Event</span>
                    </Link>
                  </>
                )}

                {/* Notifications Menu */}
                <NotificationMenu userId={user.id} />

                <div className="flex items-center space-x-2 md:space-x-3 border-l pl-2 md:pl-6 border-gray-200">
                  <div className="flex flex-col items-end hidden md:flex">
                    <span className="text-sm font-bold text-gray-900 truncate max-w-[120px]">{user.name}</span>
                    <span className="text-[10px] font-black text-gray-400 uppercase tracking-widest">{user.role}</span>
                  </div>
                  <button 
                    onClick={onLogout}
                    className="p-2 text-gray-400 hover:text-red-600 transition-colors"
                    title="Logout"
                  >
                    <LogOut className="h-5 w-5" />
                  </button>
                </div>
              </div>
            ) : (
              <div className="flex items-center space-x-1 md:space-x-4">
                <Link to="/login" className="text-gray-600 hover:text-gray-900 text-xs md:text-sm font-bold px-2 py-1">Organizer Login</Link>
                <Link to="/signup" className="bg-red-600 text-white px-4 md:px-6 py-2 rounded-full hover:bg-red-700 text-xs md:text-sm font-bold transition-all shadow-lg shadow-red-100 whitespace-nowrap">Start Hosting</Link>
              </div>
            )}
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
