
import React, { useState, useEffect, useRef } from 'react';
import { Bell, Check, X, Trash2, Info, CircleCheck, AlertTriangle, AlertCircle } from 'lucide-react';
import { Link } from 'react-router-dom';
import { Notification } from '../types';
import { notificationService } from '../services/notificationService';

interface NotificationMenuProps {
  userId: string;
}

const NotificationMenu: React.FC<NotificationMenuProps> = ({ userId }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const menuRef = useRef<HTMLDivElement>(null);

  const fetchNotifications = () => {
    setNotifications(notificationService.getByUser(userId));
  };

  useEffect(() => {
    fetchNotifications();
    const interval = setInterval(fetchNotifications, 5000); // Polling for demo purposes
    return () => clearInterval(interval);
  }, [userId]);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };
    if (isOpen) {
      document.addEventListener('mousedown', handleClickOutside);
    }
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, [isOpen]);

  const unreadCount = notifications.filter(n => !n.isRead).length;

  const handleMarkAsRead = (id: string) => {
    notificationService.markAsRead(id);
    fetchNotifications();
  };

  const handleMarkAllAsRead = () => {
    notificationService.markAllAsRead(userId);
    fetchNotifications();
  };

  const handleClearAll = () => {
    notificationService.clearAll(userId);
    fetchNotifications();
  };

  const getIcon = (type: Notification['type']) => {
    switch (type) {
      case 'success': return <CircleCheck className="h-5 w-5 text-green-500" />;
      case 'warning': return <AlertTriangle className="h-5 w-5 text-yellow-500" />;
      case 'error': return <AlertCircle className="h-5 w-5 text-red-500" />;
      default: return <Info className="h-5 w-5 text-blue-500" />;
    }
  };

  return (
    <div className="relative md:static lg:relative" ref={menuRef}>
      <button 
        onClick={() => setIsOpen(!isOpen)}
        className="relative p-2 text-gray-400 hover:text-red-600 transition-colors bg-gray-50 rounded-full"
      >
        <Bell className="h-6 w-6" />
        {unreadCount > 0 && (
          <span className="absolute top-0 right-0 bg-red-600 text-white text-[10px] font-black w-5 h-5 flex items-center justify-center rounded-full border-2 border-white animate-in zoom-in">
            {unreadCount > 9 ? '9+' : unreadCount}
          </span>
        )}
      </button>

      {isOpen && (
        <>
          {/* Backdrop for mobile */}
          <div className="fixed inset-0 bg-black/5 md:hidden z-[90]" onClick={() => setIsOpen(false)} />
          
          <div className="fixed inset-x-4 top-24 md:absolute md:inset-auto md:right-0 md:top-full md:mt-4 w-auto md:w-96 bg-white rounded-[2rem] shadow-2xl border border-gray-100 overflow-hidden z-[100] animate-in slide-in-from-top-4 duration-300">
            <div className="p-6 border-b border-gray-100 flex items-center justify-between bg-gray-50/50">
              <div>
                <h3 className="text-lg font-black text-gray-900 tracking-tight">Notifications</h3>
                <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest">{unreadCount} unread messages</p>
              </div>
              <div className="flex gap-2">
                <button 
                  onClick={handleMarkAllAsRead}
                  className="p-2 bg-white text-gray-400 hover:text-green-600 rounded-xl border border-gray-200 transition-all"
                  title="Mark all as read"
                >
                  <Check className="h-4 w-4" />
                </button>
                <button 
                  onClick={handleClearAll}
                  className="p-2 bg-white text-gray-400 hover:text-red-600 rounded-xl border border-gray-200 transition-all"
                  title="Clear all"
                >
                  <Trash2 className="h-4 w-4" />
                </button>
              </div>
            </div>

            <div className="max-h-[350px] md:max-h-[400px] overflow-y-auto no-scrollbar">
              {notifications.length > 0 ? (
                <div className="divide-y divide-gray-50">
                  {notifications.map(n => (
                    <div 
                      key={n.id} 
                      className={`p-5 hover:bg-gray-50 transition-colors group relative ${!n.isRead ? 'bg-red-50/30' : ''}`}
                      onClick={() => handleMarkAsRead(n.id)}
                    >
                      <div className="flex gap-4">
                        <div className="shrink-0 mt-1">
                          {getIcon(n.type)}
                        </div>
                        <div className="flex-1">
                          <Link 
                            to={n.link || '#'} 
                            className="block"
                            onClick={() => setIsOpen(false)}
                          >
                            <h4 className="text-sm font-bold text-gray-900 mb-1">{n.title}</h4>
                            <p className="text-xs text-gray-500 leading-relaxed font-medium">{n.message}</p>
                            <span className="text-[9px] font-black text-gray-300 uppercase mt-2 block tracking-widest">
                              {new Date(n.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                            </span>
                          </Link>
                        </div>
                        {!n.isRead && (
                          <div className="shrink-0">
                            <div className="w-2 h-2 bg-red-600 rounded-full"></div>
                          </div>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="py-20 text-center">
                  <Bell className="h-12 w-12 text-gray-100 mx-auto mb-4" />
                  <p className="text-sm font-bold text-gray-400">All caught up!</p>
                </div>
              )}
            </div>
            
            <div className="p-4 bg-gray-50 text-center border-t border-gray-100">
               <button 
                onClick={() => setIsOpen(false)}
                className="text-xs font-black text-gray-500 hover:text-red-600 uppercase tracking-widest"
               >
                 Close Menu
               </button>
            </div>
          </div>
        </>
      )}
    </div>
  );
};

export default NotificationMenu;
