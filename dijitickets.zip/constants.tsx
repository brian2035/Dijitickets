
export const COLORS = {
  primary: '#b40000', 
  secondary: '#111827',
  accent: '#e60000',
};

export const CATEGORIES = [
  'Concert',
  'Workshop',
  'Networking',
  'Festival',
  'Theatre',
  'Sports',
  'Conference'
];

export const formatCurrency = (amount: number) => {
  return new Intl.NumberFormat('en-KE', {
    style: 'currency',
    currency: 'KES',
    minimumFractionDigits: 0,
  }).format(amount);
};
