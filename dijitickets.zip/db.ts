
// This file is now primarily for initial client-side setup or local fallbacks.
// Production data is handled by the Express Backend.
import { User, Event, Ticket, Notification, AdminActivity } from './types';

// Updated to export DB with local storage fallbacks for system components
export const DB = {
  getTickets: (): Ticket[] => JSON.parse(localStorage.getItem('dijitickets_tickets') || '[]'),
  saveTickets: (tickets: Ticket[]) => localStorage.setItem('dijitickets_tickets', JSON.stringify(tickets)),
  getNotifications: (): Notification[] => JSON.parse(localStorage.getItem('dijitickets_notifications') || '[]'),
  saveNotifications: (notifications: Notification[]) => localStorage.setItem('dijitickets_notifications', JSON.stringify(notifications)),
  getActivityLogs: (): AdminActivity[] => JSON.parse(localStorage.getItem('dijitickets_logs') || '[]'),
  saveActivityLogs: (logs: AdminActivity[]) => localStorage.setItem('dijitickets_logs', JSON.stringify(logs)),
  getUsers: (): User[] => JSON.parse(localStorage.getItem('dijitickets_users') || '[]'),
  saveUsers: (users: User[]) => localStorage.setItem('dijitickets_users', JSON.stringify(users)),
  getEvents: (): Event[] => JSON.parse(localStorage.getItem('dijitickets_events') || '[]'),
  saveEvents: (events: Event[]) => localStorage.setItem('dijitickets_events', JSON.stringify(events)),
};

export const seedData = () => {
  console.log("Dijitickets client-side initialized. Connecting to backend...");
};
