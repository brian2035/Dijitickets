
import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { Lock, ShieldCheck, ArrowRight, ShieldAlert, Key, Terminal, Cpu, Smartphone, ShieldEllipsis, Fingerprint } from 'lucide-react';
import { authService } from '../services/authService';
import { adminService } from '../services/adminService';
import { User, UserRole } from '../types';
import Logo from '../components/Logo';

interface AdminLoginProps {
  onLoginSuccess: (user: User) => void;
}

const AdminLogin: React.FC<AdminLoginProps> = ({ onLoginSuccess }) => {
  const navigate = useNavigate();
  const [step, setStep] = useState<'credentials' | '2fa'>('credentials');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [otp, setOtp] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [isAuthenticating, setIsAuthenticating] = useState(false);
  const [authStepMessage, setAuthStepMessage] = useState<string | null>(null);
  const [tempUser, setTempUser] = useState<User | null>(null);

  const handleCredentialSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setIsAuthenticating(true);
    
    setAuthStepMessage("Validating System Credentials...");
    await new Promise(r => setTimeout(r, 1200));

    try {
      const user = await authService.login(email, password);
      if (user && user.role === UserRole.ADMIN) {
        setTempUser(user);
        setStep('2fa');
      } else if (user) {
        setError("Access Revoked: Credentials lack Administrator Level Clearance.");
        authService.logout();
      } else {
        setError("Authentication Failed: System ID or Access Key is incorrect.");
      }
    } catch (err) {
      setError("Critical Error: Core authentication services are offline.");
    } finally {
      setIsAuthenticating(false);
      setAuthStepMessage(null);
    }
  };

  const handleOtpSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setIsAuthenticating(true);
    
    setAuthStepMessage("Verifying Secure Token...");
    await new Promise(r => setTimeout(r, 800));

    // Simulated OTP check (123456 for testing)
    if (otp === '123456' || otp === '000000') {
      if (tempUser) {
        onLoginSuccess(tempUser);
        adminService.logActivity('Admin Console Entry Secured (2FA)', 'admin-portal', 'system');
        navigate('/internal/system-node-7412');
      }
    } else {
      setError("Verification Failed: Invalid Security Token.");
    }
    setIsAuthenticating(false);
    setAuthStepMessage(null);
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-4 bg-[#050505] selection:bg-red-500/30 selection:text-white font-['Bricolage_Grotesque'] relative overflow-hidden">
      {/* Dynamic Grid Background */}
      <div className="absolute inset-0 z-0 opacity-10 pointer-events-none" style={{ backgroundImage: 'radial-gradient(circle at 2px 2px, #444 1px, transparent 0)', backgroundSize: '40px 40px' }}></div>
      <div className="absolute top-0 left-0 w-full h-full bg-gradient-to-b from-red-950/10 via-transparent to-transparent pointer-events-none"></div>

      <div className="max-w-md w-full relative z-10">
        <div className="text-center mb-12 animate-in fade-in duration-1000">
          <Link to="/" className="flex items-center justify-center mb-10 hover:opacity-80 transition-opacity">
            <Logo variant="white" className="drop-shadow-[0_0_25px_rgba(230,0,0,0.4)]" />
          </Link>
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-red-950/40 border border-red-500/30 text-red-500 text-[10px] font-black uppercase tracking-[0.3em] mb-6 shadow-[0_0_20px_rgba(230,0,0,0.2)]">
            <Cpu size={12} className="animate-pulse" />
            Security Gateway Alpha-1
          </div>
          <h2 className="text-3xl font-black text-white tracking-tight mb-2">
            {step === 'credentials' ? 'System Access' : 'Identity Verification'}
          </h2>
          <p className="text-gray-600 font-medium text-sm">
            {step === 'credentials' ? 'Westlands Operations Hub • Restricted Entry' : 'Verification code required for root clearance'}
          </p>
        </div>

        <div className="bg-[#0f0f0f] rounded-[2.5rem] border border-white/10 p-8 md:p-12 shadow-[0_40px_80px_-20px_rgba(0,0,0,0.8)] relative overflow-hidden">
          {error && (
            <div className="mb-8 p-5 bg-red-950/30 border border-red-500/20 rounded-2xl text-red-400 text-xs font-bold animate-in slide-in-from-top-2 flex items-start gap-3">
              <ShieldAlert className="shrink-0 h-5 w-5" />
              <span>{error}</span>
            </div>
          )}
          
          {step === 'credentials' ? (
            <form onSubmit={handleCredentialSubmit} className="space-y-6 relative z-10">
              <div className="space-y-2">
                <label className="block text-[10px] font-black text-gray-500 uppercase tracking-widest ml-1">System ID</label>
                <div className="relative group">
                  <Terminal className="absolute left-5 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-700 group-focus-within:text-red-500 transition-colors" />
                  <input 
                    type="email" 
                    required
                    placeholder="admin@dijitickets.co.ke"
                    className="w-full pl-14 pr-6 py-4 rounded-2xl bg-black border border-white/10 outline-none focus:border-red-500/50 text-white font-bold text-sm transition-all placeholder:text-gray-800"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                  />
                </div>
              </div>

              <div className="space-y-2">
                <label className="block text-[10px] font-black text-gray-500 uppercase tracking-widest ml-1">Access Key</label>
                <div className="relative group">
                  <Key className="absolute left-5 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-700 group-focus-within:text-red-500 transition-colors" />
                  <input 
                    type="password" 
                    required
                    placeholder="••••••••"
                    className="w-full pl-14 pr-6 py-4 rounded-2xl bg-black border border-white/10 outline-none focus:border-red-500/50 text-white font-bold text-sm transition-all placeholder:text-gray-800"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                  />
                </div>
              </div>

              <button 
                type="submit"
                disabled={isAuthenticating}
                className="w-full bg-red-600 hover:bg-red-700 disabled:bg-gray-900 disabled:text-gray-600 text-white py-5 rounded-[2rem] font-black text-lg shadow-[0_20px_40px_-10px_rgba(230,0,0,0.4)] transition-all flex items-center justify-center space-x-3 active:scale-95 group"
              >
                {isAuthenticating ? (
                  <div className="flex flex-col items-center">
                    <span className="text-sm">{authStepMessage}</span>
                  </div>
                ) : (
                  <>
                    <span>Authorize Session</span>
                    <ArrowRight className="h-6 w-6 group-hover:translate-x-1 transition-transform" />
                  </>
                )}
              </button>
            </form>
          ) : (
            <form onSubmit={handleOtpSubmit} className="space-y-6 relative z-10 animate-in slide-in-from-right-4">
               <div className="space-y-2 text-center mb-6">
                  <div className="w-16 h-16 bg-red-500/10 rounded-full flex items-center justify-center mx-auto mb-4 border border-red-500/20">
                    <Fingerprint className="text-red-500 h-8 w-8" />
                  </div>
                  <p className="text-gray-400 text-xs font-bold px-4 leading-relaxed">System-generated token (123456) required for final clearance.</p>
               </div>
               <div className="space-y-2">
                <label className="block text-[10px] font-black text-gray-500 uppercase tracking-widest text-center mb-4">6-Digit Secure Token</label>
                <input 
                  type="text" 
                  required
                  maxLength={6}
                  placeholder="000 000"
                  className="w-full bg-black border-b-2 border-white/10 outline-none focus:border-red-500/50 text-white font-black text-4xl text-center tracking-[0.5em] py-4 transition-all placeholder:text-gray-900"
                  value={otp}
                  onChange={(e) => setOtp(e.target.value.replace(/[^0-9]/g, ''))}
                  autoFocus
                />
              </div>

              <button 
                type="submit"
                disabled={isAuthenticating || otp.length < 6}
                className="w-full bg-red-600 hover:bg-red-700 disabled:bg-gray-900 disabled:text-gray-600 text-white py-5 rounded-[2rem] font-black text-lg shadow-[0_20px_40px_-10px_rgba(230,0,0,0.4)] transition-all flex items-center justify-center space-x-3 active:scale-95 group mt-8"
              >
                {isAuthenticating ? "Synchronizing..." : "Confirm Identity"}
              </button>
              
              <button 
                type="button"
                onClick={() => setStep('credentials')}
                className="w-full text-[10px] font-black text-gray-600 uppercase tracking-widest hover:text-white transition-colors"
              >
                Cancel Session
              </button>
            </form>
          )}

          <ShieldCheck className="absolute -right-12 -bottom-12 opacity-[0.02] w-64 h-64 rotate-12 pointer-events-none" />
        </div>

        <div className="mt-12 text-center flex flex-col items-center gap-4">
          <Link to="/login" className="text-gray-600 text-[10px] font-black uppercase tracking-widest hover:text-white transition-colors">
            ← Return to Consumer Node
          </Link>
          <p className="text-[9px] text-gray-800 font-bold uppercase tracking-widest">Session ID: {Math.random().toString(36).substring(7).toUpperCase()}</p>
        </div>
      </div>
    </div>
  );
};

export default AdminLogin;
