
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  ShieldCheck, Eye, AlertCircle, X, 
  Calendar, MapPin, Clock, Info, 
  Edit3, Save, Loader2, Trash2,
  Facebook, Twitter, Instagram, Ticket as TicketIcon,
  Check, ChevronDown, ExternalLink, TrendingUp, Globe,
  ArrowUpRight, User as UserIcon, AlertTriangle, RefreshCw, 
  Bomb, LayoutDashboard, Terminal, History, QrCode, Search,
  Activity, Settings, Lock, Smartphone, Users, UserPlus
} from 'lucide-react';
import { eventService } from '../services/eventService';
import { authService } from '../services/authService';
import { adminService } from '../services/adminService';
import { DB } from '../db';
import { Event, TicketType, AdminActivity, Ticket, UserRole, User } from '../types';
import { formatCurrency } from '../constants';

type Tab = 'overview' | 'moderation' | 'users' | 'verification' | 'logs' | 'system';

const AdminPanel: React.FC = () => {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState<Tab>('overview');
  const [events, setEvents] = useState<Event[]>([]);
  const [users, setUsers] = useState<User[]>([]);
  const [filter, setFilter] = useState<'all' | 'pending' | 'approved' | 'rejected'>('pending');
  const [viewingEvent, setViewingEvent] = useState<Event | null>(null);
  const [confirmDeleteEvent, setConfirmDeleteEvent] = useState<Event | null>(null);
  const [isPurging, setIsPurging] = useState(false);
  const [showPurgeConfirm, setShowPurgeConfirm] = useState(false);
  const [rejectionReason, setRejectionReason] = useState('');
  const [showRejectModal, setShowRejectModal] = useState<Event | null>(null);
  
  // Verification State
  const [scanCode, setScanCode] = useState('');
  const [scanResult, setScanResult] = useState<{success: boolean, message: string, ticket?: Ticket} | null>(null);

  useEffect(() => {
    const user = authService.getCurrentUser();
    if (!user || user.role !== UserRole.ADMIN) {
      navigate('/internal/system-access-node');
      return;
    }
    refreshData();
  }, [navigate]);

  // Fixed: Made refreshData async to properly await service calls
  const refreshData = async () => {
    const adminEvents = await eventService.getAllForAdmin();
    setEvents([...adminEvents]);
    setUsers([...DB.getUsers()]);
  };

  const handleApprove = async (id: string) => {
    const event = events.find(e => e.id === id);
    await eventService.approveEvent(id, 'approved');
    await eventService.updateStatus(id, 'published');
    adminService.logActivity('MODERATION_APPROVE', event?.title || id, 'event');
    refreshData();
    setViewingEvent(null);
  };

  const handleReject = async () => {
    if (!showRejectModal || !rejectionReason.trim()) return;
    await eventService.approveEvent(showRejectModal.id, 'rejected', rejectionReason);
    adminService.logActivity('MODERATION_REJECT', showRejectModal.title, 'event', 'warning');
    setRejectionReason('');
    setShowRejectModal(null);
    setViewingEvent(null);
    refreshData();
  };

  const toggleUserRole = (userId: string) => {
    const allUsers = DB.getUsers();
    const userIdx = allUsers.findIndex(u => u.id === userId);
    if (userIdx !== -1) {
      const oldRole = allUsers[userIdx].role;
      const newRole = oldRole === UserRole.ADMIN ? UserRole.ORGANIZER : UserRole.ADMIN;
      allUsers[userIdx].role = newRole;
      DB.saveUsers(allUsers);
      adminService.logActivity('USER_ROLE_CHANGE', `${allUsers[userIdx].email} -> ${newRole}`, 'user');
      refreshData();
    }
  };

  const executeDelete = async (id: string) => {
    const eventToDelete = events.find(e => e.id === id);
    await eventService.delete(id);
    adminService.logActivity('SENSITIVE_DELETE_EVENT', eventToDelete?.title || id, 'event', 'warning');
    refreshData();
    setConfirmDeleteEvent(null);
    if (viewingEvent?.id === id) setViewingEvent(null);
  };

  const handlePurgePlatform = async () => {
    setIsPurging(true);
    await eventService.purgeAll();
    adminService.logActivity('SENSITIVE_MASTER_PURGE', 'ALL_SYSTEM_DATA', 'system', 'warning');
    
    setTimeout(() => {
      refreshData();
      setIsPurging(false);
      setShowPurgeConfirm(false);
    }, 1500);
  };

  const handleManualScan = (e: React.FormEvent) => {
    e.preventDefault();
    if (!scanCode.trim()) return;
    const result = adminService.verifyTicketAtGate(scanCode);
    setScanResult(result);
    setScanCode('');
  };

  const filteredEvents = events.filter(e => filter === 'all' || e.approvalStatus === filter);

  return (
    <div className="flex flex-col lg:flex-row min-h-screen bg-[#0f0f0f] font-['Bricolage_Grotesque']">
      {/* Sidebar */}
      <div className="w-full lg:w-72 shrink-0 bg-[#0a0a0a] border-r border-white/5 lg:min-h-[calc(100vh-80px)] p-6 space-y-8 overflow-y-auto no-scrollbar">
        <div>
          <p className="text-[10px] font-black text-gray-500 uppercase tracking-widest mb-6 px-4">Command Console</p>
          <nav className="space-y-1">
            {[
              { id: 'overview', icon: <LayoutDashboard size={20} />, label: 'Overview' },
              { id: 'moderation', icon: <Terminal size={20} />, label: 'Moderation' },
              { id: 'users', icon: <Users size={20} />, label: 'User Index' },
              { id: 'verification', icon: <QrCode size={20} />, label: 'Gate Access' },
              { id: 'logs', icon: <History size={20} />, label: 'System Logs' },
              { id: 'system', icon: <Settings size={20} />, label: 'Maintenance' },
            ].map(item => (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id as Tab)}
                className={`w-full flex items-center gap-4 px-4 py-3.5 rounded-2xl transition-all font-bold text-sm ${
                  activeTab === item.id 
                    ? 'bg-red-600 text-white shadow-lg shadow-red-900/20' 
                    : 'text-gray-400 hover:text-white hover:bg-white/5'
                }`}
              >
                {item.icon}
                {item.label}
              </button>
            ))}
          </nav>
        </div>

        <div className="pt-8 border-t border-white/5 px-4">
          <div className="flex items-center gap-3 text-red-500 mb-2">
            <Activity size={16} />
            <span className="text-[10px] font-black uppercase tracking-widest">Platform Healthy</span>
          </div>
          <p className="text-[10px] text-gray-500 font-medium">Internal Build v2.6.0-Live</p>
        </div>
      </div>

      <main className="flex-1 p-6 md:p-10 lg:p-12 overflow-x-hidden">
        {activeTab === 'overview' && (
          <div className="space-y-12 animate-in fade-in duration-500">
            <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
              <div>
                <h1 className="text-3xl md:text-5xl font-black text-white tracking-tight mb-2">System Pulse</h1>
                <p className="text-gray-500 font-medium">Real-time internal diagnostics for DijiTickets.</p>
              </div>
              <div className="bg-white/5 border border-white/5 rounded-2xl px-6 py-4 flex items-center gap-4">
                <div className="w-2.5 h-2.5 bg-green-500 rounded-full animate-pulse"></div>
                <span className="text-white font-black text-xs uppercase tracking-widest">Node Node Alpha-7 Connected</span>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {[
                { label: 'Active Events', value: events.filter(e => e.approvalStatus === 'approved').length, icon: <Globe className="text-blue-500" />, sub: 'National Reach' },
                { label: 'Approval Queue', value: events.filter(e => e.approvalStatus === 'pending').length, icon: <AlertCircle className="text-yellow-500" />, sub: 'Priority Critical' },
                { label: 'Total Users', value: users.length, icon: <Users className="text-purple-500" />, sub: 'Registered Accounts' },
                { label: 'Platform Sales', value: formatCurrency(events.reduce((acc, e) => acc + e.ticketTypes.reduce((s, t) => s + (t.sold * t.price), 0), 0)), icon: <TrendingUp className="text-green-500" />, sub: 'Gross Volume' },
              ].map((stat, i) => (
                <div key={i} className="bg-[#141414] border border-white/5 p-8 rounded-[2rem] hover:border-white/10 transition-all group">
                   <div className="bg-white/5 w-12 h-12 rounded-xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">{stat.icon}</div>
                   <p className="text-[10px] font-black text-gray-500 uppercase tracking-widest mb-1">{stat.label}</p>
                   <p className="text-2xl font-black text-white mb-2">{stat.value}</p>
                   <p className="text-[10px] text-gray-600 font-bold">{stat.sub}</p>
                </div>
              ))}
            </div>

            <div className="bg-red-600 rounded-[3rem] p-10 md:p-16 text-white relative overflow-hidden shadow-2xl shadow-red-900/20">
              <div className="relative z-10 max-w-2xl">
                <h2 className="text-3xl md:text-5xl font-black mb-6 tracking-tight">Audit Trail Active</h2>
                <p className="text-red-100 text-lg md:text-xl font-medium leading-relaxed opacity-90">
                  Administrative actions are monitored and permanent. Ensure double-verification before approving high-volume events or executing master resets.
                </p>
              </div>
              <ShieldCheck className="absolute -right-20 -bottom-20 w-96 h-96 opacity-10 rotate-12" />
            </div>
          </div>
        )}

        {activeTab === 'moderation' && (
          <div className="space-y-8 animate-in slide-in-from-bottom-4 duration-500">
            <div className="flex items-center justify-between">
              <h2 className="text-3xl font-black text-white tracking-tight">Queue Moderation</h2>
              <div className="bg-[#141414] p-1.5 rounded-2xl border border-white/5 flex gap-1">
                {(['all', 'pending', 'approved', 'rejected'] as const).map(f => (
                  <button 
                    key={f}
                    onClick={() => setFilter(f)}
                    className={`px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${
                      filter === f ? 'bg-red-600 text-white' : 'text-gray-500 hover:text-white'
                    }`}
                  >
                    {f}
                  </button>
                ))}
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredEvents.map(event => (
                <div key={event.id} className="bg-[#141414] border border-white/5 rounded-[2rem] overflow-hidden group">
                  <div className="h-40 relative">
                    <img src={event.bannerImage} className="w-full h-full object-cover opacity-60 group-hover:opacity-100 transition-opacity" alt="" />
                    <div className="absolute inset-0 bg-gradient-to-t from-[#141414] to-transparent"></div>
                    <div className="absolute top-4 left-4">
                      <span className={`px-3 py-1 rounded-full text-[9px] font-black uppercase tracking-widest border ${
                        event.approvalStatus === 'approved' ? 'bg-green-500/20 text-green-500 border-green-500/30' :
                        event.approvalStatus === 'pending' ? 'bg-yellow-500/20 text-yellow-500 border-yellow-500/30' : 'bg-red-500/20 text-red-500 border-red-500/30'
                      }`}>
                        {event.approvalStatus}
                      </span>
                    </div>
                  </div>
                  <div className="p-6">
                    <h3 className="text-lg font-black text-white mb-2 truncate">{event.title}</h3>
                    <div className="flex items-center gap-2 text-gray-500 mb-6">
                      <UserIcon size={14} />
                      <span className="text-[10px] font-black uppercase tracking-widest">ID: {event.organizerId}</span>
                    </div>
                    <div className="flex gap-2">
                       <button 
                        onClick={() => setViewingEvent(event)}
                        className="flex-1 bg-white/5 hover:bg-white/10 text-white py-3 rounded-xl font-black text-[10px] uppercase tracking-widest transition-all"
                       >
                         Review
                       </button>
                       <button 
                        onClick={() => setConfirmDeleteEvent(event)}
                        className="bg-red-500/10 hover:bg-red-600 text-red-500 hover:text-white p-3 rounded-xl transition-all"
                       >
                         <Trash2 size={16} />
                       </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
            {filteredEvents.length === 0 && (
               <div className="py-32 text-center bg-white/5 rounded-[3rem] border border-dashed border-white/10">
                  <Terminal size={48} className="mx-auto text-gray-700 mb-6" />
                  <p className="text-xl font-black text-gray-600">Queue is Clear.</p>
               </div>
            )}
          </div>
        )}

        {activeTab === 'users' && (
           <div className="space-y-8 animate-in fade-in duration-500">
              <h2 className="text-3xl font-black text-white tracking-tight">Identity Management</h2>
              <div className="bg-[#141414] border border-white/5 rounded-[3rem] overflow-hidden">
                <table className="w-full text-left">
                  <thead>
                    <tr className="bg-white/5 border-b border-white/5">
                      <th className="px-8 py-5 text-[10px] font-black text-gray-500 uppercase tracking-widest">Account</th>
                      <th className="px-8 py-5 text-[10px] font-black text-gray-500 uppercase tracking-widest">Level</th>
                      <th className="px-8 py-5 text-[10px] font-black text-gray-500 uppercase tracking-widest text-right">Action</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-white/5">
                    {users.map(u => (
                      <tr key={u.id} className="hover:bg-white/[0.02] transition-colors">
                        <td className="px-8 py-5">
                          <div className="flex items-center gap-4">
                            <div className="w-10 h-10 rounded-2xl bg-gray-800 flex items-center justify-center font-black text-white text-xs uppercase tracking-tighter border border-white/5">
                              {u.name.substring(0,2)}
                            </div>
                            <div>
                               <p className="text-white font-bold text-sm">{u.name}</p>
                               <p className="text-gray-500 text-xs">{u.email}</p>
                            </div>
                          </div>
                        </td>
                        <td className="px-8 py-5">
                           <span className={`text-[9px] font-black px-3 py-1 rounded-full uppercase tracking-widest border ${
                             u.role === UserRole.ADMIN ? 'bg-red-500/10 text-red-500 border-red-500/20' : 'bg-blue-500/10 text-blue-500 border-blue-500/20'
                           }`}>
                              {u.role}
                           </span>
                        </td>
                        <td className="px-8 py-5 text-right">
                           <button 
                             onClick={() => toggleUserRole(u.id)}
                             className="text-[10px] font-black uppercase tracking-widest text-gray-400 hover:text-white transition-colors"
                           >
                             {u.role === UserRole.ADMIN ? 'Revoke Admin' : 'Make Admin'}
                           </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
           </div>
        )}

        {activeTab === 'verification' && (
          <div className="max-w-2xl mx-auto space-y-12 animate-in fade-in duration-500">
             <div className="text-center">
                <div className="bg-red-600 w-20 h-20 rounded-[2rem] flex items-center justify-center mx-auto mb-8 shadow-2xl shadow-red-900/40">
                   <QrCode className="h-10 w-10 text-white" />
                </div>
                <h2 className="text-3xl font-black text-white mb-4 tracking-tight">Access Node Verification</h2>
                <p className="text-gray-500 font-medium">Verify unique digital signatures for event entry.</p>
             </div>

             <form onSubmit={handleManualScan} className="relative group">
                <div className="absolute left-6 top-1/2 -translate-y-1/2 text-gray-600 group-focus-within:text-red-500 transition-colors">
                   <Search size={24} />
                </div>
                <input 
                  type="text" 
                  placeholder="Ticket Hash Index..."
                  className="w-full bg-[#141414] border-2 border-white/5 rounded-3xl pl-16 pr-8 py-6 text-white font-black text-xl outline-none focus:border-red-600/50 transition-all placeholder:text-gray-800"
                  value={scanCode}
                  onChange={(e) => setScanCode(e.target.value)}
                />
                <button type="submit" className="absolute right-3 top-1/2 -translate-y-1/2 bg-red-600 text-white px-8 py-3 rounded-2xl font-black text-sm uppercase tracking-widest hover:bg-red-700 transition-all active:scale-95 shadow-xl">
                   Validate
                </button>
             </form>

             {scanResult && (
                <div className={`p-10 rounded-[3rem] border-2 animate-in slide-in-from-top-4 duration-500 text-center ${
                  scanResult.success ? 'bg-green-500/10 border-green-500/20' : 'bg-red-500/10 border-red-500/20'
                }`}>
                   <div className={`w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-6 ${
                     scanResult.success ? 'bg-green-50 text-green-600' : 'bg-red-50 text-red-600'
                   }`}>
                      {scanResult.success ? <Check size={40} /> : <X size={40} />}
                   </div>
                   <h3 className={`text-2xl font-black mb-2 ${scanResult.success ? 'text-green-500' : 'text-red-500'}`}>
                     {scanResult.success ? 'ENTRY_GRANTED' : 'ACCESS_DENIED'}
                   </h3>
                   <p className="text-white font-bold mb-8 text-lg">{scanResult.message}</p>
                   {scanResult.ticket && (
                      <div className="bg-white/5 p-6 rounded-2xl text-left inline-block w-full max-w-sm">
                         <p className="text-[10px] font-black text-gray-500 uppercase mb-2">Gate Metadata</p>
                         <p className="text-white text-sm font-bold truncate">Ref: {scanResult.ticket.id}</p>
                         <p className="text-gray-400 text-xs">Date: {new Date(scanResult.ticket.purchaseDate).toLocaleString()}</p>
                      </div>
                   )}
                </div>
             )}
          </div>
        )}

        {activeTab === 'logs' && (
          <div className="space-y-8 animate-in fade-in duration-500">
             <div className="flex items-center justify-between">
                <h2 className="text-3xl font-black text-white tracking-tight">Immutable System Logs</h2>
                <button onClick={() => refreshData()} className="p-3 bg-white/5 hover:bg-white/10 text-gray-400 rounded-xl transition-all">
                   <RefreshCw size={20} />
                </button>
             </div>

             <div className="bg-[#141414] border border-white/5 rounded-[3rem] overflow-hidden">
                <table className="w-full text-left">
                   <thead>
                      <tr className="bg-white/5 border-b border-white/5">
                         <th className="px-8 py-5 text-[10px] font-black text-gray-500 uppercase tracking-widest">Administrator</th>
                         <th className="px-8 py-5 text-[10px] font-black text-gray-500 uppercase tracking-widest">Operation</th>
                         <th className="px-8 py-5 text-[10px] font-black text-gray-500 uppercase tracking-widest">Object Ref</th>
                         <th className="px-8 py-5 text-[10px] font-black text-gray-500 uppercase tracking-widest text-right">Timestamp</th>
                      </tr>
                   </thead>
                   <tbody className="divide-y divide-white/5">
                      {adminService.getLogs().map(log => (
                        <tr key={log.id} className="hover:bg-white/[0.02] transition-colors">
                           <td className="px-8 py-5">
                              <div className="flex items-center gap-3">
                                 <div className="w-8 h-8 rounded-full bg-red-600 flex items-center justify-center text-[10px] font-black text-white">{log.adminName.charAt(0)}</div>
                                 <span className="text-white font-bold text-sm">{log.adminName}</span>
                              </div>
                           </td>
                           <td className="px-8 py-5">
                              <span className={`text-[10px] font-black px-3 py-1 rounded-full uppercase tracking-widest ${
                                log.status === 'warning' ? 'bg-red-500/10 text-red-500' : 'bg-green-500/10 text-green-500'
                              }`}>
                                 {log.action}
                              </span>
                           </td>
                           <td className="px-8 py-5">
                              <span className="text-gray-500 text-xs font-mono truncate block max-w-[150px]">{log.targetId}</span>
                           </td>
                           <td className="px-8 py-5 text-right">
                              <span className="text-gray-600 text-[10px] font-black uppercase tracking-widest">{new Date(log.timestamp).toLocaleString()}</span>
                           </td>
                        </tr>
                      ))}
                      {adminService.getLogs().length === 0 && (
                         <tr><td colSpan={4} className="py-20 text-center text-gray-600 font-bold">No activity recorded.</td></tr>
                      )}
                   </tbody>
                </table>
             </div>
          </div>
        )}

        {activeTab === 'system' && (
           <div className="max-w-4xl mx-auto space-y-12 animate-in slide-in-from-top-4 duration-500">
              <div className="text-center">
                 <h2 className="text-3xl font-black text-white mb-4 tracking-tight">Management Protocols</h2>
                 <p className="text-gray-500 font-medium">Core platform security and maintenance.</p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                 <div className="bg-[#141414] p-10 rounded-[3rem] border border-white/5 space-y-6">
                    <h3 className="text-xl font-black text-white">System Lockout</h3>
                    <p className="text-gray-500 text-sm leading-relaxed font-medium">Prevent public access to all event nodes and ticket engines.</p>
                    <button className="w-full py-4 bg-white/5 hover:bg-white/10 text-white rounded-2xl font-black text-xs uppercase tracking-widest border border-white/5 transition-all">
                       Toggle Master Lock
                    </button>
                 </div>

                 <div className="bg-red-950/20 p-10 rounded-[3rem] border border-red-500/10 space-y-6">
                    <div className="flex items-center gap-3 text-red-500">
                       <Bomb size={24} />
                       <h3 className="text-xl font-black">Database Wipe</h3>
                    </div>
                    <p className="text-gray-500 text-sm font-medium">IRREVERSIBLE. Clear all user, event, and ticket indices from the core DB.</p>
                    <button 
                      onClick={() => setShowPurgeConfirm(true)}
                      className="w-full py-4 bg-red-600 hover:bg-red-700 text-white rounded-2xl font-black text-xs uppercase tracking-widest shadow-xl shadow-red-900/20 transition-all active:scale-95"
                    >
                       Initiate Clear-Down
                    </button>
                 </div>
              </div>
           </div>
        )}
      </main>

      {/* View Event Modal */}
      {viewingEvent && (
        <ViewModal 
          event={viewingEvent} 
          onClose={() => setViewingEvent(null)} 
          onApprove={() => handleApprove(viewingEvent.id)}
          onReject={() => setShowRejectModal(viewingEvent)}
          onDelete={(id: string) => setConfirmDeleteEvent(viewingEvent)}
        />
      )}

      {/* Reject Reason Modal */}
      {showRejectModal && (
        <div className="fixed inset-0 z-[200] flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/90 backdrop-blur-md" onClick={() => setShowRejectModal(null)}></div>
          <div className="relative bg-white w-full max-w-md rounded-[3rem] shadow-2xl p-10 font-['Bricolage_Grotesque']">
             <h3 className="text-2xl font-black text-gray-900 mb-2">Reject Content</h3>
             <p className="text-gray-500 text-sm font-medium mb-6">Briefly explain why this event does not meet guidelines.</p>
             <textarea 
               autoFocus
               rows={4}
               placeholder="e.g. Inappropriate content, missing venue authorization..."
               className="w-full p-6 bg-gray-50 rounded-2xl border-none outline-none focus:ring-4 focus:ring-red-500/10 font-bold mb-6"
               value={rejectionReason}
               onChange={(e) => setRejectionReason(e.target.value)}
             />
             <div className="flex gap-4">
                <button onClick={() => setShowRejectModal(null)} className="flex-1 py-4 bg-gray-100 text-gray-500 rounded-2xl font-black text-sm uppercase tracking-widest">Cancel</button>
                <button 
                  onClick={handleReject} 
                  disabled={!rejectionReason.trim()}
                  className="flex-1 py-4 bg-red-600 text-white rounded-2xl font-black text-sm uppercase tracking-widest disabled:opacity-50"
                >
                  Send Rejection
                </button>
             </div>
          </div>
        </div>
      )}

      {confirmDeleteEvent && (
        <DeleteConfirmModal 
          event={confirmDeleteEvent} 
          onCancel={() => setConfirmDeleteEvent(null)} 
          onConfirm={() => executeDelete(confirmDeleteEvent.id)} 
        />
      )}

      {showPurgeConfirm && (
        <PurgeConfirmModal 
          onCancel={() => !isPurging && setShowPurgeConfirm(false)} 
          onConfirm={handlePurgePlatform}
          isPurging={isPurging}
        />
      )}
    </div>
  );
};

const DeleteConfirmModal = ({ event, onCancel, onConfirm }: any) => {
  const [confirmText, setConfirmText] = useState('');
  const isValid = confirmText.trim().toLowerCase() === event.title.trim().toLowerCase();

  return (
    <div className="fixed inset-0 z-[200] flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/95 backdrop-blur-md animate-in fade-in duration-300" onClick={onCancel}></div>
      <div className="relative bg-white w-full max-w-md rounded-[3rem] shadow-2xl p-10 text-center animate-in zoom-in duration-300 font-['Bricolage_Grotesque']">
        <div className="bg-red-100 w-20 h-20 rounded-[2rem] flex items-center justify-center mx-auto mb-8 shadow-inner">
          <AlertTriangle className="h-10 w-10 text-red-600" />
        </div>
        <h3 className="text-2xl font-black text-gray-900 mb-4 tracking-tight leading-tight px-2">
          Security Challenge
        </h3>
        <p className="text-gray-500 font-medium mb-8 leading-relaxed px-4 text-sm">
          To finalize permanent deletion of <span className="text-red-600 font-black">"{event.title}"</span>, type the full title below.
        </p>
        
        <div className="mb-10 text-left">
           <label className="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-2 ml-1">Type Object Title</label>
           <input 
             type="text"
             className={`w-full px-6 py-4 rounded-2xl bg-gray-50 border-2 outline-none transition-all font-bold text-sm ${
               isValid ? 'border-green-500 bg-green-50' : 'border-gray-100 focus:border-red-500/30'
             }`}
             placeholder={event.title}
             value={confirmText}
             onChange={(e) => setConfirmText(e.target.value)}
             autoFocus
           />
        </div>

        <div className="space-y-3">
          <button 
            onClick={onConfirm}
            disabled={!isValid}
            className={`w-full py-5 rounded-2xl font-black text-sm uppercase tracking-widest transition-all shadow-xl active:scale-95 ${
              isValid 
                ? 'bg-red-600 text-white shadow-red-100 hover:bg-red-700' 
                : 'bg-gray-100 text-gray-300 cursor-not-allowed shadow-none'
            }`}
          >
            Confirm Purge
          </button>
          <button 
            onClick={onCancel}
            className="w-full py-5 bg-gray-50 text-gray-500 rounded-2xl font-black text-sm uppercase tracking-widest hover:bg-gray-100 transition-all"
          >
            Abort
          </button>
        </div>
      </div>
    </div>
  );
};

const PurgeConfirmModal = ({ onCancel, onConfirm, isPurging }: any) => (
  <div className="fixed inset-0 z-[200] flex items-center justify-center p-4">
    <div className="absolute inset-0 bg-black/98 backdrop-blur-2xl animate-in fade-in duration-300" onClick={onCancel}></div>
    <div className="relative bg-white w-full max-w-md rounded-[4rem] shadow-2xl p-12 text-center animate-in zoom-in duration-300 border-8 border-red-600 font-['Bricolage_Grotesque']">
      <div className="bg-gray-900 w-24 h-24 rounded-[2.5rem] flex items-center justify-center mx-auto mb-8 shadow-2xl">
        <Bomb className="h-12 w-12 text-red-600 animate-pulse" />
      </div>
      <h3 className="text-4xl font-black text-gray-900 mb-4 tracking-tight leading-none uppercase">
        NUCLEAR_WIPE
      </h3>
      <p className="text-red-600 font-black text-[10px] uppercase tracking-[0.3em] mb-8">Authorizing Master Protocol</p>
      <p className="text-gray-500 font-medium mb-10 leading-relaxed text-sm">
        ALL_DATA will be erased. This action cannot be undone. Audit trail will capture this root operation.
      </p>
      <div className="space-y-3">
        <button 
          onClick={onConfirm}
          disabled={isPurging}
          className="w-full py-6 bg-gray-900 text-white rounded-3xl font-black text-sm uppercase tracking-widest hover:bg-black transition-all shadow-2xl flex items-center justify-center gap-4 active:scale-95 disabled:opacity-50"
        >
          {isPurging ? <RefreshCw className="h-6 w-6 animate-spin" /> : <><ShieldCheck size={20} /> Authorize Reset</>}
        </button>
        <button 
          onClick={onCancel}
          disabled={isPurging}
          className="w-full py-6 bg-gray-100 text-gray-500 rounded-3xl font-black text-sm uppercase tracking-widest hover:bg-gray-200 transition-all"
        >
          Abort Mission
        </button>
      </div>
    </div>
  </div>
);

const ViewModal = ({ event, onClose, onApprove, onReject, onDelete }: any) => {
  const totalProjectedRevenue = event.ticketTypes.reduce((acc: number, tt: any) => acc + (tt.sold * tt.price), 0);

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/95 backdrop-blur-2xl animate-in fade-in duration-300" onClick={onClose}></div>
      <div className="relative bg-[#141414] w-full max-w-5xl rounded-[3rem] shadow-2xl overflow-hidden flex flex-col max-h-[92vh] animate-in zoom-in duration-300 border border-white/5 font-['Bricolage_Grotesque']">
        <div className="h-64 md:h-[350px] shrink-0 relative">
          <img src={event.bannerImage} className="w-full h-full object-cover opacity-40" alt="" />
          <div className="absolute inset-0 bg-gradient-to-t from-[#141414] via-transparent to-transparent"></div>
          <div className="absolute top-8 left-8 flex gap-3">
             <span className={`px-5 py-2.5 rounded-2xl text-[10px] font-black uppercase tracking-widest border ${
                event.approvalStatus === 'approved' ? 'bg-green-600 text-white border-green-500' : 
                event.approvalStatus === 'pending' ? 'bg-yellow-500 text-white border-yellow-400' : 'bg-red-600 text-white border-red-500'
              }`}>
               {event.approvalStatus.toUpperCase()}_QUEUE
             </span>
          </div>
          <button onClick={onClose} className="absolute top-8 right-8 bg-white/5 hover:bg-red-600 text-white p-4 rounded-3xl transition-all border border-white/10 group">
            <X size={24} className="group-hover:rotate-90 transition-transform duration-300"/>
          </button>
          <div className="absolute bottom-10 left-10">
             <h2 className="text-4xl md:text-6xl font-black text-white leading-tight tracking-tight drop-shadow-2xl">{event.title}</h2>
          </div>
        </div>
        
        <div className="p-10 md:p-16 overflow-y-auto no-scrollbar space-y-16">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
             <div className="bg-white/5 p-8 rounded-[2rem] border border-white/5">
                <Calendar className="h-6 w-6 text-red-500 mb-4" />
                <p className="text-[10px] font-black text-gray-500 uppercase tracking-widest mb-1">Date</p>
                <p className="text-base font-black text-white">{event.date}</p>
             </div>
             <div className="bg-white/5 p-8 rounded-[2rem] border border-white/5">
                <MapPin className="h-6 w-6 text-red-500 mb-4" />
                <p className="text-[10px] font-black text-gray-500 uppercase tracking-widest mb-1">Venue</p>
                <p className="text-base font-black text-white truncate">{event.venue}</p>
             </div>
             <div className="bg-[#0f0f0f] p-8 rounded-[2.5rem] md:col-span-2 border border-red-500/10">
                <TrendingUp className="h-6 w-6 text-green-500 mb-4" />
                <p className="text-[10px] font-black text-gray-500 uppercase tracking-widest mb-1">Revenue Performance</p>
                <p className="text-2xl font-black text-white">{formatCurrency(totalProjectedRevenue)}</p>
             </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-5 gap-16">
             <div className="lg:col-span-3 space-y-10">
                <div>
                   <h3 className="text-xs font-black text-white uppercase tracking-[0.2em] mb-6 flex items-center gap-3">
                     <div className="h-1.5 w-1.5 rounded-full bg-red-600"></div> Content Validation
                   </h3>
                   <div className="bg-white/5 p-10 rounded-[3rem] border border-white/5">
                      <p className="text-gray-400 leading-relaxed font-medium whitespace-pre-line">
                        {event.description}
                      </p>
                   </div>
                </div>
             </div>

             <div className="lg:col-span-2 space-y-8">
                <h3 className="text-xs font-black text-white uppercase tracking-[0.2em] mb-6 flex items-center gap-3">
                  <div className="h-1.5 w-1.5 rounded-full bg-red-600"></div> Tiers Check
                </h3>
                <div className="space-y-4">
                  {event.ticketTypes.map((tt: any) => (
                    <div key={tt.id} className="p-6 bg-white/5 border border-white/5 rounded-3xl">
                       <div className="flex justify-between items-start mb-4">
                          <span className="text-xs font-black text-white uppercase">{tt.name}</span>
                          <span className="text-red-500 font-black">{formatCurrency(tt.price)}</span>
                       </div>
                       <div className="flex justify-between text-[10px] font-bold text-gray-500">
                          <span>Capacity: {tt.quantity}</span>
                          <span>Sold: {tt.sold}</span>
                       </div>
                    </div>
                  ))}
                </div>
             </div>
          </div>
        </div>

        <div className="p-10 border-t border-white/5 bg-black/40 flex flex-col md:flex-row gap-4 items-center justify-between">
          <div className="flex items-center gap-4 w-full md:w-auto">
             <button onClick={onClose} className="flex-1 px-8 py-4 bg-white/5 text-gray-400 hover:text-white rounded-2xl font-black text-xs uppercase tracking-widest transition-all">
               Close Preview
             </button>
             <button onClick={() => onDelete(event.id)} className="p-4 bg-red-500/10 text-red-500 hover:bg-red-600 hover:text-white rounded-2xl transition-all border border-red-500/20">
                <Trash2 size={24} />
             </button>
          </div>
          
          <div className="flex-1 w-full md:max-w-xl flex flex-col md:flex-row gap-4">
             {event.approvalStatus === 'pending' && (
               <>
                 <button onClick={onReject} className="flex-1 px-8 py-4 bg-white/10 hover:bg-red-900/20 text-red-500 rounded-2xl font-black text-xs uppercase tracking-widest transition-all">
                   Decline Entry
                 </button>
                 <button onClick={onApprove} className="flex-2 px-12 py-5 bg-red-600 hover:bg-red-700 text-white rounded-2xl font-black text-sm uppercase tracking-widest shadow-xl transition-all active:scale-95 flex items-center justify-center gap-4">
                   <ShieldCheck size={20} /> Authorize Listing
                 </button>
               </>
             )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminPanel;
