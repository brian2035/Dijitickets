
import React from 'react';
import { Phone, Mail, MapPin, MessageSquare, Send } from 'lucide-react';

const ContactUs: React.FC = () => {
  return (
    <div className="min-h-screen bg-white">
      <div className="max-w-7xl mx-auto px-4 py-24">
        <div className="text-center mb-24">
          <h1 className="text-5xl md:text-7xl font-black text-gray-900 mb-6 tracking-tight">Get in <span className="text-red-600">Touch.</span></h1>
          <p className="text-xl text-gray-500 max-w-2xl mx-auto leading-relaxed font-medium">
            Have a question or need help with your event? Our Nairobi-based support team is here for you.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
          <div className="lg:col-span-1 space-y-6">
             <div className="bg-gray-50 p-10 rounded-[2.5rem] border border-gray-100 flex flex-col items-center text-center">
                <div className="bg-red-100 p-4 rounded-2xl mb-6">
                   <Phone className="text-red-600 h-8 w-8" />
                </div>
                <h3 className="text-xl font-black text-gray-900 mb-2">Call Us</h3>
                <p className="text-gray-500 font-bold text-lg mb-1">0154724343</p>
                <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Mon - Sat, 8am - 6pm</p>
             </div>
             <div className="bg-gray-50 p-10 rounded-[2.5rem] border border-gray-100 flex flex-col items-center text-center">
                <div className="bg-red-100 p-4 rounded-2xl mb-6">
                   <Mail className="text-red-600 h-8 w-8" />
                </div>
                <h3 className="text-xl font-black text-gray-900 mb-2">Email Us</h3>
                <p className="text-gray-500 font-bold text-lg mb-1">info@dijitickets.co.ke</p>
                <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Response within 2 hours</p>
             </div>
             <div className="bg-gray-50 p-10 rounded-[2.5rem] border border-gray-100 flex flex-col items-center text-center">
                <div className="bg-red-100 p-4 rounded-2xl mb-6">
                   <MapPin className="text-red-600 h-8 w-8" />
                </div>
                <h3 className="text-xl font-black text-gray-900 mb-2">Office</h3>
                <p className="text-gray-500 font-bold text-lg mb-1">Westlands, Nairobi</p>
                <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Delta Corner, Tower 1</p>
             </div>
          </div>

          <div className="lg:col-span-2 bg-white rounded-[3rem] border border-gray-100 shadow-2xl p-12">
             <div className="flex items-center gap-4 mb-10">
                <MessageSquare className="text-red-600 h-8 w-8" />
                <h2 className="text-3xl font-black text-gray-900 tracking-tight">Send a Message</h2>
             </div>
             
             <form className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div>
                   <label className="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-3 ml-2">Full Name</label>
                   <input type="text" placeholder="John Doe" className="w-full px-6 py-4 bg-gray-50 border-none rounded-2xl focus:ring-4 focus:ring-red-500/10 focus:bg-white transition-all font-bold outline-none" />
                </div>
                <div>
                   <label className="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-3 ml-2">Email Address</label>
                   <input type="email" placeholder="john@example.com" className="w-full px-6 py-4 bg-gray-50 border-none rounded-2xl focus:ring-4 focus:ring-red-500/10 focus:bg-white transition-all font-bold outline-none" />
                </div>
                <div className="md:col-span-2">
                   <label className="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-3 ml-2">Subject</label>
                   <input type="text" placeholder="How can we help?" className="w-full px-6 py-4 bg-gray-50 border-none rounded-2xl focus:ring-4 focus:ring-red-500/10 focus:bg-white transition-all font-bold outline-none" />
                </div>
                <div className="md:col-span-2">
                   <label className="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-3 ml-2">Message</label>
                   <textarea rows={6} placeholder="Type your message here..." className="w-full px-6 py-4 bg-gray-50 border-none rounded-2xl focus:ring-4 focus:ring-red-500/10 focus:bg-white transition-all font-medium outline-none resize-none"></textarea>
                </div>
                <div className="md:col-span-2">
                   <button className="w-full bg-red-600 text-white py-5 rounded-2xl font-black text-xl shadow-2xl shadow-red-100 hover:bg-red-700 transition-all flex items-center justify-center gap-3">
                      <Send className="h-6 w-6" /> Send Message
                   </button>
                </div>
             </form>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ContactUs;
