
import React, { useState, useRef, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { 
  Calendar, MapPin, Image as ImageIcon, Plus, 
  Info, CheckCircle2, Clock, Upload, X, Link as LinkIcon, 
  Loader2, FileText, Check, Search, Map as MapIcon, ExternalLink,
  Trash2, ChevronDown, PlusCircle, Zap
} from 'lucide-react';
import { eventService } from '../services/eventService';
import { authService } from '../services/authService';
import { mapService } from '../services/mapService';
import { CATEGORIES as INITIAL_CATEGORIES } from '../constants';
import { TicketType, Event } from '../types';

const CreateEvent: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const categoryRef = useRef<HTMLDivElement>(null);
  const user = authService.getCurrentUser();
  
  const [existingEvent, setExistingEvent] = useState<Event | null>(null);
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [date, setDate] = useState('');
  const [time, setTime] = useState('');
  const [venue, setVenue] = useState('');
  const [category, setCategory] = useState(INITIAL_CATEGORIES[0]);
  const [bannerUrl, setBannerUrl] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [loadingMessage, setLoadingMessage] = useState('Initializing...');
  const [isOptimizing, setIsOptimizing] = useState(false);
  
  // Category Search State
  const [isCategoryOpen, setIsCategoryOpen] = useState(false);
  const [categorySearch, setCategorySearch] = useState('');
  const [availableCategories, setAvailableCategories] = useState(INITIAL_CATEGORIES);

  const [isMapModalOpen, setIsMapModalOpen] = useState(false);
  const [mapSearchQuery, setMapSearchQuery] = useState('');
  const [isSearchingMap, setIsSearchingMap] = useState(false);
  const [mapResults, setMapResults] = useState<{name: string, address: string, url: string}[]>([]);
  const [selectedMapUrl, setSelectedMapUrl] = useState('');

  const [ticketTypes, setTicketTypes] = useState<Partial<TicketType>[]>([
    { id: '1', name: 'Regular', price: 0, quantity: 100, sold: 0 }
  ]);

  useEffect(() => {
    // Fixed: Wrapped service call in an async function inside useEffect
    const fetchEvent = async () => {
      if (id) {
        const ev = await eventService.getById(id);
        if (ev) {
          setExistingEvent(ev);
          setTitle(ev.title);
          setDescription(ev.description);
          setDate(ev.date);
          setTime(ev.time);
          setVenue(ev.venue);
          setCategory(ev.category);
          setBannerUrl(ev.bannerImage);
          setTicketTypes(ev.ticketTypes);
          
          if (!availableCategories.includes(ev.category)) {
            setAvailableCategories(prev => [...prev, ev.category]);
          }
        } else {
          navigate('/create-event');
        }
      }
    };
    fetchEvent();
  }, [id, navigate, availableCategories]);

  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (categoryRef.current && !categoryRef.current.contains(e.target as Node)) {
        setIsCategoryOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleDelete = async () => {
    if (id) {
      setIsSubmitting(true);
      setLoadingMessage('Removing from server...');
      await eventService.delete(id);
      navigate('/organizer');
    }
  };

  const compressImage = (base64Str: string): Promise<string> => {
    return new Promise((resolve) => {
      const img = new Image();
      img.src = base64Str;
      img.onload = () => {
        const canvas = document.createElement('canvas');
        const MAX_WIDTH = 1200;
        let width = img.width;
        let height = img.height;

        if (width > MAX_WIDTH) {
          height *= MAX_WIDTH / width;
          width = MAX_WIDTH;
        }

        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        ctx?.drawImage(img, 0, 0, width, height);
        resolve(canvas.toDataURL('image/jpeg', 0.7));
      };
    });
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setIsOptimizing(true);
      const reader = new FileReader();
      reader.onloadend = async () => {
        const rawBase64 = reader.result as string;
        const compressed = await compressImage(rawBase64);
        setBannerUrl(compressed);
        setIsOptimizing(false);
      };
      reader.readAsDataURL(file);
    }
  };

  const getStatusConfig = () => {
    if (isSubmitted) return { label: 'Event Published!', sub: 'Visible to fans immediately.', color: 'text-green-700', bg: 'bg-green-50', border: 'border-green-100', icon: <CheckCircle2 className="text-green-600 h-6 w-6" /> };
    if (isOptimizing) return { label: 'Optimizing Media...', sub: 'Compressing for performance.', color: 'text-blue-700', bg: 'bg-blue-50', border: 'border-blue-100', icon: <Loader2 className="text-blue-600 h-6 w-6 animate-spin" /> };
    if (isSubmitting) return { label: loadingMessage, sub: 'Syncing with backend...', color: 'text-blue-700', bg: 'bg-blue-50', border: 'border-blue-100', icon: <Loader2 className="text-blue-600 h-6 w-6 animate-spin" /> };
    
    if (existingEvent) {
      return { label: 'Live Event', sub: 'Event is visible to fans.', color: 'text-green-700', bg: 'bg-green-50', border: 'border-green-100', icon: <CheckCircle2 className="text-green-600 h-6 w-6" /> };
    }
    
    return { label: 'Go Live Ready', sub: 'Publishes instantly.', color: 'text-orange-600', bg: 'bg-orange-50', border: 'border-orange-100', icon: <Zap className="text-orange-500 h-6 w-6" /> };
  };

  const status = getStatusConfig();

  const handleMapSearch = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!mapSearchQuery.trim()) return;
    setIsSearchingMap(true);
    try {
      const result = await mapService.searchLocation(mapSearchQuery);
      const lines = result.text.split('\n').filter(l => l.includes('|'));
      const parsedResults = lines.map((line, index) => {
        const [name, address] = line.split('|').map(s => s.trim().replace(/^[\*\-\d\.\s]+/, ''));
        const groundingChunk = result.groundingChunks[index] as any;
        const url = groundingChunk?.maps?.uri || `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(name + ' ' + address)}`;
        return { name, address, url };
      });
      setMapResults(parsedResults.length > 0 ? parsedResults : [{ 
        name: mapSearchQuery, 
        address: "Search result from Google Maps", 
        url: `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(mapSearchQuery)}` 
      }]);
    } catch (error) {
      alert("Failed to search maps. Please try again.");
    } finally {
      setIsSearchingMap(false);
    }
  };

  const selectLocation = (loc: {name: string, address: string, url: string}) => {
    setVenue(`${loc.name}, ${loc.address}`);
    setSelectedMapUrl(loc.url);
    setIsMapModalOpen(false);
    setMapResults([]);
    setMapSearchQuery('');
  };

  const addTicketType = () => setTicketTypes([...ticketTypes, { id: Date.now().toString(), name: '', price: 0, quantity: 10, sold: 0 }]);
  const removeTicketType = (id: string) => setTicketTypes(ticketTypes.filter(t => t.id !== id));
  const updateTicketType = (id: string, field: keyof TicketType, value: any) => setTicketTypes(ticketTypes.map(t => t.id === id ? { ...t, [field]: value } : t));

  const filteredCategories = availableCategories.filter(cat => 
    cat.toLowerCase().includes(categorySearch.toLowerCase())
  );

  const addNewCategory = () => {
    const newCat = categorySearch.trim();
    if (newCat && !availableCategories.includes(newCat)) {
      setAvailableCategories(prev => [...prev, newCat]);
      setCategory(newCat);
      setIsCategoryOpen(false);
      setCategorySearch('');
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;
    setIsSubmitting(true);
    
    setLoadingMessage('Optimizing event media...');
    await new Promise(resolve => setTimeout(resolve, 600));

    const payload = {
      organizerId: user.id,
      title,
      description,
      date,
      time,
      venue,
      category,
      bannerImage: bannerUrl || `https://picsum.photos/seed/${title}/1200/600`,
      ticketTypes: ticketTypes as TicketType[],
    };

    setLoadingMessage('Publishing live...');
    if (id) {
      await eventService.update(id, payload);
    } else {
      await eventService.create(payload);
    }

    setIsSubmitting(false);
    setIsSubmitted(true);
    await new Promise(resolve => setTimeout(resolve, 1500));
    navigate('/organizer');
  };

  return (
    <div className="max-w-5xl mx-auto px-4 py-8 md:py-16">
      <div className="mb-8 md:mb-12 flex flex-col md:flex-row md:items-end justify-between gap-6">
        <div>
          <div className="inline-flex items-center gap-2 bg-red-50 text-red-600 px-4 py-1.5 rounded-full text-[10px] font-black uppercase tracking-widest mb-4">
            Organizer Lab
          </div>
          <h1 className="text-3xl md:text-5xl font-black text-gray-900 mb-2 tracking-tight">
            {id ? 'Update Live Event' : 'Launch New Event'}
          </h1>
          <p className="text-gray-500 text-sm md:text-lg">Skip the queue. Your event goes live to thousands of fans instantly.</p>
        </div>
        
        <div className={`px-5 py-4 rounded-3xl flex items-center gap-4 transition-all duration-500 border bg-white ${status.border}`}>
           <div className={`h-12 w-12 rounded-2xl flex items-center justify-center shadow-sm ${status.bg}`}>
              {status.icon}
           </div>
           <div>
              <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Process Status</p>
              <p className={`text-sm font-bold ${status.color}`}>
                {status.label}
              </p>
           </div>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="space-y-8 md:space-y-12 relative">
        {isSubmitted && (
          <div className="fixed inset-0 z-50 bg-white/60 backdrop-blur-sm flex items-center justify-center rounded-[3rem] animate-in fade-in duration-500 p-4">
             <div className="bg-white p-8 md:p-12 rounded-[2.5rem] md:rounded-[3rem] shadow-2xl border border-gray-100 text-center animate-in zoom-in duration-500 w-full max-w-md">
                <div className="bg-green-100 w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-6">
                  <Check className="h-10 w-10 text-green-600" />
                </div>
                <h3 className="text-3xl font-black text-gray-900 mb-2">Success!</h3>
                <p className="text-gray-500 font-medium">Your event is now live and selling. Redirecting...</p>
             </div>
          </div>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 md:gap-12">
          <div className="lg:col-span-2 space-y-8 md:space-y-10">
            <section className="bg-white p-6 md:p-10 rounded-[2rem] md:rounded-[2.5rem] border border-gray-100 shadow-sm space-y-6 md:space-y-8">
              <div className="flex items-center gap-3">
                <div className="bg-red-50 p-2.5 rounded-xl"><ImageIcon className="h-5 w-5 text-red-600" /></div>
                <h2 className="text-xl md:text-2xl font-black text-gray-900">Event Banner</h2>
              </div>
              <div className="space-y-6">
                <div 
                  onClick={() => !isSubmitting && !isOptimizing && fileInputRef.current?.click()}
                  className={`relative group cursor-pointer border-2 border-dashed rounded-[1.5rem] md:rounded-[2rem] p-1 transition-all overflow-hidden ${
                    bannerUrl ? 'border-red-100 bg-red-50/10' : 'border-gray-200 hover:border-red-400 hover:bg-red-50/30'
                  } ${isSubmitting || isOptimizing ? 'opacity-50 cursor-not-allowed' : ''}`}
                >
                  {isOptimizing ? (
                    <div className="aspect-video flex flex-col items-center justify-center py-8 md:py-12">
                       <Loader2 className="h-10 w-10 text-red-600 animate-spin mb-4" />
                       <p className="text-sm font-black text-gray-900 uppercase tracking-widest">Optimizing Experience...</p>
                    </div>
                  ) : bannerUrl ? (
                    <div className="relative aspect-video w-full rounded-[1.3rem] md:rounded-[1.8rem] overflow-hidden">
                      <img src={bannerUrl} alt="Preview" className="w-full h-full object-cover transition-transform group-hover:scale-110 duration-500" />
                      {!isSubmitting && (
                        <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                           <div className="bg-white text-gray-900 px-6 py-3 rounded-2xl font-black text-sm shadow-xl">Change Image</div>
                        </div>
                      )}
                      {!isSubmitting && (
                        <button type="button" onClick={(e) => { e.stopPropagation(); setBannerUrl(''); }} className="absolute top-4 right-4 bg-red-600 text-white p-2 rounded-full shadow-lg hover:bg-red-700 transition-colors z-10"><X className="h-5 w-5" /></button>
                      )}
                    </div>
                  ) : (
                    <div className="aspect-video flex flex-col items-center justify-center py-8 md:py-12">
                      <div className="bg-gray-100 p-6 rounded-[2rem] mb-6 group-hover:bg-red-100 transition-colors"><Upload className="h-8 w-8 text-gray-400 group-hover:text-red-600" /></div>
                      <p className="text-lg md:text-xl font-black text-gray-900 mb-2">Upload Banner</p>
                      <p className="text-xs text-gray-400 font-medium px-4 text-center">1200 x 600px recommended (PNG, JPG)</p>
                    </div>
                  )}
                  <input type="file" ref={fileInputRef} className="hidden" accept="image/*" onChange={handleFileUpload} disabled={isSubmitting || isOptimizing} />
                </div>
                <div className="relative group">
                  <div className="absolute left-5 top-1/2 -translate-y-1/2 text-gray-400 group-focus-within:text-red-500 transition-colors"><LinkIcon className="h-5 w-5" /></div>
                  <input type="url" disabled={isSubmitting} className="w-full pl-14 pr-6 py-4 md:py-5 rounded-2xl bg-gray-50 border-none outline-none focus:ring-4 focus:ring-red-500/10 focus:bg-white transition-all font-bold text-sm disabled:opacity-50" placeholder="Image URL (Alternative)" value={bannerUrl.startsWith('data:') ? '' : bannerUrl} onChange={(e) => setBannerUrl(e.target.value)} />
                </div>
              </div>
            </section>

            <section className="bg-white p-6 md:p-10 rounded-[2rem] md:rounded-[2.5rem] border border-gray-100 shadow-sm space-y-6 md:space-y-8">
              <div className="flex items-center gap-3">
                <div className="bg-red-50 p-2.5 rounded-xl"><Info className="h-5 w-5 text-red-600" /></div>
                <h2 className="text-xl md:text-2xl font-black text-gray-900">Event Details</h2>
              </div>
              <div className="space-y-6">
                <div>
                  <label className="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-3">Event Title</label>
                  <input type="text" required disabled={isSubmitting} className="w-full px-6 py-4 rounded-2xl bg-gray-50 border-none outline-none focus:ring-4 focus:ring-red-500/10 focus:bg-white transition-all font-black text-lg disabled:opacity-50" placeholder="e.g. Nairobi Street Food Festival" value={title} onChange={(e) => setTitle(e.target.value)} />
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-3">Date</label>
                    <div className="relative">
                      <Calendar className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400" />
                      <input type="date" required disabled={isSubmitting} className="w-full pl-12 pr-6 py-4 rounded-2xl bg-gray-50 border-none outline-none focus:ring-4 focus:ring-red-500/10 focus:bg-white transition-all font-bold disabled:opacity-50" value={date} onChange={(e) => setDate(e.target.value)} />
                    </div>
                  </div>
                  <div>
                    <label className="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-3">Time</label>
                    <div className="relative">
                      <Clock className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400" />
                      <input type="time" required disabled={isSubmitting} className="w-full pl-12 pr-6 py-4 rounded-2xl bg-gray-50 border-none outline-none focus:ring-4 focus:ring-red-500/10 focus:bg-white transition-all font-bold disabled:opacity-50" value={time} onChange={(e) => setTime(e.target.value)} />
                    </div>
                  </div>
                </div>
                <div>
                  <div className="flex items-center justify-between mb-3">
                    <label className="block text-[10px] font-black text-gray-400 uppercase tracking-widest">Venue / Exact Location</label>
                    <button type="button" onClick={() => setIsMapModalOpen(true)} className="text-red-600 text-[9px] font-black uppercase tracking-[0.1em] flex items-center gap-1.5 hover:underline"><MapIcon className="h-3 w-3" /> Find Venue</button>
                  </div>
                  <div className="relative group">
                    <div className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400 group-focus-within:text-red-500 transition-colors"><MapPin className="h-5 w-5" /></div>
                    <input type="text" required disabled={isSubmitting} className="w-full pl-12 pr-6 py-4 rounded-2xl bg-gray-50 border-none outline-none focus:ring-4 focus:ring-red-500/10 focus:bg-white transition-all font-bold disabled:opacity-50" placeholder="Venue Name, Area" value={venue} onChange={(e) => setVenue(e.target.value)} />
                    {selectedMapUrl && <a href={selectedMapUrl} target="_blank" rel="noopener noreferrer" className="absolute right-4 top-1/2 -translate-y-1/2 bg-white text-green-600 p-1.5 rounded-lg border border-green-100 shadow-sm hover:bg-green-50 transition-colors flex items-center gap-1.5 text-[9px] font-black uppercase"><ExternalLink className="h-3 w-3" /> Map</a>}
                  </div>
                </div>
                <div className="relative">
                  <div className="flex items-center justify-between mb-3">
                    <label className="block text-[10px] font-black text-gray-400 uppercase tracking-widest">Description</label>
                  </div>
                  <textarea required disabled={isSubmitting} rows={6} className="w-full px-6 py-4 rounded-2xl bg-gray-50 border-none outline-none focus:ring-4 focus:ring-red-500/10 focus:bg-white transition-all font-medium leading-relaxed disabled:opacity-50" placeholder="Tell fans about the experience..." value={description} onChange={(e) => setDescription(e.target.value)}></textarea>
                </div>
              </div>
            </section>
          </div>

          <div className="lg:col-span-1 space-y-8">
             <section className="bg-white p-6 md:p-10 rounded-[2rem] md:rounded-[2.5rem] border border-gray-100 shadow-sm space-y-8">
                <div ref={categoryRef} className="relative">
                  <h3 className="text-xl font-bold text-gray-900 mb-6 flex items-center gap-2">Category</h3>
                  
                  <div className="space-y-3">
                    <label className="block text-[10px] font-black text-gray-400 uppercase tracking-widest ml-1">Selected Type</label>
                    <button 
                      type="button"
                      disabled={isSubmitting}
                      onClick={() => setIsCategoryOpen(!isCategoryOpen)}
                      className="w-full px-5 py-4 bg-gray-50 rounded-2xl border-none outline-none focus:ring-4 focus:ring-red-500/10 focus:bg-white transition-all flex items-center justify-between text-left group disabled:opacity-50"
                    >
                      <span className="font-black text-gray-900">{category}</span>
                      <ChevronDown className={`h-5 w-5 text-gray-400 group-hover:text-red-600 transition-transform duration-300 ${isCategoryOpen ? 'rotate-180' : ''}`} />
                    </button>

                    {isCategoryOpen && (
                      <div className="absolute left-0 right-0 mt-2 bg-white rounded-3xl shadow-2xl border border-gray-100 overflow-hidden z-[50] animate-in slide-in-from-top-2 duration-300">
                        <div className="p-4 border-b border-gray-50">
                          <div className="relative flex items-center">
                            <Search className="absolute left-4 h-4 w-4 text-gray-300" />
                            <input 
                              type="text"
                              autoFocus
                              placeholder="Search or add category..."
                              className="w-full pl-11 pr-4 py-3 bg-gray-50 rounded-xl text-sm font-bold border-none outline-none focus:ring-2 focus:ring-red-500/10 transition-all"
                              value={categorySearch}
                              onChange={(e) => setCategorySearch(e.target.value)}
                            />
                          </div>
                        </div>

                        <div className="max-h-60 overflow-y-auto no-scrollbar py-2">
                          {filteredCategories.length > 0 ? (
                            filteredCategories.map((cat) => (
                              <button
                                key={cat}
                                type="button"
                                onClick={() => { setCategory(cat); setIsCategoryOpen(false); setCategorySearch(''); }}
                                className={`w-full px-6 py-3.5 text-left text-sm font-black tracking-wide transition-colors flex items-center justify-between ${
                                  category === cat ? 'bg-red-50 text-red-600' : 'text-gray-600 hover:bg-gray-50'
                                }`}
                              >
                                {cat}
                                {category === cat && <Check className="h-4 w-4" />}
                              </button>
                            ))
                          ) : categorySearch ? (
                            <div className="px-4 py-4 text-center">
                              <p className="text-xs text-gray-400 font-bold mb-4 italic">No matching categories</p>
                            </div>
                          ) : null}
                          
                          {categorySearch && !availableCategories.some(c => c.toLowerCase() === categorySearch.toLowerCase()) && (
                            <div className="px-4 pt-2 pb-2">
                               <button 
                                type="button"
                                onClick={addNewCategory}
                                className="w-full flex items-center gap-3 p-4 bg-red-600 text-white rounded-2xl font-black text-xs uppercase tracking-widest shadow-lg shadow-red-100 hover:bg-red-700 transition-all active:scale-95"
                               >
                                 <PlusCircle size={16} /> Add "{categorySearch}"
                               </button>
                            </div>
                          )}
                        </div>
                      </div>
                    )}
                  </div>
                </div>
             </section>

             <div className="bg-red-600 p-8 md:p-10 rounded-[2rem] md:rounded-[2.5rem] text-white shadow-2xl shadow-red-100 relative overflow-hidden">
                <div className="relative z-10">
                  <h3 className="text-xl font-black mb-4">{id ? 'Save Updates' : 'Launch Instantly'}</h3>
                  <p className="text-red-100 text-xs md:text-sm leading-relaxed mb-8">No waiting for approval. Your event will be live on the platform as soon as you hit the button below.</p>
                  <div className="space-y-3">
                    <button type="submit" disabled={isSubmitting || isSubmitted || isOptimizing} className={`w-full py-4 rounded-2xl font-black text-lg transition-all flex items-center justify-center gap-3 active:scale-95 shadow-xl ${isSubmitted ? 'bg-green-500 text-white' : isSubmitting || isOptimizing ? 'bg-white/90 text-red-600 cursor-not-allowed' : 'bg-white text-red-600 hover:bg-gray-50'}`}>
                      {isSubmitted ? <CheckCircle2 className="h-6 w-6" /> : isSubmitting || isOptimizing ? <Loader2 className="h-6 w-6 animate-spin" /> : null}
                      {isSubmitted ? 'Success!' : isSubmitting || isOptimizing ? 'Processing...' : (id ? 'Update Live Event' : 'Go Live Now')}
                    </button>
                    {id && (
                      <button type="button" onClick={handleDelete} className="w-full py-3 bg-red-700 hover:bg-red-800 text-white/80 hover:text-white rounded-xl font-black text-xs uppercase tracking-widest flex items-center justify-center gap-2 transition-all">
                        <Trash2 size={16} /> Delete Event
                      </button>
                    )}
                  </div>
                </div>
                {(isSubmitting || isOptimizing) && <div className="absolute bottom-0 left-0 h-1 bg-white animate-progress-indefinite w-full"></div>}
             </div>
          </div>
        </div>

        <section className="bg-white p-6 md:p-10 rounded-[2rem] md:rounded-[2.5rem] border border-gray-100 shadow-sm">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8 md:mb-10">
            <div className="flex items-center gap-3"><div className="bg-red-50 p-2.5 rounded-xl"><Plus className="h-5 w-5 text-red-600" /></div><h2 className="text-xl md:text-2xl font-black text-gray-900">Ticket Tiers</h2></div>
            {!isSubmitting && <button type="button" onClick={addTicketType} className="text-red-600 text-[10px] font-black uppercase tracking-widest flex items-center gap-2 hover:bg-red-50 px-4 py-2.5 rounded-xl transition-all border border-red-100 w-fit">Add Tier</button>}
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {ticketTypes.map((tt) => (
              <div key={tt.id} className="p-6 md:p-8 bg-gray-50 rounded-[1.5rem] md:rounded-[2rem] border border-gray-100 relative group animate-in slide-in-from-bottom-4 duration-300">
                {ticketTypes.length > 1 && !isSubmitting && <button type="button" onClick={() => removeTicketType(tt.id!)} className="absolute top-6 right-6 p-2 text-gray-400 hover:text-red-600 transition-colors"><Trash2 className="h-5 w-5" /></button>}
                <div className={`space-y-6 ${isSubmitting ? 'opacity-50' : ''}`}>
                  <div><label className="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-2">Tier Name</label><input type="text" required disabled={isSubmitting} placeholder="e.g. VIP Backstage" className="w-full px-4 py-3 rounded-xl bg-white border-none outline-none focus:ring-2 focus:ring-red-500 font-bold" value={tt.name} onChange={(e) => updateTicketType(tt.id!, 'name', e.target.value)} /></div>
                  <div className="grid grid-cols-2 gap-4">
                    <div><label className="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-2">Price (KES)</label><input type="number" required disabled={isSubmitting} className="w-full px-4 py-3 rounded-xl bg-white border-none outline-none focus:ring-2 focus:ring-red-500 font-black" value={tt.price} onChange={(e) => updateTicketType(tt.id!, 'price', Number(e.target.value))} /></div>
                    <div><label className="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-2">Total Capacity</label><input type="number" required disabled={isSubmitting} className="w-full px-4 py-3 rounded-xl bg-white border-none outline-none focus:ring-2 focus:ring-red-500 font-black" value={tt.quantity} onChange={(e) => updateTicketType(tt.id!, 'quantity', Number(e.target.value))} /></div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </section>
      </form>

      {/* Map Modal */}
      {isMapModalOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-gray-900/80 backdrop-blur-md" onClick={() => setIsMapModalOpen(false)}></div>
          <div className="relative bg-white w-full max-w-xl rounded-[2rem] md:rounded-[2.5rem] shadow-2xl overflow-hidden animate-in fade-in zoom-in duration-300">
             <div className="p-6 md:p-8 border-b border-gray-100 flex items-center justify-between bg-gray-50/50">
               <div className="flex items-center gap-3"><div className="bg-red-600 p-2.5 rounded-2xl shadow-lg shadow-red-100"><MapIcon className="h-6 w-6 text-white" /></div><div><h2 className="text-xl md:text-2xl font-black text-gray-900 tracking-tight">Venue Finder</h2><p className="text-[10px] text-gray-500 font-black uppercase tracking-widest">Nairobi Hub Connected</p></div></div>
               <button onClick={() => setIsMapModalOpen(false)} className="p-2 md:p-3 bg-white border border-gray-200 hover:bg-red-50 hover:text-red-600 rounded-2xl transition-all"><X className="h-6 w-6" /></button>
             </div>
             <div className="p-6 md:p-8 space-y-6">
                <form onSubmit={handleMapSearch} className="relative group">
                   <div className="absolute left-5 top-1/2 -translate-y-1/2 text-gray-400 group-focus-within:text-red-500 transition-colors"><Search className="h-5 w-5" /></div>
                   <input type="text" placeholder="Search venue..." className="w-full pl-14 pr-24 md:pr-32 py-4 rounded-2xl bg-gray-50 border-none outline-none focus:ring-4 focus:ring-red-500/10 focus:bg-white transition-all font-bold text-sm" value={mapSearchQuery} onChange={(e) => setMapSearchQuery(e.target.value)} autoFocus />
                  <button type="submit" disabled={isSearchingMap || !mapSearchQuery.trim()} className="absolute right-3 top-1/2 -translate-y-1/2 bg-red-600 text-white px-4 md:px-6 py-2 rounded-xl font-black text-[10px] uppercase tracking-widest shadow-lg hover:bg-red-700 disabled:bg-gray-200 disabled:shadow-none transition-all">{isSearchingMap ? <Loader2 className="h-3 w-3 animate-spin" /> : 'Search'}</button>
                </form>
                <div className="max-h-[300px] md:max-h-[350px] overflow-y-auto no-scrollbar space-y-3">
                   {mapResults.length > 0 ? (
                      mapResults.map((res, i) => (
                        <div key={i} onClick={() => selectLocation(res)} className="p-5 bg-white border-2 border-gray-50 rounded-2xl hover:border-red-600 hover:bg-red-50 transition-all cursor-pointer group">
                           <div className="flex justify-between items-start mb-1"><h4 className="font-black text-gray-900 group-hover:text-red-700">{res.name}</h4><MapPin className="h-4 w-4 text-gray-300 group-hover:text-red-600" /></div>
                           <p className="text-xs text-gray-500 font-medium leading-relaxed">{res.address}</p>
                        </div>
                      ))
                   ) : mapSearchQuery && !isSearchingMap ? (
                      <div className="py-12 text-center text-gray-400 font-bold">No results found in Kenya.</div>
                   ) : (
                      <div className="py-12 text-center">
                         <MapIcon className="h-12 w-12 mx-auto text-gray-200 mb-4" />
                         <p className="text-sm font-bold text-gray-400">Search for any venue in Kenya</p>
                      </div>
                   )}
                </div>
             </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default CreateEvent;
