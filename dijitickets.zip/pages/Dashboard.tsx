
import React, { useState, useEffect } from 'react';
import { QRCodeSVG } from 'qrcode.react';
import { 
  Ticket as TicketIcon, MapPin, Calendar, Clock, Download, 
  ExternalLink, QrCode
} from 'lucide-react';
import { authService } from '../services/authService';
import { eventService } from '../services/eventService';
import { DB } from '../db';
import { User, Ticket, Event } from '../types';
import { formatCurrency } from '../constants';

const Dashboard: React.FC = () => {
  const [user, setUser] = useState<User | null>(null);
  const [tickets, setTickets] = useState<(Ticket & { event: Event | undefined })[]>([]);
  const [selectedTicket, setSelectedTicket] = useState<Ticket & { event: Event | undefined } | null>(null);
  
  useEffect(() => {
    const currentUser = authService.getCurrentUser();
    setUser(currentUser);
    if (currentUser) {
      refreshTickets(currentUser.id);
    }
  }, []);

  const refreshTickets = (userId: string) => {
    const userTickets = DB.getTickets().filter(t => t.buyerId === userId);
    const enrichedTickets = userTickets.map(t => ({
      ...t,
      event: eventService.getById(t.eventId)
    }));
    setTickets(enrichedTickets);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-12">
        <div>
          <h1 className="text-4xl font-black text-gray-900 mb-2 tracking-tight">My Tickets</h1>
          <p className="text-gray-500">Welcome back, {user?.name}. Here are your upcoming experiences.</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Ticket List */}
        <div className="lg:col-span-2 space-y-6">
          <h2 className="text-xl font-bold text-gray-900 flex items-center">
            <TicketIcon className="h-5 w-5 mr-2 text-red-600" />
            Active Tickets ({tickets.length})
          </h2>

          {tickets.length > 0 ? (
            <div className="space-y-4">
              {tickets.map(ticket => (
                <div 
                  key={ticket.id}
                  onClick={() => setSelectedTicket(ticket)}
                  className={`bg-white rounded-[2rem] p-6 border-2 transition-all cursor-pointer flex flex-col md:flex-row gap-6 ${
                    selectedTicket?.id === ticket.id ? 'border-red-600 shadow-xl shadow-red-50' : 'border-gray-100 hover:border-gray-200'
                  }`}
                >
                  <div className="w-full md:w-32 h-32 rounded-2xl overflow-hidden bg-gray-100 shrink-0">
                    <img src={ticket.event?.bannerImage} alt="" className="w-full h-full object-cover" />
                  </div>
                  <div className="flex-1">
                    <div className="flex justify-between items-start mb-2">
                      <h3 className="text-xl font-bold text-gray-900">{ticket.event?.title}</h3>
                      <span className="bg-green-50 text-green-600 px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest">
                        {ticket.status}
                      </span>
                    </div>
                    
                    <div className="grid grid-cols-2 gap-4 text-sm text-gray-500 mb-4">
                      <div className="flex items-center">
                        <Calendar className="h-4 w-4 mr-2 text-red-500" />
                        <span>{ticket.event?.date}</span>
                      </div>
                      <div className="flex items-center">
                        <MapPin className="h-4 w-4 mr-2 text-red-500" />
                        <span className="truncate">{ticket.event?.venue}</span>
                      </div>
                    </div>

                    <div className="flex items-center justify-between pt-4 border-t border-gray-50">
                      <span className="text-[10px] font-black text-gray-400 uppercase tracking-widest">ID: {ticket.id}</span>
                      <button className="text-red-600 text-sm font-black flex items-center hover:underline">
                        View QR Code <QrCode className="ml-1.5 h-4 w-4" />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-20 bg-gray-50 rounded-[3rem] border-4 border-dashed border-gray-100">
              <TicketIcon className="h-16 w-16 text-gray-200 mx-auto mb-4" />
              <p className="text-gray-500 font-bold mb-6">You haven't bought any tickets yet.</p>
              <button 
                onClick={() => window.location.hash = '#/'} 
                className="bg-red-600 text-white px-8 py-3 rounded-2xl font-black text-sm shadow-xl shadow-red-100 hover:bg-red-700 transition-all"
              >
                Discover events
              </button>
            </div>
          )}
        </div>

        {/* Selected Ticket / QR Display */}
        <div className="lg:col-span-1">
          {selectedTicket ? (
            <div className="bg-white rounded-[2.5rem] shadow-2xl overflow-hidden border border-gray-100 sticky top-24 animate-in fade-in slide-in-from-right-4 duration-500">
              <div className="bg-red-600 p-10 text-white text-center">
                <div className="bg-white p-6 rounded-3xl inline-block mb-8 shadow-inner qr-code-canvas">
                  <QRCodeSVG value={selectedTicket.qrCode} size={220} />
                </div>
                <h3 className="text-2xl font-black mb-2 tracking-tight">{selectedTicket.event?.title}</h3>
                <p className="text-red-100 text-sm opacity-80 mb-6 font-medium">Scan this at the entrance</p>
                <div className="flex justify-center items-center gap-3 text-xs font-black uppercase tracking-widest">
                   <div className="bg-red-700/50 px-4 py-2 rounded-xl border border-red-500/30">
                     {selectedTicket.event?.date}
                   </div>
                   <div className="bg-red-700/50 px-4 py-2 rounded-xl border border-red-500/30">
                     {selectedTicket.event?.time}
                   </div>
                </div>
              </div>
              <div className="p-10">
                <div className="space-y-5 mb-10">
                  <div className="flex justify-between border-b border-gray-100 pb-3">
                    <span className="text-gray-400 text-[10px] font-black uppercase tracking-widest">Ticket Type</span>
                    <span className="font-bold text-gray-900">General Access</span>
                  </div>
                  <div className="flex justify-between border-b border-gray-100 pb-3">
                    <span className="text-gray-400 text-[10px] font-black uppercase tracking-widest">Price Paid</span>
                    <span className="font-black text-red-600">{formatCurrency(selectedTicket.price)}</span>
                  </div>
                  <div className="flex justify-between border-b border-gray-100 pb-3">
                    <span className="text-gray-400 text-[10px] font-black uppercase tracking-widest">Reference</span>
                    <span className="font-bold text-gray-900">{selectedTicket.id.split('-')[1]}</span>
                  </div>
                </div>
                
                <div className="grid grid-cols-2 gap-4">
                  <button className="flex items-center justify-center gap-2 bg-gray-900 text-white py-4 rounded-2xl font-black text-sm hover:bg-black transition-all active:scale-95">
                    <Download className="h-4 w-4" /> PDF
                  </button>
                  <button className="flex items-center justify-center gap-2 bg-gray-50 text-gray-900 py-4 rounded-2xl font-black text-sm hover:bg-gray-100 border border-gray-200 transition-all active:scale-95">
                    <ExternalLink className="h-4 w-4" /> Details
                  </button>
                </div>
              </div>
              <div className="bg-gray-50 p-6 text-center text-[10px] text-gray-400 font-black uppercase tracking-[0.2em] border-t border-gray-100">
                Official Dijitickets Digital Pass
              </div>
            </div>
          ) : null}
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
