
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Compass, Palmtree, Binoculars, Hotel, ArrowRight, MapPin, Globe } from 'lucide-react';

const DijiExperience: React.FC = () => {
  const navigate = useNavigate();
  const [email, setEmail] = useState('');
  const [subscribed, setSubscribed] = useState(false);

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (email) {
      setSubscribed(true);
      setTimeout(() => setSubscribed(false), 5000);
      setEmail('');
    }
  };

  return (
    <div className="min-h-screen relative bg-gray-900 overflow-hidden flex flex-col">
      {/* Background with Safari/Kenya Theme */}
      <div className="absolute inset-0 z-0">
        <img 
          src="https://images.unsplash.com/photo-1516426122078-c23e76319801?q=80&w=2068&auto=format&fit=crop" 
          alt="Kenyan Safari" 
          className="w-full h-full object-cover opacity-30 scale-105 animate-slow-zoom"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-gray-900 via-gray-900/40 to-gray-900"></div>
      </div>

      <div className="relative z-10 flex-grow flex flex-col items-center justify-center px-4 py-20 text-center">
        <div className="inline-flex items-center gap-2 bg-red-600/10 border border-red-500/20 px-4 py-1.5 rounded-full text-[10px] font-black text-red-500 uppercase tracking-[0.3em] mb-8 animate-in slide-in-from-top-4 duration-700">
          The Future of Kenyan Travel
        </div>

        <h1 className="text-5xl md:text-8xl font-black text-white mb-6 tracking-tighter leading-[0.9] animate-in fade-in zoom-in duration-700">
          Diji<span className="text-red-500">Experience</span>
        </h1>
        
        <p className="text-lg md:text-2xl text-gray-300 max-w-2xl mx-auto mb-12 font-medium leading-relaxed animate-in fade-in slide-in-from-bottom-4 duration-1000">
          Beyond tickets. We're building the ultimate gateway to Kenya's most breathtaking adventures. 
          Coming in 2026.
        </p>

        {/* Subscribe Form */}
        <div className="max-w-md w-full bg-white/5 backdrop-blur-2xl border border-white/10 p-2 rounded-[2.5rem] flex flex-col md:flex-row gap-2 shadow-2xl animate-in fade-in slide-in-from-bottom-12 duration-1000 delay-500">
          {subscribed ? (
            <div className="w-full py-4 px-6 text-green-400 font-black text-sm flex items-center justify-center gap-2">
              You're on the list! We'll alert you first.
            </div>
          ) : (
            <>
              <input 
                type="email" 
                placeholder="Enter your email for early access..." 
                className="flex-1 bg-transparent border-none outline-none text-white px-6 py-4 font-bold text-sm placeholder:text-gray-500"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
              />
              <button 
                onClick={handleSubscribe}
                className="bg-red-600 text-white px-8 py-4 rounded-[2rem] font-black text-sm hover:bg-red-700 transition-all active:scale-95 flex items-center justify-center gap-2"
              >
                Notify Me <ArrowRight size={16} />
              </button>
            </>
          )}
        </div>

        <button 
          onClick={() => navigate('/')}
          className="mt-12 text-gray-500 hover:text-white transition-colors font-black text-[10px] uppercase tracking-[0.2em] flex items-center gap-2"
        >
          Return to Events Hub
        </button>
      </div>

      {/* Decorative Elements */}
      <div className="absolute top-20 left-20 w-64 h-64 bg-red-600/10 rounded-full blur-[100px] pointer-events-none"></div>
      <div className="absolute bottom-20 right-20 w-96 h-96 bg-blue-600/5 rounded-full blur-[120px] pointer-events-none"></div>
      
      <style>{`
        @keyframes slow-zoom {
          0% { transform: scale(1); }
          100% { transform: scale(1.1); }
        }
        .animate-slow-zoom {
          animation: slow-zoom 20s infinite alternate ease-in-out;
        }
      `}</style>
    </div>
  );
};

export default DijiExperience;
