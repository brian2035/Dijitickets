
import React, { useState, useEffect, useRef } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { 
  Calendar, MapPin, Clock, Share2, ShieldCheck, 
  Ticket as TicketIcon, Loader2, CheckCircle2, 
  ArrowLeft, Copy, Check, User, Mail, Smartphone, Heart, Download, QrCode,
  Facebook, Twitter, Instagram, Globe, Bell, X, CalendarPlus, ChevronDown,
  AlertCircle, Receipt
} from 'lucide-react';
import { eventService } from '../services/eventService';
import { authService } from '../services/authService';
import { paymentService } from '../services/paymentService';
import { Event, User as UserType, Ticket } from '../types';
import { formatCurrency } from '../constants';

const EventDetails: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [event, setEvent] = useState<Event | null>(null);
  const [user, setUser] = useState<UserType | null>(null);
  const [selectedTicket, setSelectedTicket] = useState<string | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [paymentSuccess, setPaymentSuccess] = useState(false);
  
  // Waitlist State
  const [isWaitlistModalOpen, setIsWaitlistModalOpen] = useState(false);
  const [waitlistEmail, setWaitlistEmail] = useState('');
  const [waitlistSuccess, setWaitlistSuccess] = useState(false);
  
  // Checkout Fields
  const [mpesaNumber, setMpesaNumber] = useState('');
  const [mpesaError, setMpesaError] = useState<string | null>(null);
  const [guestName, setGuestName] = useState('');
  const [guestEmail, setGuestEmail] = useState('');
  
  const [copied, setCopied] = useState(false);
  const [showCalendarMenu, setShowCalendarMenu] = useState(false);
  const calendarRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const fetchEvent = async () => {
      if (id) {
        try {
          const data = await eventService.getById(id);
          if (data) setEvent(data);
          else navigate('/');
        } catch (err) {
          navigate('/');
        }
      }
    };
    fetchEvent();

    const currentUser = authService.getCurrentUser();
    setUser(currentUser);
    if (currentUser) {
      setWaitlistEmail(currentUser.email);
    }
  }, [id, navigate]);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (calendarRef.current && !calendarRef.current.contains(event.target as Node)) {
        setShowCalendarMenu(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleShare = async () => {
    const shareUrl = `${window.location.origin}${window.location.pathname}#/event/${id}`;
    if (navigator.share) {
      try {
        await navigator.share({
          title: event?.title || 'Dijitickets Event',
          text: `I'm checking out ${event?.title} on Dijitickets. You should come too!`,
          url: shareUrl,
        });
      } catch (err) {
        if ((err as Error).name !== 'AbortError') {
          copyToClipboard(shareUrl);
        }
      }
    } else {
      copyToClipboard(shareUrl);
    }
  };

  const copyToClipboard = async (text: string) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopied(true);
      setTimeout(() => setCopied(false), 3000);
    } catch (err) {
      console.error('Failed to copy: ', err);
    }
  };

  const validateMpesaNumber = (num: string) => {
    const phoneRegex = /^(?:254|\+254|0)?([71][0-9]{8})$/;
    return phoneRegex.test(num);
  };

  const handleMpesaChange = (val: string) => {
    const cleaned = val.replace(/[^0-9]/g, '');
    setMpesaNumber(cleaned);
    if (cleaned && !validateMpesaNumber(cleaned)) {
      setMpesaError('Invalid Kenyan format');
    } else {
      setMpesaError(null);
    }
  };

  const handlePurchase = async () => {
    if (!selectedTicket || !id || !event) return;

    if (!user) {
      if (!guestName || !guestEmail) {
        alert("Please provide your name and email to continue as a guest.");
        return;
      }
    }

    if (!validateMpesaNumber(mpesaNumber)) {
      setMpesaError('Enter a valid M-Pesa number');
      return;
    }

    const currentTicketType = event.ticketTypes.find(t => t.id === selectedTicket);
    const totalPrice = currentTicketType?.price || 0;

    setIsProcessing(true);
    try {
      const ticket = await paymentService.buyTicket(
        user?.id || null, 
        id, 
        selectedTicket, 
        !user ? { name: guestName, email: guestEmail } : undefined,
        mpesaNumber,
        totalPrice
      );

      if (ticket) {
        setPaymentSuccess(true);
        if (user) {
          setTimeout(() => navigate('/dashboard'), 5000);
        }
      } else {
        alert("Payment failed or ticket sold out.");
      }
    } catch (error) {
      alert("An error occurred during payment.");
    } finally {
      setIsProcessing(false);
    }
  };

  const handleWaitlistSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!id || !selectedTicket || !waitlistEmail) return;
    
    const success = await eventService.subscribeToWaitlist(id, selectedTicket, waitlistEmail, user?.id);
    if (success) {
      setWaitlistSuccess(true);
      setTimeout(() => {
        setIsWaitlistModalOpen(false);
        setWaitlistSuccess(false);
      }, 3000);
    } else {
      alert("Subscription failed.");
    }
  };

  if (!event) return null;

  const currentTicketType = event.ticketTypes.find(t => t.id === selectedTicket);
  const isSoldOut = currentTicketType ? currentTicketType.sold >= currentTicketType.quantity : false;
  const totalPrice = currentTicketType?.price || 0;

  return (
    <div className="min-h-screen pb-20 bg-gray-50/50">
      {/* Banner */}
      <div className="relative h-[250px] md:h-[450px] w-full overflow-hidden">
        <img src={event.bannerImage} alt={event.title} className="w-full h-full object-cover" />
        <div className="absolute inset-0 bg-gradient-to-t from-gray-900 via-gray-900/60 to-transparent"></div>
        
        <div className="absolute top-4 md:top-8 left-0 right-0 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex justify-between items-center">
           <button onClick={() => navigate(-1)} className="bg-white/10 hover:bg-white/20 backdrop-blur-xl text-white p-2 md:p-3 rounded-xl md:rounded-2xl transition-all">
              <ArrowLeft className="h-5 w-5 md:h-6 md:w-6" />
           </button>
           <button onClick={handleShare} className={`flex items-center gap-2 px-3 py-2 md:px-6 md:py-3 rounded-xl md:rounded-2xl font-black text-[10px] md:text-sm transition-all backdrop-blur-xl border border-white/20 ${copied ? 'bg-green-600 text-white border-green-500' : 'bg-white/10 hover:bg-white/20 text-white'}`}>
              {copied ? <Check className="h-4 w-4" /> : <Share2 className="h-4 w-4" />}
              <span>{copied ? 'Copied' : 'Share'}</span>
           </button>
        </div>

        <div className="absolute bottom-4 md:bottom-10 left-0 right-0 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-red-600 inline-block px-2 py-0.5 rounded-full text-[8px] md:text-[10px] font-black text-white mb-2 md:mb-6 uppercase tracking-[0.2em] shadow-lg">
            {event.category}
          </div>
          <h1 className="text-xl md:text-6xl font-black text-white mb-3 md:mb-8 leading-tight tracking-tight max-w-4xl drop-shadow-lg">
            {event.title}
          </h1>
          
          <div className="flex flex-wrap gap-4 md:gap-8 text-white/90">
            <div className="flex items-center">
              <Calendar className="h-5 w-5 text-red-400 mr-2" />
              <span className="font-bold text-[10px] md:text-lg">{new Date(event.date).toLocaleDateString('en-GB', { day: 'numeric', month: 'short' })}</span>
            </div>
            <div className="flex items-center">
              <Clock className="h-5 w-5 text-red-400 mr-2" />
              <span className="font-bold text-[10px] md:text-lg">{event.time}</span>
            </div>
            <div className="flex items-center">
              <MapPin className="h-5 w-5 text-red-400 mr-2" />
              <span className="font-bold text-[10px] md:text-lg truncate block max-w-[120px] md:max-w-none">{event.venue}</span>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 md:py-16">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 md:gap-16">
          <div className="lg:col-span-2 space-y-8 md:space-y-10">
            <section>
              <h2 className="text-xl md:text-2xl font-black text-gray-900 mb-6">About this Event</h2>
              <div className="bg-white p-8 rounded-[2.5rem] border border-gray-100 shadow-sm">
                <p className="text-gray-600 leading-relaxed whitespace-pre-line font-medium">{event.description}</p>
              </div>
            </section>

            <section>
              <h2 className="text-xl md:text-2xl font-black text-gray-900 mb-6">Select Tickets</h2>
              <div className="space-y-4">
                {event.ticketTypes.map(tt => {
                  const soldOut = tt.sold >= tt.quantity;
                  return (
                    <div 
                      key={tt.id} 
                      onClick={() => !soldOut && setSelectedTicket(tt.id)}
                      className={`p-6 rounded-3xl border-2 transition-all cursor-pointer flex justify-between items-center ${
                        selectedTicket === tt.id ? 'border-red-600 bg-red-50/30' : soldOut ? 'opacity-50 border-gray-100 bg-gray-50' : 'border-gray-100 bg-white hover:border-gray-200'
                      }`}
                    >
                      <div>
                        <h4 className="font-black text-gray-900 text-lg">{tt.name}</h4>
                        <p className="text-xs text-gray-500 font-bold uppercase tracking-widest">{soldOut ? 'Sold Out' : `${tt.quantity - tt.sold} tickets remaining`}</p>
                      </div>
                      <div className="text-right">
                        <p className="text-xl font-black text-red-600">{formatCurrency(tt.price)}</p>
                        {soldOut && (
                          <button 
                            onClick={(e) => { e.stopPropagation(); setSelectedTicket(tt.id); setIsWaitlistModalOpen(true); }}
                            className="text-[10px] font-black uppercase text-red-600 hover:underline"
                          >
                            Notify Me
                          </button>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </section>
          </div>

          <div className="lg:col-span-1">
             <div className="bg-white p-8 rounded-[2.5rem] border border-gray-100 shadow-2xl sticky top-24">
                <h3 className="text-xl font-black text-gray-900 mb-6">Secure Checkout</h3>
                
                {!user && (
                  <div className="space-y-4 mb-6">
                    <input type="text" placeholder="Full Name" className="w-full px-4 py-3 rounded-xl bg-gray-50 border-none outline-none font-bold text-sm" value={guestName} onChange={(e) => setGuestName(e.target.value)} />
                    <input type="email" placeholder="Email Address" className="w-full px-4 py-3 rounded-xl bg-gray-50 border-none outline-none font-bold text-sm" value={guestEmail} onChange={(e) => setGuestEmail(e.target.value)} />
                  </div>
                )}

                <div className="space-y-4 mb-8">
                  <label className="block text-[10px] font-black text-gray-400 uppercase tracking-widest">M-Pesa Number</label>
                  <div className="relative">
                    <Smartphone className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400" />
                    <input 
                      type="text" 
                      placeholder="07XX XXX XXX" 
                      className={`w-full pl-12 pr-4 py-4 rounded-2xl bg-gray-50 border-none outline-none font-black text-lg ${mpesaError ? 'ring-2 ring-red-500' : 'focus:ring-2 focus:ring-red-600'}`}
                      value={mpesaNumber}
                      onChange={(e) => handleMpesaChange(e.target.value)}
                    />
                  </div>
                  {mpesaError && <p className="text-red-500 text-[10px] font-bold">{mpesaError}</p>}
                </div>

                <div className="space-y-2 mb-8 border-t border-gray-50 pt-6">
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-500 font-medium">Ticket Price</span>
                    <span className="text-gray-900 font-bold">{formatCurrency(totalPrice)}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-500 font-medium">Service Fee</span>
                    <span className="text-gray-900 font-bold">{formatCurrency(0)}</span>
                  </div>
                  <div className="flex justify-between text-lg pt-2 border-t border-gray-50">
                    <span className="font-black text-gray-900">Total</span>
                    <span className="font-black text-red-600">{formatCurrency(totalPrice)}</span>
                  </div>
                </div>

                <button 
                  onClick={handlePurchase}
                  disabled={isProcessing || !selectedTicket || isSoldOut}
                  className="w-full bg-red-600 text-white py-5 rounded-[2rem] font-black text-lg shadow-xl hover:bg-red-700 transition-all active:scale-95 disabled:opacity-50 flex items-center justify-center gap-3"
                >
                  {isProcessing ? <Loader2 className="animate-spin" /> : <ShieldCheck />}
                  {isProcessing ? 'Processing M-Pesa...' : paymentSuccess ? 'Success!' : 'Pay via M-Pesa'}
                </button>
                
                <p className="text-[9px] text-gray-400 text-center mt-6 font-black uppercase tracking-[0.2em]">
                   Powered by Safaricom Daraja API
                </p>
             </div>
          </div>
        </div>
      </div>

      {isWaitlistModalOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/80 backdrop-blur-sm" onClick={() => setIsWaitlistModalOpen(false)}></div>
          <div className="relative bg-white w-full max-w-md rounded-[2.5rem] shadow-2xl p-10 animate-in zoom-in">
             <h3 className="text-2xl font-black text-gray-900 mb-2">Restock Alert</h3>
             <p className="text-gray-500 font-medium mb-8">We'll notify you as soon as more tickets become available.</p>
             <form onSubmit={handleWaitlistSubmit} className="space-y-6">
                <input type="email" required placeholder="your@email.com" className="w-full px-6 py-4 rounded-2xl bg-gray-50 border-none outline-none font-bold" value={waitlistEmail} onChange={(e) => setWaitlistEmail(e.target.value)} />
                <button type="submit" className="w-full bg-red-600 text-white py-4 rounded-2xl font-black text-sm uppercase tracking-widest shadow-xl">
                  {waitlistSuccess ? 'Subscribed!' : 'Notify Me'}
                </button>
             </form>
          </div>
        </div>
      )}

      {paymentSuccess && (
        <div className="fixed inset-0 z-[110] flex items-center justify-center p-4 bg-white/90 backdrop-blur-xl animate-in fade-in duration-500">
          <div className="text-center">
            <div className="bg-green-100 w-24 h-24 rounded-full flex items-center justify-center mx-auto mb-8 animate-in zoom-in duration-700">
               <CheckCircle2 size={64} className="text-green-600" />
            </div>
            <h2 className="text-4xl font-black text-gray-900 mb-4">Payment Successful!</h2>
            <p className="text-gray-500 text-lg font-medium mb-12">Your ticket is now secured. Check your dashboard for the QR code.</p>
            <button 
              onClick={() => navigate('/dashboard')}
              className="bg-red-600 text-white px-12 py-5 rounded-[2rem] font-black text-xl shadow-2xl hover:bg-red-700 transition-all active:scale-95"
            >
              Go to My Tickets
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default EventDetails;
