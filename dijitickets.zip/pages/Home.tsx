
import React, { useState, useEffect, useRef } from 'react';
import { Link } from 'react-router-dom';
import { Search, MapPin, Filter, ArrowRight, Flame, Star, TrendingUp, ChevronRight, Compass } from 'lucide-react';
import { eventService } from '../services/eventService';
import { Event } from '../types';
import EventCard from '../components/EventCard';
import { CATEGORIES, formatCurrency } from '../constants';

const KENYA_COUNTIES = [
  'Mombasa', 'Kwale', 'Kilifi', 'Tana River', 'Lamu', 'Taita–Taveta', 'Garissa', 'Wajir', 'Mandera', 
  'Marsabit', 'Isiolo', 'Meru', 'Tharaka-Nithi', 'Embu', 'Kitui', 'Machakos', 'Makueni', 'Nyandarua', 
  'Nyeri', 'Kirinyaga', 'Murang’a', 'Kiambu', 'Turkana', 'West Pokot', 'Samburu', 'Trans-Nzoia', 
  'Uasin Gishu', 'Elgeyo-Marakwet', 'Nandi', 'Baringo', 'Laikipia', 'Nakuru', 'Narok', 'Kajiado', 
  'Kericho', 'Bomet', 'Kakamega', 'Vihiga', 'Bungoma', 'Busia', 'Siaya', 'Kisumu', 'Homa Bay', 
  'Migori', 'Kisii', 'Nyamira', 'Nairobi City'
];

const Home: React.FC = () => {
  const [events, setEvents] = useState<Event[]>([]);
  const [trending, setTrending] = useState<{ mostPopular: Event[], fastSelling: Event[], topCategories: string[] }>({
    mostPopular: [],
    fastSelling: [],
    topCategories: []
  });
  const [activeTrendingTab, setActiveTrendingTab] = useState<'hot' | 'popular' | 'categories'>('hot');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [selectedLocation, setSelectedLocation] = useState('All Locations (Kenya)');
  const resultsRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    // Fix: Properly await async eventService methods
    const fetchData = async () => {
      const allEvents = await eventService.getAll();
      setEvents(allEvents);
      const trendingData = await eventService.getTrending();
      setTrending(trendingData);
    };
    fetchData();
  }, []);

  const filteredEvents = events.filter(e => {
    const matchesSearch = e.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          e.venue.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          e.description.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesCategory = selectedCategory === 'All' || e.category === selectedCategory;
    
    const matchesLocation = selectedLocation === 'All Locations (Kenya)' || 
                            e.venue.toLowerCase().includes(selectedLocation.toLowerCase()) ||
                            (selectedLocation === 'Nairobi City' && e.venue.toLowerCase().includes('nairobi'));
                            
    return matchesSearch && matchesCategory && matchesLocation;
  });

  const handleFindEvents = () => {
    resultsRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' });
  };

  return (
    <div className="min-h-screen overflow-x-hidden">
      {/* Hero Section */}
      <div className="relative bg-gray-900 pt-16 md:pt-24 pb-24 md:pb-32 overflow-hidden">
        <div className="absolute inset-0 z-0 opacity-40">
          <img 
            src="https://images.unsplash.com/photo-1533174072545-7a4b6ad7a6c3?q=80&w=2070&auto=format&fit=crop" 
            className="w-full h-full object-cover"
            alt="Hero Background"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-gray-900 via-transparent to-transparent"></div>
        </div>

        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl md:text-7xl font-black text-white mb-6 tracking-tight leading-tight">
            Discover What's <span className="text-red-500">Happening</span>
          </h1>
          <p className="text-lg md:text-xl text-gray-300 max-w-2xl mx-auto mb-10 font-medium">
            The easiest way to find and book events in Kenya. Secure your spot at the hottest events instantly.
          </p>

          <div className="max-w-4xl mx-auto bg-white p-2 rounded-2xl md:rounded-full shadow-2xl flex flex-col md:flex-row items-stretch gap-2">
            <div className="flex-1 flex items-center px-5 py-4 rounded-xl md:rounded-full bg-gray-50 md:bg-white">
              <Search className="h-5 w-5 text-red-500 mr-3 shrink-0" />
              <input 
                type="text" 
                placeholder="Search events, concerts..."
                className="w-full bg-transparent outline-none text-gray-900 font-bold placeholder:text-gray-400 placeholder:font-medium text-sm md:text-base"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
            <div className="flex-1 flex items-center px-5 py-4 rounded-xl md:rounded-full bg-gray-50 md:bg-white border-t md:border-t-0 md:border-l border-gray-100">
              <MapPin className="h-5 w-5 text-red-500 mr-3 shrink-0" />
              <select 
                className="w-full bg-transparent outline-none text-gray-900 font-bold appearance-none cursor-pointer text-sm md:text-base"
                value={selectedLocation}
                onChange={(e) => setSelectedLocation(e.target.value)}
              >
                <option>All Locations (Kenya)</option>
                {KENYA_COUNTIES.map(county => (
                  <option key={county} value={county}>{county}</option>
                ))}
              </select>
            </div>
            <button 
              onClick={handleFindEvents}
              className="w-full md:w-auto bg-red-600 text-white px-8 py-4 rounded-xl md:rounded-full font-black text-base md:text-lg hover:bg-red-700 transition-all shadow-xl active:scale-95"
            >
              Find Events
            </button>
          </div>
        </div>
      </div>

      {/* Trending Now Section */}
      <div className="bg-white pt-16 pb-8 border-b border-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-10">
            <div className="flex items-center gap-3">
              <div className="bg-orange-100 p-2.5 rounded-2xl">
                <Flame className="h-6 w-6 text-orange-600 animate-pulse" />
              </div>
              <div>
                <h2 className="text-2xl md:text-3xl font-black text-gray-900 tracking-tight">Trending Now</h2>
                <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Real-time engagement stats</p>
              </div>
            </div>
            
            <div className="flex p-1.5 bg-gray-50 rounded-2xl border border-gray-100 self-start md:self-center">
              {[
                { id: 'hot', label: 'Fast Selling' },
                { id: 'popular', label: 'Top Sold' },
                { id: 'categories', label: 'Top Genres' }
              ].map(tab => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTrendingTab(tab.id as any)}
                  className={`flex items-center gap-2 px-5 py-2.5 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${
                    activeTrendingTab === tab.id 
                      ? 'bg-white text-orange-600 shadow-md ring-1 ring-black/5' 
                      : 'text-gray-400 hover:text-gray-600'
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
            {activeTrendingTab === 'hot' && trending.fastSelling.map((event, idx) => (
              <TrendingCompactCard key={event.id} event={event} rank={idx + 1} badge="HOT" />
            ))}
            {activeTrendingTab === 'popular' && trending.mostPopular.map((event, idx) => (
              <TrendingCompactCard key={event.id} event={event} rank={idx + 1} badge="POPULAR" />
            ))}
            {activeTrendingTab === 'categories' && trending.topCategories.map((cat, idx) => (
              <CategoryCompactCard key={cat} category={cat} rank={idx + 1} onSelect={() => { setSelectedCategory(cat); handleFindEvents(); }} />
            ))}
          </div>
        </div>
      </div>

      {/* Categories Scroller */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-8 relative z-20">
        <div className="bg-white p-3 md:p-4 rounded-2xl shadow-xl flex items-center gap-3 md:gap-4 overflow-x-auto no-scrollbar border border-gray-100">
          <button 
            onClick={() => setSelectedCategory('All')}
            className={`px-6 md:px-8 py-2 md:py-3 rounded-full whitespace-nowrap text-xs md:text-sm font-black transition-all ${selectedCategory === 'All' ? 'bg-red-600 text-white shadow-lg' : 'bg-gray-50 text-gray-500 hover:bg-gray-100'}`}
          >
            All Experiences
          </button>
          {CATEGORIES.map(cat => (
            <button 
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-6 md:px-8 py-2 md:py-3 rounded-full whitespace-nowrap text-xs md:text-sm font-black transition-all ${selectedCategory === cat ? 'bg-red-600 text-white shadow-lg' : 'bg-gray-50 text-gray-500 hover:bg-gray-100'}`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Event Grid */}
      <div ref={resultsRef} className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 md:py-24 scroll-mt-24">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-12">
          <div>
            <h2 className="text-3xl md:text-4xl font-black text-gray-900 mb-2 tracking-tight">
              {searchQuery || selectedCategory !== 'All' || selectedLocation !== 'All Locations (Kenya)' 
                ? 'Search Results' 
                : 'Featured Events'}
            </h2>
            <p className="text-gray-500 font-medium text-sm md:text-base">
              Explore {filteredEvents.length} hand-picked events across Kenya.
            </p>
          </div>
          {(searchQuery || selectedCategory !== 'All' || selectedLocation !== 'All Locations (Kenya)') && (
            <button 
              onClick={() => { setSearchQuery(''); setSelectedCategory('All'); setSelectedLocation('All Locations (Kenya)'); }}
              className="text-red-600 font-black text-sm hover:text-red-700 underline underline-offset-4 decoration-2 text-left"
            >
              Reset all filters
            </button>
          )}
        </div>

        {filteredEvents.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-10">
            {filteredEvents.map(event => (
              <EventCard key={event.id} event={event} />
            ))}
          </div>
        ) : (
          <div className="text-center py-24 bg-gray-50 rounded-[2.5rem] md:rounded-[4rem] border-4 border-dashed border-gray-100">
            <div className="bg-white w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-6 shadow-sm">
              <Search className="h-8 w-8 text-gray-300" />
            </div>
            <h3 className="text-2xl font-black text-gray-900 mb-3 tracking-tight">No results found</h3>
            <p className="text-gray-500 max-w-sm mx-auto font-medium text-sm px-4">
              Try adjusting your search terms or filters. We're constantly adding new experiences!
            </p>
            <button 
              onClick={() => { setSearchQuery(''); setSelectedCategory('All'); setSelectedLocation('All Locations (Kenya)'); }}
              className="mt-8 bg-gray-900 text-white px-8 py-4 rounded-full font-black text-sm hover:bg-black transition-all shadow-xl"
            >
              Clear Search
            </button>
          </div>
        )}
      </div>

      {/* DijiExperience Teaser Section - Placed above Host Your Own Event */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mb-20">
        <Link to="/experience" className="group relative block w-full h-[300px] md:h-[400px] rounded-[3rem] md:rounded-[4rem] overflow-hidden shadow-2xl transition-all duration-500 hover:shadow-red-500/10">
          <img 
            src="https://images.unsplash.com/photo-1516426122078-c23e76319801?q=80&w=2068&auto=format&fit=crop" 
            className="absolute inset-0 w-full h-full object-cover transition-transform duration-1000 group-hover:scale-110"
            alt="DijiExperience Teaser"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-black/90 via-black/40 to-transparent"></div>
          
          <div className="relative h-full flex flex-col justify-center px-8 md:px-20 max-w-3xl">
            <div className="inline-flex items-center gap-2 bg-red-600 text-white px-5 py-2 rounded-full text-[10px] font-black uppercase tracking-[0.3em] mb-6 w-fit shadow-xl">
              Coming Soon
            </div>
            <h2 className="text-4xl md:text-6xl font-black text-white mb-6 tracking-tighter leading-none">
              Diji<span className="text-red-500">Experience</span>
            </h2>
            <p className="text-lg md:text-xl text-gray-200 font-medium leading-relaxed mb-8">
              Explore the magic of Kenya. From luxury coastal retreats to curated wildlife safaris. Your next great adventure begins here.
            </p>
            <div className="flex items-center gap-3 text-white font-black text-sm md:text-base uppercase tracking-widest group-hover:gap-5 transition-all">
              Discover More <ArrowRight size={24} className="text-red-500" />
            </div>
          </div>
        </Link>
      </div>

      {/* CTA Section */}
      <div className="bg-red-600 py-16 md:py-24 overflow-hidden relative">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col lg:flex-row items-center justify-between gap-12 relative z-10">
          <div className="text-white max-w-2xl text-center lg:text-left">
            <h2 className="text-4xl md:text-6xl font-black mb-6 tracking-tight">Host Your Own Event.</h2>
            <p className="text-red-100 text-lg md:text-xl font-medium leading-relaxed">Join thousands of Kenyan organizers. Create your event and get paid instantly via M-Pesa.</p>
          </div>
          <Link to="/signup" className="w-full sm:w-auto bg-white text-red-600 px-10 py-5 rounded-full font-black text-lg md:text-xl shadow-2xl hover:bg-gray-100 transition-all text-center">
            Start Hosting
          </Link>
        </div>
        <div className="absolute top-0 right-0 -translate-y-1/2 translate-x-1/2 w-64 h-64 md:w-96 md:h-96 bg-red-500 rounded-full opacity-30 blur-3xl"></div>
      </div>
    </div>
  );
};

/* Added interface for TrendingCompactCard props to fix TS errors with 'key' */
interface TrendingCompactCardProps {
  event: Event;
  rank: number;
  badge: string;
}

// Updated to React.FC to handle reserved 'key' prop correctly in JSX
const TrendingCompactCard: React.FC<TrendingCompactCardProps> = ({ event, rank, badge }) => {
  const minPrice = Math.min(...event.ticketTypes.map(t => t.price));
  const soldCount = event.ticketTypes.reduce((s, t) => s + t.sold, 0);

  return (
    <Link to={`/event/${event.id}`} className="group relative bg-white border border-gray-100 p-4 rounded-3xl hover:shadow-xl hover:shadow-orange-500/5 transition-all flex gap-4 items-center overflow-hidden">
      <div className="absolute -right-4 -top-4 bg-orange-500/10 text-orange-600 px-6 py-4 rounded-full font-black text-[10px] uppercase rotate-12 opacity-50">
        #{rank}
      </div>
      
      <div className="h-20 w-20 rounded-2xl overflow-hidden shrink-0">
        <img src={event.bannerImage} alt="" className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" />
      </div>
      
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2 mb-1">
          <span className="bg-orange-600 text-white text-[8px] font-black px-1.5 py-0.5 rounded uppercase tracking-widest">{badge}</span>
          <span className="text-[10px] font-bold text-gray-400 truncate">{event.category}</span>
        </div>
        <h3 className="font-black text-gray-900 group-hover:text-orange-600 transition-colors truncate mb-1">{event.title}</h3>
        <p className="text-xs font-black text-orange-600">{formatCurrency(minPrice)}</p>
        <p className="text-[9px] font-bold text-gray-400 mt-1 uppercase tracking-widest">{soldCount} Sold already</p>
      </div>
    </Link>
  );
};

/* Added interface for CategoryCompactCard props to fix TS errors with 'key' */
interface CategoryCompactCardProps {
  category: string;
  rank: number;
  onSelect: () => void;
}

// Updated to React.FC to handle reserved 'key' prop correctly in JSX
const CategoryCompactCard: React.FC<CategoryCompactCardProps> = ({ category, rank, onSelect }) => {
  return (
    <div onClick={onSelect} className="group cursor-pointer bg-white border border-gray-100 p-6 rounded-3xl hover:shadow-xl hover:shadow-red-500/5 transition-all relative overflow-hidden flex flex-col items-center justify-center text-center">
      <div className="absolute top-4 left-4 bg-gray-50 text-gray-400 w-8 h-8 rounded-full flex items-center justify-center font-black text-[10px]">
        #{rank}
      </div>
      <div className="bg-red-50 p-4 rounded-2xl mb-4 group-hover:bg-red-600 group-hover:text-white transition-all">
        <TrendingUp className="h-6 w-6 text-red-600 group-hover:text-white" />
      </div>
      <h3 className="font-black text-gray-900 group-hover:text-red-600 transition-colors uppercase tracking-widest text-xs mb-1">{category}</h3>
      <p className="text-[10px] font-bold text-gray-400">Rising in Popularity</p>
      <div className="mt-4 flex items-center gap-2 text-red-600 font-black text-[9px] uppercase tracking-widest opacity-0 group-hover:opacity-100 transition-opacity">
        Explore <ChevronRight size={12} />
      </div>
    </div>
  );
};

export default Home;
