
import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Search, CreditCard, Ticket, CheckCircle2, PlusCircle, Share2, Wallet, Calendar, Users, BarChart3 } from 'lucide-react';

const HowItWorks: React.FC = () => {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-white">
      {/* Hero Section */}
      <div className="bg-gray-50 py-24 border-b border-gray-100">
        <div className="max-w-7xl mx-auto px-4 text-center">
          <h1 className="text-5xl md:text-7xl font-black text-gray-900 mb-6 tracking-tight">How it <span className="text-red-600">Works</span></h1>
          <p className="text-xl text-gray-500 max-w-2xl mx-auto leading-relaxed font-medium">
            Kenya's simplest and most secure digital ticketing experience. Whether you're a fan or a host, we've got you covered.
          </p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-24 space-y-32">
        {/* For Attendees */}
        <section>
          <div className="flex flex-col md:flex-row items-center gap-16">
            <div className="flex-1">
              <span className="text-xs font-black text-red-600 uppercase tracking-widest bg-red-50 px-4 py-1.5 rounded-full mb-6 inline-block">For Attendees</span>
              <h2 className="text-4xl font-black text-gray-900 mb-8 tracking-tight">Booking your next experience in seconds.</h2>
              
              <div className="space-y-10">
                <div className="flex gap-6">
                  <div className="shrink-0 w-12 h-12 bg-gray-900 text-white rounded-2xl flex items-center justify-center font-black">1</div>
                  <div>
                    <h3 className="text-xl font-bold mb-2">Discover Events</h3>
                    <p className="text-gray-500">Browse through hundreds of concerts, workshops, and festivals happening across Kenya.</p>
                  </div>
                </div>
                <div className="flex gap-6">
                  <div className="shrink-0 w-12 h-12 bg-gray-900 text-white rounded-2xl flex items-center justify-center font-black">2</div>
                  <div>
                    <h3 className="text-xl font-bold mb-2">Secure M-Pesa Payment</h3>
                    <p className="text-gray-500">Enter your number, receive an STK Push, and confirm your payment instantly. No extra paperwork.</p>
                  </div>
                </div>
                <div className="flex gap-6">
                  <div className="shrink-0 w-12 h-12 bg-gray-900 text-white rounded-2xl flex items-center justify-center font-black">3</div>
                  <div>
                    <h3 className="text-xl font-bold mb-2">Digital QR Ticket</h3>
                    <p className="text-gray-500">Your ticket is generated immediately and stored in your dashboard. Just show the QR code at the door.</p>
                  </div>
                </div>
              </div>
            </div>
            <div className="flex-1 bg-red-50 rounded-[3rem] p-12 relative overflow-hidden">
               <div className="relative z-10 grid grid-cols-2 gap-4">
                  <div className="bg-white p-6 rounded-[2rem] shadow-xl">
                    <Search className="text-red-600 mb-4 h-8 w-8" />
                    <p className="font-bold text-sm">Find</p>
                  </div>
                  <div className="bg-white p-6 rounded-[2rem] shadow-xl translate-y-8">
                    <CreditCard className="text-red-600 mb-4 h-8 w-8" />
                    <p className="font-bold text-sm">Pay</p>
                  </div>
                  <div className="bg-white p-6 rounded-[2rem] shadow-xl -translate-x-4 translate-y-4">
                    <Ticket className="text-red-600 mb-4 h-8 w-8" />
                    <p className="font-bold text-sm">Attend</p>
                  </div>
                  <div className="bg-white p-6 rounded-[2rem] shadow-xl translate-x-4 translate-y-12">
                    <CheckCircle2 className="text-red-600 mb-4 h-8 w-8" />
                    <p className="font-bold text-sm">Enjoy</p>
                  </div>
               </div>
            </div>
          </div>
        </section>

        {/* For Organizers */}
        <section>
          <div className="flex flex-col md:flex-row-reverse items-center gap-16">
            <div className="flex-1">
              <span className="text-xs font-black text-blue-600 uppercase tracking-widest bg-blue-50 px-4 py-1.5 rounded-full mb-6 inline-block">For Organizers</span>
              <h2 className="text-4xl font-black text-gray-900 mb-8 tracking-tight">Scale your event with professional tools.</h2>
              
              <div className="space-y-10">
                <div className="flex gap-6">
                  <div className="shrink-0 w-12 h-12 bg-blue-600 text-white rounded-2xl flex items-center justify-center font-black">1</div>
                  <div>
                    <h3 className="text-xl font-bold mb-2">Create & Customize</h3>
                    <p className="text-gray-500">Set up your event page in minutes. Add multiple ticket tiers and beautiful banners.</p>
                  </div>
                </div>
                <div className="flex gap-6">
                  <div className="shrink-0 w-12 h-12 bg-blue-600 text-white rounded-2xl flex items-center justify-center font-black">2</div>
                  <div>
                    <h3 className="text-xl font-bold mb-2">Promote Everywhere</h3>
                    <p className="text-gray-500">Use our built-in sharing tools to reach fans on WhatsApp, Instagram, and Twitter.</p>
                  </div>
                </div>
                <div className="flex gap-6">
                  <div className="shrink-0 w-12 h-12 bg-blue-600 text-white rounded-2xl flex items-center justify-center font-black">3</div>
                  <div>
                    <h3 className="text-xl font-bold mb-2">Instant Payouts</h3>
                    <p className="text-gray-500">Track every sale in real-time. Once the event is over, withdraw your funds directly to M-Pesa.</p>
                  </div>
                </div>
              </div>
            </div>
            <div className="flex-1 bg-gray-900 rounded-[3rem] p-12 text-white overflow-hidden relative">
               <div className="relative z-10 grid grid-cols-1 gap-6">
                  <div className="bg-white/5 backdrop-blur-sm p-6 rounded-[2rem] border border-white/10">
                     <Calendar className="text-blue-400 mb-4 h-8 w-8" />
                     <h4 className="font-black text-lg mb-1">Simple Scheduling</h4>
                     <p className="text-gray-400 text-sm">Set dates, times and multi-day schedules with ease.</p>
                  </div>
                  <div className="bg-white/5 backdrop-blur-sm p-6 rounded-[2rem] border border-white/10">
                     <BarChart3 className="text-green-400 mb-4 h-8 w-8" />
                     <h4 className="font-black text-lg mb-1">Sales Tracking</h4>
                     <p className="text-gray-400 text-sm">Real-time data on ticket sales and revenue generation.</p>
                  </div>
               </div>
            </div>
          </div>
        </section>
      </div>

      {/* Final CTA */}
      <div className="bg-red-600 py-24 text-center text-white px-4">
        <h2 className="text-4xl md:text-5xl font-black mb-8 tracking-tight">Ready to join the movement?</h2>
        <div className="flex flex-col sm:flex-row justify-center gap-4">
           <button 
             onClick={() => navigate('/')}
             className="bg-white text-red-600 px-10 py-5 rounded-[2rem] font-black text-xl shadow-2xl hover:bg-gray-50 transition-all active:scale-95"
           >
             Buy a Ticket
           </button>
           <button 
             onClick={() => navigate('/create-event')}
             className="bg-transparent border-2 border-white text-white px-10 py-5 rounded-[2rem] font-black text-xl hover:bg-white/10 transition-all active:scale-95"
           >
             Host an Event
           </button>
        </div>
      </div>
    </div>
  );
};

export default HowItWorks;
