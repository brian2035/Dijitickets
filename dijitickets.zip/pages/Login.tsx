
import React, { useState, useMemo } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { 
  Mail, User as UserIcon, ArrowRight, Lock, 
  ShieldAlert, ShieldCheck, Check, X, AlertCircle,
  Eye, EyeOff, Key
} from 'lucide-react';
import { authService } from '../services/authService';
import { User, UserRole } from '../types';
import Logo from '../components/Logo';

interface LoginProps {
  onLoginSuccess: (user: User) => void;
}

const Login: React.FC<LoginProps> = ({ onLoginSuccess }) => {
  const navigate = useNavigate();
  const [view, setView] = useState<'login' | 'signup' | 'forgot'>('login');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);

  // Password Complexity Logic
  const passwordCriteria = useMemo(() => {
    return {
      length: password.length >= 8,
      uppercase: /[A-Z]/.test(password),
      lowercase: /[a-z]/.test(password),
      number: /[0-9]/.test(password),
      special: /[!@#$%^&*(),.?":{}|<>]/.test(password),
    };
  }, [password]);

  const strengthScore = useMemo(() => {
    return Object.values(passwordCriteria).filter(Boolean).length;
  }, [passwordCriteria]);

  const isPasswordValid = useMemo(() => {
    return Object.values(passwordCriteria).every(Boolean);
  }, [passwordCriteria]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSuccess(null);

    if (view === 'forgot') {
      setIsLoading(true);
      try {
        const found = await authService.resetPassword(email);
        if (found) {
          setSuccess("Recovery instructions sent! Please check your inbox.");
        } else {
          setError("This email address is not registered in our system.");
        }
      } catch (err) {
        setError("Network error. Please try again.");
      } finally {
        setIsLoading(false);
      }
      return;
    }

    // Validation for Signup
    if (view === 'signup' && !isPasswordValid) {
      setError("Please ensure your password meets all complexity requirements.");
      return;
    }

    setIsLoading(true);
    
    try {
      const user = view === 'login' 
        ? await authService.login(email, password)
        : await authService.signup(name, email, password);

      if (user) {
        onLoginSuccess(user);
        if (user.role === UserRole.ADMIN) {
          navigate('/admin');
        } else {
          navigate('/organizer');
        }
      } else {
        setError("Invalid credentials. Please check your email and password.");
      }
    } catch (err) {
      setError("An unexpected error occurred. Please try again.");
    } finally {
      setIsLoading(false);
    }
  };

  const strengthColor = () => {
    if (strengthScore <= 2) return 'bg-red-500';
    if (strengthScore <= 4) return 'bg-yellow-500';
    return 'bg-green-500';
  };

  const strengthText = () => {
    if (strengthScore <= 2) return 'Weak';
    if (strengthScore <= 4) return 'Moderate';
    return 'Strong';
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-4 bg-gray-50/50 selection:bg-red-100 selection:text-red-900 font-['Bricolage_Grotesque']">
      <div className="max-w-md w-full animate-in fade-in zoom-in duration-500">
        <div className="text-center mb-10">
          <Link to="/" className="flex items-center justify-center mb-8 hover:scale-105 transition-transform duration-300">
            <Logo className="drop-shadow-2xl" />
          </Link>
          <div className="space-y-2">
            <h2 className="text-3xl md:text-4xl font-black text-gray-900 tracking-tight leading-tight">
              {view === 'login' ? 'Welcome Back' : view === 'signup' ? 'Join Dijitickets' : 'Recover Access'}
            </h2>
            <p className="text-gray-500 font-medium px-4">
              {view === 'login' 
                ? 'Login to manage your experiences and ticket sales.' 
                : view === 'signup' 
                ? 'The simplest way to sell tickets in Kenya.' 
                : 'Enter your email and we\'ll send you recovery instructions.'}
            </p>
          </div>
        </div>

        <div className="bg-white rounded-[3rem] shadow-[0_32px_64px_-16px_rgba(0,0,0,0.08)] border border-gray-100 overflow-hidden ring-1 ring-black/[0.02]">
          <div className="p-8 md:p-12">
            {error && (
              <div className="mb-8 p-4 bg-red-50 border border-red-100 rounded-2xl text-red-600 text-sm font-bold animate-in slide-in-from-top-2 flex items-start gap-3">
                <ShieldAlert className="shrink-0 h-5 w-5" />
                <span>{error}</span>
              </div>
            )}

            {success && (
              <div className="mb-8 p-4 bg-green-50 border border-green-100 rounded-2xl text-green-700 text-sm font-bold animate-in slide-in-from-top-2 flex items-start gap-3">
                <ShieldCheck className="shrink-0 h-5 w-5" />
                <span>{success}</span>
              </div>
            )}
            
            <form onSubmit={handleSubmit} className="space-y-6">
              {view === 'signup' && (
                <div className="space-y-2 animate-in slide-in-from-top-4 duration-300">
                  <label className="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-2 ml-1">Company / Brand Name</label>
                  <div className="relative group">
                    <UserIcon className="absolute left-5 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-300 group-focus-within:text-red-500 transition-colors" />
                    <input 
                      type="text" 
                      required
                      placeholder="e.g. Sauti Sol Entertainment"
                      className="w-full pl-14 pr-6 py-4 rounded-2xl bg-gray-50 border-none outline-none focus:ring-4 focus:ring-red-500/10 focus:bg-white transition-all font-bold text-sm"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                    />
                  </div>
                </div>
              )}

              <div className="space-y-2">
                <label className="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1 ml-1">Email Address</label>
                <div className="relative group">
                  <Mail className="absolute left-5 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-300 group-focus-within:text-red-500 transition-colors" />
                  <input 
                    type="email" 
                    required
                    placeholder="name@dijitickets.co.ke"
                    className="w-full pl-14 pr-6 py-4 rounded-2xl bg-gray-50 border-none outline-none focus:ring-4 focus:ring-red-500/10 focus:bg-white transition-all font-bold text-sm"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                  />
                </div>
              </div>

              {view !== 'forgot' && (
                <div className="space-y-2 animate-in slide-in-from-top-4 duration-300">
                  <div className="flex justify-between items-center ml-1">
                    <label className="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1">Secure Password</label>
                    {view === 'login' && (
                      <button 
                        type="button"
                        onClick={() => { setView('forgot'); setError(null); setSuccess(null); }}
                        className="text-[10px] font-black text-red-600 uppercase tracking-widest hover:underline"
                      >
                        Forgot?
                      </button>
                    )}
                  </div>
                  <div className="relative group">
                    <Lock className="absolute left-5 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-300 group-focus-within:text-red-500 transition-colors" />
                    <input 
                      type={showPassword ? "text" : "password"}
                      required
                      placeholder="••••••••"
                      className="w-full pl-14 pr-14 py-4 rounded-2xl bg-gray-50 border-none outline-none focus:ring-4 focus:ring-red-500/10 focus:bg-white transition-all font-bold text-sm"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                    />
                    <button 
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-5 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600 transition-colors"
                    >
                      {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                    </button>
                  </div>
                </div>
              )}

              {view === 'signup' && password.length > 0 && (
                <div className="space-y-4 animate-in fade-in slide-in-from-top-2 duration-300">
                  <div className="space-y-2">
                    <div className="flex justify-between items-center mb-1">
                      <span className="text-[9px] font-black text-gray-400 uppercase tracking-widest">Strength: {strengthText()}</span>
                      <span className="text-[9px] font-black text-gray-400 uppercase tracking-widest">{strengthScore}/5</span>
                    </div>
                    <div className="h-1.5 w-full bg-gray-100 rounded-full overflow-hidden">
                      <div 
                        className={`h-full transition-all duration-500 ${strengthColor()}`}
                        style={{ width: `${(strengthScore / 5) * 100}%` }}
                      ></div>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 gap-2 p-4 bg-gray-50 rounded-2xl border border-gray-100">
                    {[
                      { key: 'length', label: '8+ characters' },
                      { key: 'uppercase', label: 'Uppercase letter' },
                      { key: 'lowercase', label: 'Lowercase letter' },
                      { key: 'number', label: 'Number' },
                      { key: 'special', label: 'Special character' },
                    ].map(req => (
                      <div key={req.key} className="flex items-center gap-2">
                        {passwordCriteria[req.key as keyof typeof passwordCriteria] ? (
                          <div className="bg-green-100 p-0.5 rounded-full"><Check className="h-2.5 w-2.5 text-green-600" /></div>
                        ) : (
                          <div className="bg-gray-200 p-0.5 rounded-full"><X className="h-2.5 w-2.5 text-gray-400" /></div>
                        )}
                        <span className={`text-[10px] font-bold ${passwordCriteria[req.key as keyof typeof passwordCriteria] ? 'text-green-700' : 'text-gray-400'}`}>
                          {req.label}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              <button 
                type="submit"
                disabled={isLoading || (view === 'signup' && !isPasswordValid)}
                className="w-full bg-red-600 hover:bg-red-700 disabled:bg-gray-100 disabled:text-gray-300 text-white py-5 rounded-[2rem] font-black text-lg shadow-2xl shadow-red-500/20 transition-all duration-300 flex items-center justify-center space-x-3 active:scale-95"
              >
                <span>
                  {isLoading 
                    ? 'Processing...' 
                    : (view === 'login' ? 'Sign In' : view === 'signup' ? 'Create My Account' : 'Send Reset Link')}
                </span>
                {view !== 'forgot' && <ArrowRight className="h-6 w-6" />}
              </button>
            </form>

            <div className="mt-10 pt-8 border-t border-gray-50 text-center space-y-4">
              {view === 'forgot' ? (
                <button 
                  onClick={() => { setView('login'); setError(null); setSuccess(null); }}
                  className="group inline-flex items-center gap-2 text-gray-500 text-xs font-black uppercase tracking-widest hover:text-red-600 transition-colors"
                >
                  Return to login
                </button>
              ) : (
                <button 
                  onClick={() => { setView(view === 'login' ? 'signup' : 'login'); setError(null); setSuccess(null); setPassword(''); }}
                  className="group inline-flex items-center gap-2 text-gray-500 text-xs font-black uppercase tracking-widest hover:text-red-600 transition-colors"
                >
                  {view === 'login' ? "Need an account? Signup" : "Already registered? Login"}
                </button>
              )}
            </div>
          </div>
        </div>

        <div className="mt-12 text-center">
          <Link to="/" className="inline-block text-gray-400 text-[10px] font-black uppercase tracking-widest hover:text-red-600 transition-colors py-4">
            ← Return to Experiences
          </Link>
        </div>
      </div>
    </div>
  );
};

export default Login;
