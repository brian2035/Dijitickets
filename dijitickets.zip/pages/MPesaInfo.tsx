
import React from 'react';
import { Smartphone, ShieldCheck, Zap, ArrowRight, CheckCircle2 } from 'lucide-react';

const MPesaInfo: React.FC = () => {
  return (
    <div className="min-h-screen bg-white">
      <div className="max-w-7xl mx-auto px-4 py-24">
        <div className="flex flex-col md:flex-row items-center gap-20">
          <div className="flex-1">
             <div className="bg-[#4CAF50]/10 text-[#4CAF50] inline-block px-4 py-1.5 rounded-full text-xs font-black mb-8 uppercase tracking-widest">Native Integration</div>
             <h1 className="text-5xl md:text-7xl font-black text-gray-900 mb-8 tracking-tight leading-none">The <span className="text-[#4CAF50]">M-Pesa</span> Standard.</h1>
             <p className="text-xl text-gray-500 leading-relaxed font-medium mb-12">
               Dijitickets is built on top of Safaricom's Daraja API, providing a seamless "One-Tap" payment experience for every Kenyan event-goer.
             </p>
             
             <div className="space-y-6">
                <div className="flex items-center gap-4 p-6 bg-gray-50 rounded-[2rem] border border-gray-100">
                   <Zap className="text-[#4CAF50] h-6 w-6" />
                   <span className="font-bold">Instant STK Push for Attendees</span>
                </div>
                <div className="flex items-center gap-4 p-6 bg-gray-50 rounded-[2rem] border border-gray-100">
                   <ShieldCheck className="text-[#4CAF50] h-6 w-6" />
                   <span className="font-bold">Verified Real-Time Transactions</span>
                </div>
                <div className="flex items-center gap-4 p-6 bg-gray-50 rounded-[2rem] border border-gray-100">
                   <Smartphone className="text-[#4CAF50] h-6 w-6" />
                   <span className="font-bold">Automatic Ticket Reconciliation</span>
                </div>
             </div>
          </div>
          <div className="flex-1 w-full">
             <div className="bg-[#4CAF50] rounded-[4rem] p-16 text-white shadow-[0_50px_100px_-20px_rgba(76,175,80,0.3)] relative overflow-hidden">
                <h2 className="text-3xl font-black mb-10 tracking-tight">How we use M-Pesa</h2>
                <div className="space-y-8 relative z-10">
                   <div className="flex gap-6">
                      <div className="shrink-0 w-8 h-8 bg-white text-[#4CAF50] rounded-full flex items-center justify-center font-black">1</div>
                      <p className="font-medium text-lg text-[#E8F5E9]">User selects a ticket and enters their M-Pesa registered phone number.</p>
                   </div>
                   <div className="flex gap-6">
                      <div className="shrink-0 w-8 h-8 bg-white text-[#4CAF50] rounded-full flex items-center justify-center font-black">2</div>
                      <p className="font-medium text-lg text-[#E8F5E9]">User receives an automatic PIN prompt on their mobile device (STK Push).</p>
                   </div>
                   <div className="flex gap-6">
                      <div className="shrink-0 w-8 h-8 bg-white text-[#4CAF50] rounded-full flex items-center justify-center font-black">3</div>
                      <p className="font-medium text-lg text-[#E8F5E9]">Payment is confirmed in milliseconds and the digital ticket is issued instantly.</p>
                   </div>
                </div>
                <div className="mt-16 pt-10 border-t border-white/20 text-center">
                   <p className="text-sm font-black uppercase tracking-widest opacity-80">Powered by Safaricom Daraja API</p>
                </div>
             </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default MPesaInfo;
