
import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from 'recharts';
import { 
  PlusCircle, TrendingUp, Users, Calendar, 
  Share2, Edit3, Trash2,
  ExternalLink, Check,
  Tag, Percent, AlertTriangle, X, Save, RotateCcw, Loader2, Wallet
} from 'lucide-react';
import { authService } from '../services/authService';
import { eventService } from '../services/eventService';
import { Event, User, DashboardStats, TicketType } from '../types';
import { formatCurrency } from '../constants';

const OrganizerDashboard: React.FC = () => {
  const [user, setUser] = useState<User | null>(null);
  const [events, setEvents] = useState<Event[]>([]);
  const [stats, setStats] = useState<DashboardStats>({ totalRevenue: 0, ticketsSold: 0, activeEvents: 0, averageTicketPrice: 0 });
  const [copyStatus, setCopyStatus] = useState<string | null>(null);
  const [eventToDelete, setEventToDelete] = useState<Event | null>(null);
  
  // Inline Editing State
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editForm, setEditForm] = useState<Partial<Event> | null>(null);
  const [isSaving, setIsSaving] = useState(false);

  const calculateStats = (orgEvents: Event[]) => {
    const totalRevenue = orgEvents.reduce((acc, ev) => 
      acc + ev.ticketTypes.reduce((sum, tt) => sum + (tt.sold * tt.price), 0), 0);
    const ticketsSold = orgEvents.reduce((acc, ev) => 
      acc + ev.ticketTypes.reduce((sum, tt) => sum + tt.sold, 0), 0);
    
    setStats({
      totalRevenue,
      ticketsSold,
      activeEvents: orgEvents.filter(e => e.status === 'published' && e.approvalStatus === 'approved').length,
      averageTicketPrice: ticketsSold > 0 ? totalRevenue / ticketsSold : 0
    });
  };

  // Fixed: Made refreshData async to properly await service calls
  const refreshData = async () => {
    const currentUser = authService.getCurrentUser();
    setUser(currentUser);
    if (currentUser) {
      const orgEvents = await eventService.getByOrganizer(currentUser.id);
      setEvents(orgEvents);
      calculateStats(orgEvents);
    }
  };

  useEffect(() => {
    refreshData();
  }, []);

  const confirmDelete = async () => {
    if (eventToDelete) {
      await eventService.delete(eventToDelete.id);
      refreshData();
      setEventToDelete(null);
    }
  };

  const handleShare = async (event: Event) => {
    const shareUrl = `${window.location.origin}${window.location.pathname}#/event/${event.id}`;
    if (navigator.share) {
      try { await navigator.share({ title: event.title, text: `Check out ${event.title} on Dijitickets!`, url: shareUrl }); } catch (err) { if ((err as Error).name !== 'AbortError') copyToClipboard(shareUrl, event.id); }
    } else { copyToClipboard(shareUrl, event.id); }
  };

  const copyToClipboard = async (text: string, id: string) => {
    try { await navigator.clipboard.writeText(text); setCopyStatus(id); setTimeout(() => setCopyStatus(null), 3000); } catch (err) { console.error('Failed to copy: ', err); }
  };

  // Inline Editing Handlers
  const startEditing = (event: Event) => {
    setEditingId(event.id);
    setEditForm({
      title: event.title,
      description: event.description,
      ticketTypes: JSON.parse(JSON.stringify(event.ticketTypes)) // Deep clone for editing
    });
  };

  const cancelEditing = () => {
    setEditingId(null);
    setEditForm(null);
  };

  const saveInlineEdit = async () => {
    if (!editingId || !editForm) return;
    setIsSaving(true);
    try {
      await eventService.update(editingId, editForm);
      refreshData();
      setEditingId(null);
      setEditForm(null);
    } catch (error) {
      alert("Failed to save changes.");
    } finally {
      setIsSaving(false);
    }
  };

  const updateTier = (tierId: string, field: keyof TicketType, value: any) => {
    if (!editForm?.ticketTypes) return;
    const newTiers = editForm.ticketTypes.map(tt => 
      tt.id === tierId ? { ...tt, [field]: value } : tt
    );
    setEditForm({ ...editForm, ticketTypes: newTiers });
  };

  const chartData = events.map(e => ({
    name: e.title.length > 8 ? e.title.substring(0, 8) + '..' : e.title,
    revenue: e.ticketTypes.reduce((sum, tt) => sum + (tt.sold * tt.price), 0),
    fill: '#b40000'
  }));

  const efficiencyData = events.map(e => {
    const sold = e.ticketTypes.reduce((sum, tt) => sum + tt.sold, 0);
    const total = e.ticketTypes.reduce((sum, tt) => sum + tt.quantity, 0);
    return { name: e.title, percent: total > 0 ? (sold / total) * 100 : 0 };
  });

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 md:py-12">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-10 md:mb-14">
        <div>
          <h1 className="text-3xl md:text-5xl font-black text-gray-900 mb-2 tracking-tight">Organizer Hub</h1>
          <p className="text-gray-500 font-medium text-sm md:text-base">Manage your events and ticket sales.</p>
        </div>
        <Link to="/create-event" className="bg-red-600 text-white px-8 py-4 rounded-2xl font-black flex items-center justify-center gap-2 shadow-2xl shadow-red-100 hover:bg-red-700 transition-all w-full md:auto active:scale-95">
          <PlusCircle className="h-5 w-5" />
          <span>New Event</span>
        </Link>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6 mb-10 md:mb-14">
        {[
          { icon: <TrendingUp className="text-red-600" />, label: 'Revenue', value: formatCurrency(stats.totalRevenue), bg: 'bg-red-50' },
          { icon: <Users className="text-blue-600" />, label: 'Sold', value: stats.ticketsSold, bg: 'bg-blue-50' },
          { icon: <Tag className="text-amber-600" />, label: 'Avg Price', value: formatCurrency(stats.averageTicketPrice || 0), bg: 'bg-amber-50' },
          { icon: <Calendar className="text-purple-600" />, label: 'Active', value: stats.activeEvents, bg: 'bg-purple-50' }
        ].map((s, idx) => (
          <div key={idx} className="bg-white p-5 md:p-8 rounded-[1.5rem] md:rounded-[2.5rem] border border-gray-100 shadow-sm transition-all hover:shadow-md">
            <div className={`${s.bg} p-2 md:p-3 rounded-xl inline-block mb-3 md:mb-4`}>{s.icon}</div>
            <h3 className="text-gray-400 text-[9px] md:text-[10px] font-black uppercase tracking-widest mb-1">{s.label}</h3>
            <p className="text-lg md:text-3xl font-black text-gray-900 truncate">{s.value}</p>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 md:gap-12 mb-10 md:mb-14">
        <div className="lg:col-span-2 space-y-8 md:space-y-10">
          <div className="bg-white p-6 md:p-10 rounded-[2rem] md:rounded-[3rem] border border-gray-100 shadow-sm overflow-hidden">
            <h3 className="text-xl font-black text-gray-900 mb-8 flex items-center gap-3">
              <TrendingUp className="h-6 w-6 text-red-600" /> Revenue Breakdown
            </h3>
            <div className="h-[250px] md:h-[350px] w-full -ml-4 md:ml-0">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={chartData} margin={{ left: -10, right: 10 }}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f5f5f5" />
                  <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fill: '#9ca3af', fontSize: 10, fontWait: 700}} dy={10} />
                  <YAxis axisLine={false} tickLine={false} tick={{fill: '#9ca3af', fontSize: 10, fontWeight: 700}} dx={-5} />
                  <Tooltip cursor={{fill: '#fef2f2'}} contentStyle={{borderRadius: '16px', border: 'none', boxShadow: '0 20px 25px -5px rgba(0,0,0,0.1)'}} />
                  <Bar dataKey="revenue" radius={[8, 8, 0, 0]} barSize={28}>
                    {chartData.map((entry, index) => <Cell key={index} fill={entry.fill} />)}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>

          <div className="bg-white p-6 md:p-10 rounded-[2rem] md:rounded-[3rem] border border-gray-100 shadow-sm">
             <div className="flex items-center justify-between mb-8">
                <h3 className="text-xl font-black text-gray-900 flex items-center gap-3">
                  <Percent className="h-6 w-6 text-red-600" /> Sales Efficiency
                </h3>
             </div>
             <div className="space-y-8">
                {efficiencyData.map((data, i) => (
                  <div key={i} className="group">
                    <div className="flex flex-col md:flex-row md:justify-between md:items-end mb-2 gap-1">
                       <span className="text-xs md:text-sm font-black text-gray-900 truncate max-w-full">{data.name}</span>
                       <span className="text-[10px] font-black text-red-600 uppercase tracking-widest">{data.percent.toFixed(1)}% Capacity</span>
                    </div>
                    <div className="w-full h-3 md:h-4 bg-gray-50 rounded-full overflow-hidden border border-gray-100 shadow-inner">
                       <div className={`h-full transition-all duration-1000 ease-out shadow-sm ${data.percent > 80 ? 'bg-red-600' : 'bg-blue-600'}`} style={{ width: `${data.percent}%` }} />
                    </div>
                  </div>
                ))}
             </div>
          </div>
        </div>

        <div className="lg:col-span-1 space-y-8">
           <div className="bg-white p-10 rounded-[2.5rem] md:rounded-[3rem] border border-gray-100 shadow-sm text-center md:text-left">
              <h3 className="text-lg font-black text-gray-900 mb-2">My Payouts</h3>
              <p className="text-gray-500 text-xs font-bold uppercase tracking-widest mb-6">Withdrawable Balance</p>
              <p className="text-4xl font-black text-red-600 mb-8">{formatCurrency(stats.totalRevenue * 0.95)}</p>
              <Link to="/organizer/withdraw" className="w-full py-4 bg-gray-900 text-white rounded-2xl font-black transition-all text-xs uppercase tracking-widest hover:bg-black active:scale-95 flex items-center justify-center gap-2">
                <Wallet size={16} /> Request Withdrawal
              </Link>
              <p className="mt-4 text-[9px] text-gray-400 font-black uppercase tracking-[0.2em]">Processed within 24 hours</p>
           </div>
        </div>
      </div>

      {/* Events List */}
      <div className="mt-16 md:mt-24">
        <div className="flex items-center justify-between mb-8">
           <h2 className="text-2xl md:text-4xl font-black text-gray-900 tracking-tight">Active Events</h2>
           <span className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Total: {events.length}</span>
        </div>
        
        <div className="space-y-6 md:space-y-8">
          {events.map(event => {
            const isEditing = editingId === event.id;
            
            return (
              <div key={event.id} className={`bg-white rounded-[2rem] md:rounded-[3rem] border-2 overflow-hidden flex flex-col md:flex-row transition-all duration-300 ${isEditing ? 'border-red-600 shadow-2xl scale-[1.01]' : 'border-gray-100 hover:shadow-xl'}`}>
                <div className="md:w-64 h-56 md:h-auto overflow-hidden relative group shrink-0">
                  <img src={event.bannerImage} alt="" className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110" />
                  <div className="absolute top-4 left-4">
                    <span className={`px-3 py-1.5 rounded-xl text-[9px] font-black uppercase tracking-widest shadow-lg ${event.status === 'published' ? 'bg-red-600 text-white' : 'bg-white text-gray-900'}`}>{event.status}</span>
                  </div>
                </div>
                
                <div className="flex-1 p-6 md:p-10 flex flex-col justify-between">
                  {isEditing ? (
                    <div className="space-y-6 animate-in fade-in duration-300">
                      <div>
                        <label className="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-2 ml-1">Event Title</label>
                        <input 
                          type="text" 
                          className="w-full px-5 py-3 rounded-xl bg-gray-50 border-2 border-transparent focus:border-red-600/20 focus:bg-white outline-none font-black text-xl transition-all"
                          value={editForm?.title || ''}
                          onChange={(e) => setEditForm({ ...editForm, title: e.target.value })}
                        />
                      </div>
                      <div>
                        <label className="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-2 ml-1">Description</label>
                        <textarea 
                          rows={4}
                          className="w-full px-5 py-3 rounded-xl bg-gray-50 border-2 border-transparent focus:border-red-600/20 focus:bg-white outline-none font-medium text-sm leading-relaxed transition-all"
                          value={editForm?.description || ''}
                          onChange={(e) => setEditForm({ ...editForm, description: e.target.value })}
                        />
                      </div>
                      
                      <div>
                         <label className="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-4 ml-1">Ticket Tiers</label>
                         <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            {editForm?.ticketTypes?.map((tt) => (
                              <div key={tt.id} className="p-4 bg-gray-50 rounded-2xl border border-gray-100 space-y-3">
                                <input 
                                  type="text" 
                                  className="w-full bg-transparent border-none outline-none font-black text-xs uppercase tracking-widest text-red-600"
                                  value={tt.name}
                                  onChange={(e) => updateTier(tt.id, 'name', e.target.value)}
                                />
                                <div className="grid grid-cols-2 gap-3">
                                  <div>
                                    <span className="block text-[8px] font-black text-gray-400 uppercase mb-1">Price (KES)</span>
                                    <input 
                                      type="number"
                                      className="w-full bg-white px-3 py-2 rounded-lg border-none outline-none text-xs font-bold"
                                      value={tt.price}
                                      onChange={(e) => updateTier(tt.id, 'price', Number(e.target.value))}
                                    />
                                  </div>
                                  <div>
                                    <span className="block text-[8px] font-black text-gray-400 uppercase mb-1">Quantity</span>
                                    <input 
                                      type="number"
                                      className="w-full bg-white px-3 py-2 rounded-lg border-none outline-none text-xs font-bold"
                                      value={tt.quantity}
                                      onChange={(e) => updateTier(tt.id, 'quantity', Number(e.target.value))}
                                    />
                                  </div>
                                </div>
                              </div>
                            ))}
                         </div>
                      </div>
                    </div>
                  ) : (
                    <div>
                      <div className="flex flex-col md:flex-row justify-between items-start gap-4 mb-6">
                        <div className="flex-1 min-w-0">
                          <h3 className="text-xl md:text-3xl font-black text-gray-900 leading-tight mb-2 truncate">{event.title}</h3>
                          <div className="flex flex-wrap gap-4 text-[10px] md:text-xs text-gray-400 font-black uppercase tracking-widest">
                             <div className="flex items-center gap-1.5"><Calendar className="h-3.5 w-3.5 text-red-500" /> {event.date}</div>
                             <div className="flex items-center gap-1.5"><Users className="h-3.5 w-3.5 text-red-500" /> {event.ticketTypes.reduce((s,t)=>s+t.sold,0)} Sold</div>
                          </div>
                        </div>
                      </div>
                      
                      <p className="text-gray-500 text-sm font-medium line-clamp-2 mb-6 leading-relaxed">
                        {event.description}
                      </p>
                      
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-6 pt-6 border-t border-gray-50">
                         {event.ticketTypes.slice(0, 4).map(tt => (
                           <div key={tt.id} className="min-w-0">
                              <div className="flex justify-between items-center mb-1.5">
                                <span className="text-[8px] md:text-[9px] font-black text-gray-400 uppercase truncate">{tt.name}</span>
                                <span className="text-[8px] font-black text-red-600">{Math.round((tt.sold/tt.quantity)*100)}%</span>
                              </div>
                              <div className="h-1.5 bg-gray-50 rounded-full w-full overflow-hidden shadow-inner"><div className="h-full bg-red-600 rounded-full transition-all duration-1000" style={{width: `${Math.min(100, (tt.sold/tt.quantity)*100)}%`}}></div></div>
                           </div>
                         ))}
                      </div>
                    </div>
                  )}

                  <div className="mt-8 pt-8 border-t border-gray-50 flex flex-wrap md:flex-nowrap gap-2 md:gap-4">
                    {isEditing ? (
                      <>
                        <button 
                          onClick={saveInlineEdit}
                          disabled={isSaving}
                          className="flex-1 md:flex-none flex items-center justify-center gap-2 px-8 py-3 bg-red-600 text-white rounded-xl font-black text-[10px] uppercase tracking-widest shadow-xl shadow-red-100 hover:bg-red-700 transition-all disabled:opacity-50"
                        >
                          {isSaving ? <Loader2 size={14} className="animate-spin" /> : <Save size={14} />}
                          <span>Save Changes</span>
                        </button>
                        <button 
                          onClick={cancelEditing}
                          disabled={isSaving}
                          className="flex-1 md:flex-none flex items-center justify-center gap-2 px-6 py-3 bg-gray-100 text-gray-500 rounded-xl font-black text-[10px] uppercase tracking-widest hover:bg-gray-200 transition-all disabled:opacity-50"
                        >
                          <RotateCcw size={14} />
                          <span>Cancel</span>
                        </button>
                      </>
                    ) : (
                      <>
                        <button onClick={() => handleShare(event)} className="flex-1 md:flex-none flex items-center justify-center gap-2 px-4 py-3 bg-gray-50 hover:bg-red-50 text-gray-600 hover:text-red-600 rounded-xl transition-all font-black text-[10px] uppercase tracking-widest border border-gray-100">
                          {copyStatus === event.id ? <Check size={14} className="text-green-600" /> : <Share2 size={14} />} 
                          <span className="md:hidden lg:inline">{copyStatus === event.id ? 'Copied' : 'Share'}</span>
                        </button>
                        <button 
                          onClick={() => startEditing(event)} 
                          className="flex-1 md:flex-none flex items-center justify-center gap-2 px-4 py-3 bg-gray-50 hover:bg-blue-50 text-gray-600 hover:text-blue-600 rounded-xl transition-all font-black text-[10px] uppercase tracking-widest border border-gray-100"
                        >
                          <Edit3 size={14} /> <span className="md:hidden lg:inline">Edit</span>
                        </button>
                        <button onClick={() => setEventToDelete(event)} className="flex-1 md:flex-none flex items-center justify-center gap-2 px-4 py-3 bg-gray-50 hover:bg-red-600 hover:text-white rounded-xl transition-all font-black text-[10px] uppercase tracking-widest border border-gray-100">
                          <Trash2 size={14} /> <span className="md:hidden lg:inline">Delete</span>
                        </button>
                        <Link to={`/event/${event.id}`} className="w-full md:w-auto ml-0 md:ml-auto flex items-center justify-center gap-2 px-6 py-3 bg-gray-900 text-white rounded-xl font-black text-[10px] uppercase tracking-widest hover:bg-black transition-all active:scale-95">
                          View Live <ExternalLink size={14} />
                        </Link>
                      </>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
          {events.length === 0 && (
            <div className="py-32 text-center bg-gray-50 rounded-[3rem] border-4 border-dashed border-gray-200">
               <Calendar className="h-16 w-16 text-gray-200 mx-auto mb-6" />
               <p className="text-xl font-black text-gray-400 mb-8">No events hosted yet</p>
               <Link to="/create-event" className="inline-flex items-center gap-2 bg-red-600 text-white px-10 py-4 rounded-2xl font-black hover:bg-red-700 transition-all shadow-xl shadow-red-100 active:scale-95">
                  <PlusCircle size={20} /> Create Your First Event
               </Link>
            </div>
          )}
        </div>
      </div>

      {/* Delete Confirmation Modal */}
      {eventToDelete && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-gray-900/80 backdrop-blur-md animate-in fade-in duration-300" onClick={() => setEventToDelete(null)}></div>
          <div className="relative bg-white w-full max-w-md rounded-[2.5rem] shadow-2xl p-8 md:p-10 text-center animate-in zoom-in duration-300">
            <div className="bg-red-100 w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-6">
              <AlertTriangle className="h-10 w-10 text-red-600" />
            </div>
            <h3 className="text-2xl font-black text-gray-900 mb-2">Delete Event?</h3>
            <p className="text-sm text-gray-500 font-medium mb-8 leading-relaxed">
              Are you sure you want to delete <span className="text-red-600 font-black">"{eventToDelete.title}"</span>? This action is permanent and will cancel all associated tickets.
            </p>
            <div className="space-y-3">
              <button 
                onClick={confirmDelete}
                className="w-full py-4 bg-red-600 text-white rounded-2xl font-black text-sm uppercase tracking-widest hover:bg-red-700 transition-all active:scale-95 shadow-xl shadow-red-100"
              >
                Confirm Delete
              </button>
              <button 
                onClick={() => setEventToDelete(null)}
                className="w-full py-4 bg-gray-100 text-gray-500 rounded-2xl font-black text-sm uppercase tracking-widest hover:bg-gray-200 transition-all"
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default OrganizerDashboard;
