
import React from 'react';
import { useNavigate } from 'react-router-dom';
import { CheckCircle2, Zap, Smartphone, ArrowRight } from 'lucide-react';
import { formatCurrency } from '../constants';

const Pricing: React.FC = () => {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-white">
      <div className="max-w-7xl mx-auto px-4 py-24">
        <div className="text-center mb-24">
          <span className="text-xs font-black text-red-600 uppercase tracking-widest bg-red-50 px-4 py-1.5 rounded-full mb-6 inline-block">Transparent Pricing</span>
          <h1 className="text-5xl md:text-7xl font-black text-gray-900 mb-6 tracking-tight">No Hidden <span className="text-red-600">Fees.</span></h1>
          <p className="text-xl text-gray-500 max-w-2xl mx-auto leading-relaxed font-medium">
            We only win when you win. Simple, fair pricing designed to help Kenyan event organizers grow.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
          <div className="bg-gray-900 rounded-[3rem] p-12 text-white shadow-2xl relative overflow-hidden">
            <div className="relative z-10">
              <div className="bg-red-600 inline-block px-4 py-1.5 rounded-full text-[10px] font-black mb-8 uppercase tracking-widest">Organizers</div>
              <div className="mb-10">
                <span className="text-7xl font-black leading-none">5%</span>
                <span className="text-2xl font-bold text-gray-400"> / per ticket</span>
              </div>
              
              <ul className="space-y-6 mb-12">
                <li className="flex items-center gap-4 font-bold text-lg">
                  <CheckCircle2 className="text-red-500 h-6 w-6" />
                  No monthly subscription fees
                </li>
                <li className="flex items-center gap-4 font-bold text-lg">
                  <CheckCircle2 className="text-red-500 h-6 w-6" />
                  Free for free events
                </li>
                <li className="flex items-center gap-4 font-bold text-lg">
                  <CheckCircle2 className="text-red-500 h-6 w-6" />
                  Instant M-Pesa STK push for buyers
                </li>
                <li className="flex items-center gap-4 font-bold text-lg">
                  <CheckCircle2 className="text-red-500 h-6 w-6" />
                  Full dashboard & analytics access
                </li>
              </ul>

              <button 
                onClick={() => navigate('/create-event')}
                className="w-full bg-white text-gray-900 py-5 rounded-2xl font-black text-xl hover:bg-gray-100 transition-all flex items-center justify-center gap-3 active:scale-95"
              >
                Start Selling Now <ArrowRight />
              </button>
            </div>
            <div className="absolute -bottom-12 -right-12 opacity-5 scale-150 rotate-12">
               <Zap size={300} />
            </div>
          </div>

          <div className="space-y-12">
             <div className="bg-gray-50 p-10 rounded-[2.5rem] border border-gray-100">
                <Smartphone className="text-red-600 h-10 w-10 mb-6" />
                <h3 className="text-2xl font-black text-gray-900 mb-4 tracking-tight">Zero M-Pesa Friction</h3>
                <p className="text-gray-500 leading-relaxed font-medium">
                  We handle all the complex M-Pesa integrations. Your customers pay via a simple STK push, and the 5% commission is automatically deducted during payout.
                </p>
             </div>
             <div className="bg-gray-50 p-10 rounded-[2.5rem] border border-gray-100">
                <Zap className="text-red-600 h-10 w-10 mb-6" />
                <h3 className="text-2xl font-black text-gray-900 mb-4 tracking-tight">Free Marketing Tools</h3>
                <p className="text-gray-500 leading-relaxed font-medium">
                  Every organizer gets access to our Growth Engine, analytics, and social sharing tools at no additional cost. 
                </p>
             </div>
          </div>
        </div>

        <div className="mt-32 pt-20 border-t border-gray-100">
           <h2 className="text-3xl font-black text-gray-900 mb-12 text-center tracking-tight">Frequently Asked Questions</h2>
           <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-sm">
              <div className="bg-white p-8 rounded-3xl border border-gray-100">
                 <h4 className="font-black text-gray-900 mb-3">When do I get paid?</h4>
                 <p className="text-gray-500 leading-relaxed">Payouts are initiated 24-48 hours after your event has successfully concluded.</p>
              </div>
              <div className="bg-white p-8 rounded-3xl border border-gray-100">
                 <h4 className="font-black text-gray-900 mb-3">What if my event is free?</h4>
                 <p className="text-gray-500 leading-relaxed">If your event is free, Dijitickets is 100% free for you and your attendees!</p>
              </div>
              <div className="bg-white p-8 rounded-3xl border border-gray-100">
                 <h4 className="font-black text-gray-900 mb-3">Are there tax implications?</h4>
                 <p className="text-gray-500 leading-relaxed">You are responsible for any KRA taxes applicable to your event income. Our 5% fee is inclusive of VAT.</p>
              </div>
           </div>
        </div>
      </div>
    </div>
  );
};

export default Pricing;
