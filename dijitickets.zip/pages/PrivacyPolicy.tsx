
import React from 'react';
import { Shield, Mail, Lock, FileText, Globe, Cookie } from 'lucide-react';

const PrivacyPolicy: React.FC = () => {
  return (
    <div className="min-h-screen bg-white pb-24">
      {/* Header Section */}
      <div className="bg-gray-50 py-20 border-b border-gray-100 mb-16">
        <div className="max-w-4xl mx-auto px-4 text-center">
          <div className="bg-red-100 text-red-600 inline-block px-4 py-1.5 rounded-full text-[10px] font-black uppercase tracking-[0.2em] mb-6 shadow-sm">
            Legal & Compliance
          </div>
          <h1 className="text-5xl md:text-6xl font-black text-gray-900 mb-4 tracking-tight">Privacy Policy</h1>
          <p className="text-gray-500 font-bold uppercase text-[10px] tracking-widest">Last updated: October 2024</p>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4">
        <div className="prose prose-lg prose-red text-gray-600 space-y-16 font-medium leading-relaxed">
          
          <section className="bg-red-50/30 p-8 rounded-[2rem] border border-red-50">
            <h2 className="text-2xl font-black text-gray-900 mb-4 flex items-center gap-3">
              <Shield className="h-6 w-6 text-red-600" />
              1. Introduction
            </h2>
            <p>
              Dijitickets Limited ("we," "us," or "our") respects your privacy and is committed to protecting your personal data. 
              This Privacy Policy outlines how we collect, use, store, and share your information when you visit our website, use our mobile application, or purchase a ticket through our platform.
            </p>
            <p className="font-bold text-gray-900 mt-4 text-sm bg-white/50 p-4 rounded-xl border border-red-100">
              This policy is drafted in compliance with the Constitution of Kenya (2010) and the Data Protection Act, 2019.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-black text-gray-900 mb-6 flex items-center gap-3">
              <FileText className="h-6 w-6 text-red-600" />
              2. Information We Collect
            </h2>
            <p className="mb-4">We collect specific data to facilitate ticket sales and secure event entry. This includes:</p>
            <ul className="space-y-4 list-none pl-0">
              <li className="flex gap-4">
                <div className="h-2 w-2 bg-red-600 rounded-full mt-2.5 shrink-0"></div>
                <div><strong className="text-gray-900">Personal Identity Data:</strong> Name, Phone Number, and Email Address.</div>
              </li>
              <li className="flex gap-4">
                <div className="h-2 w-2 bg-red-600 rounded-full mt-2.5 shrink-0"></div>
                <div><strong className="text-gray-900">Transaction Data:</strong> Details of the tickets you bought, the amount paid, and the payment method (e.g., M-Pesa Transaction Code). <span className="text-red-600 font-bold italic">Note: We do NOT store your full Credit Card numbers or M-Pesa PINs.</span></div>
              </li>
              <li className="flex gap-4">
                <div className="h-2 w-2 bg-red-600 rounded-full mt-2.5 shrink-0"></div>
                <div><strong className="text-gray-900">Technical Data:</strong> IP address, browser type, and device information used to access our platform (for fraud detection).</div>
              </li>
              <li className="flex gap-4">
                <div className="h-2 w-2 bg-red-600 rounded-full mt-2.5 shrink-0"></div>
                <div><strong className="text-gray-900">Event Usage Data:</strong> Information on when your ticket was scanned at a gate.</div>
              </li>
            </ul>
          </section>

          <section>
            <h2 className="text-2xl font-black text-gray-900 mb-6 flex items-center gap-3">
              <Globe className="h-6 w-6 text-red-600" />
              3. How We Use Your Data
            </h2>
            <p className="mb-4">We process your personal data for the following specific purposes:</p>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-6">
              <div className="p-5 bg-gray-50 rounded-2xl border border-gray-100">
                <h4 className="text-sm font-black text-gray-900 uppercase mb-2">1. Ticket Delivery</h4>
                <p className="text-sm">To generate your unique QR code and send it to you via SMS or Email.</p>
              </div>
              <div className="p-5 bg-gray-50 rounded-2xl border border-gray-100">
                <h4 className="text-sm font-black text-gray-900 uppercase mb-2">2. Event Management</h4>
                <p className="text-sm">To provide the Event Organizer with a guest list for entry verification and security.</p>
              </div>
              <div className="p-5 bg-gray-50 rounded-2xl border border-gray-100">
                <h4 className="text-sm font-black text-gray-900 uppercase mb-2">3. Customer Support</h4>
                <p className="text-sm">To resolve issues regarding lost tickets or payment failures.</p>
              </div>
              <div className="p-5 bg-gray-50 rounded-2xl border border-gray-100">
                <h4 className="text-sm font-black text-gray-900 uppercase mb-2">4. Communication</h4>
                <p className="text-sm">To send you critical event updates (e.g., "Event Postponed" or "Venue Changed").</p>
              </div>
              <div className="p-5 bg-gray-50 rounded-2xl border border-gray-100 md:col-span-2">
                <h4 className="text-sm font-black text-gray-900 uppercase mb-2">5. Legal Compliance</h4>
                <p className="text-sm">To comply with tax laws (KRA) and record-keeping regulations.</p>
              </div>
            </div>
          </section>

          <section>
            <h2 className="text-2xl font-black text-gray-900 mb-6 flex items-center gap-3">
              <Lock className="h-6 w-6 text-red-600" />
              4. Sharing of Your Data
            </h2>
            <p className="mb-6">We do not sell your personal data to advertisers. However, we share necessary data with the following parties:</p>
            <div className="space-y-6">
              <div className="flex gap-4 items-start">
                <div className="bg-red-50 p-2 rounded-lg text-red-600 font-black text-xs">A</div>
                <p><strong className="text-gray-900">The Event Organizer:</strong> When you buy a ticket, we share your Name and Email with the organizer of that specific event so they can manage the gate and logistics.</p>
              </div>
              <div className="flex gap-4 items-start">
                <div className="bg-red-50 p-2 rounded-lg text-red-600 font-black text-xs">B</div>
                <p><strong className="text-gray-900">Payment Processors:</strong> We share transaction data with Safaricom (M-Pesa) or our Card Payment Gateways to process your payment securely.</p>
              </div>
              <div className="flex gap-4 items-start">
                <div className="bg-red-50 p-2 rounded-lg text-red-600 font-black text-xs">C</div>
                <p><strong className="text-gray-900">Law Enforcement:</strong> We may disclose data if required by a court order or to prevent fraud/criminal activity at an event.</p>
              </div>
            </div>
          </section>

          <section>
            <h2 className="text-2xl font-black text-gray-900 mb-4">5. Data Retention</h2>
            <ul className="list-disc pl-6 space-y-3">
              <li><strong className="text-gray-900">General:</strong> We retain your personal data only as long as necessary to fulfil the purposes for which it was collected.</li>
              <li><strong className="text-gray-900">Financial Records:</strong> Transaction data is kept for a minimum of <span className="text-red-600">seven (7) years</span> as required by Kenyan Tax Laws.</li>
              <li><strong className="text-gray-900">Unsuccessful Events:</strong> If an event is canceled, we retain data to facilitate refunds before archiving it.</li>
            </ul>
          </section>

          <section className="bg-gray-900 text-white p-10 rounded-[3rem] shadow-2xl">
            <h2 className="text-2xl font-black mb-6">6. Your Rights (Under Kenyan Law)</h2>
            <p className="text-gray-400 mb-8">As a user, the Data Protection Act grants you the following rights:</p>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <h4 className="font-black text-red-500 uppercase text-[10px] tracking-widest mb-1">Right to Access</h4>
                <p className="text-sm opacity-80">You can ask us for a copy of the personal data we hold about you.</p>
              </div>
              <div>
                <h4 className="font-black text-red-500 uppercase text-[10px] tracking-widest mb-1">Right to Rectification</h4>
                <p className="text-sm opacity-80">You can ask us to correct wrong details (e.g., a misspelled email).</p>
              </div>
              <div>
                <h4 className="font-black text-red-500 uppercase text-[10px] tracking-widest mb-1">Right to Erasure</h4>
                <p className="text-sm opacity-80">You can ask us to delete your data, provided it is no longer needed for tax or legal purposes.</p>
              </div>
              <div>
                <h4 className="font-black text-red-500 uppercase text-[10px] tracking-widest mb-1">Right to Object</h4>
                <p className="text-sm opacity-80">You may opt-out of receiving marketing emails from us at any time.</p>
              </div>
            </div>
          </section>

          <section>
            <h2 className="text-2xl font-black text-gray-900 mb-4">7. Data Security</h2>
            <p>
              We have implemented appropriate security measures to prevent your personal data from being accidentally lost, used, or accessed in an unauthorized way. 
              All data transmission is encrypted via <strong>SSL (Secure Socket Layer)</strong> technology. Access to our backend database is restricted to authorized employees and technical staff only.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-black text-gray-900 mb-4">8. International Transfers</h2>
            <p>
              Some of our cloud storage providers may be located outside Kenya. In such cases, we ensure that your data is protected by strict international privacy standards equivalent to those in Kenya.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-black text-gray-900 mb-4 flex items-center gap-3">
              <Cookie className="h-6 w-6 text-red-600" />
              9. Cookies
            </h2>
            <p>
              Our website uses cookies to improve your experience (e.g., remembering your cart contents). You can choose to disable cookies in your browser settings, though some parts of the site may not function properly.
            </p>
          </section>

          <section className="pt-12 border-t border-gray-100">
            <h2 className="text-2xl font-black text-gray-900 mb-8 flex items-center gap-3">
              <Mail className="h-6 w-6 text-red-600" />
              10. Contact Us
            </h2>
            <p className="mb-8">
              If you have questions about this privacy policy or wish to exercise your rights, please contact our Data Protection Officer (DPO):
            </p>
            <div className="bg-gray-50 p-8 rounded-[2rem] border border-gray-100 flex flex-col md:flex-row md:items-center justify-between gap-6">
              <div>
                <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1">DPO Email</p>
                <a href="mailto:privacy@dijitickets.co.ke" className="text-xl font-black text-red-600 hover:underline">
                  privacy@dijitickets.co.ke
                </a>
              </div>
              <button className="bg-gray-900 text-white px-8 py-4 rounded-2xl font-black text-sm hover:bg-black transition-all">
                Contact DPO
              </button>
            </div>
          </section>
        </div>
      </div>
    </div>
  );
};

export default PrivacyPolicy;
