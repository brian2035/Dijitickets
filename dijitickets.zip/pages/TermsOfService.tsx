
import React from 'react';
import { Scale, Info, AlertTriangle, Gavel, ShieldCheck, Ticket, Calendar, AlertCircle } from 'lucide-react';

const TermsOfService: React.FC = () => {
  return (
    <div className="min-h-screen bg-white pb-24">
      {/* Header Section */}
      <div className="bg-gray-50 py-20 border-b border-gray-100 mb-16">
        <div className="max-w-4xl mx-auto px-4 text-center">
          <div className="bg-gray-200 text-gray-700 inline-block px-4 py-1.5 rounded-full text-[10px] font-black uppercase tracking-[0.2em] mb-6 shadow-sm">
            Legal Framework
          </div>
          <h1 className="text-5xl md:text-6xl font-black text-gray-900 mb-4 tracking-tight">Terms & Conditions</h1>
          <p className="text-gray-500 font-medium text-lg max-w-2xl mx-auto">
            Please read these terms carefully. By using our platform, you agree to the binding agreement outlined below.
          </p>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4">
        <div className="space-y-16">
          
          {/* 1. Introduction */}
          <section className="prose prose-lg max-w-none">
            <h2 className="text-2xl font-black text-gray-900 mb-6 flex items-center gap-3">
              <Scale className="h-6 w-6 text-red-600" />
              1. Introduction
            </h2>
            <p className="text-gray-600 font-medium leading-relaxed">
              These Terms and Conditions ("Terms") govern the sale of tickets through the Dijitickets platform (website, mobile application, and USSD services). By purchasing a ticket, you (the "Customer") agree to be bound by these Terms.
            </p>
          </section>

          {/* 2. Critical Role Callout */}
          <section className="bg-gray-900 text-white p-10 rounded-[3rem] shadow-2xl relative overflow-hidden">
            <div className="relative z-10">
              <h2 className="text-2xl font-black mb-6 flex items-center gap-3">
                <Info className="h-6 w-6 text-red-500" />
                2. The Role of Dijitickets
              </h2>
              <p className="text-gray-300 font-medium mb-8 leading-relaxed">
                It is critically important that you understand our role in the ticketing ecosystem:
              </p>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div className="bg-white/5 border border-white/10 p-6 rounded-2xl">
                  <h4 className="text-red-500 font-black text-xs uppercase tracking-widest mb-2">We are an Agent</h4>
                  <p className="text-sm text-gray-400">Dijitickets acts solely as a booking agent for the Event Organizer (Promoter/Venue). We do not organize, produce, or control the events.</p>
                </div>
                <div className="bg-white/5 border border-white/10 p-6 rounded-2xl">
                  <h4 className="text-red-500 font-black text-xs uppercase tracking-widest mb-2">The Contract</h4>
                  <p className="text-sm text-gray-400">When you buy a ticket, the legal contract is between You and the Event Organizer. We are responsible only for the technical processing and delivery.</p>
                </div>
              </div>
            </div>
            <div className="absolute -right-10 -bottom-10 opacity-10">
              <Gavel size={240} />
            </div>
          </section>

          {/* 3. Ticket Purchase & Payment */}
          <section>
            <h2 className="text-2xl font-black text-gray-900 mb-8 flex items-center gap-3">
              <Ticket className="h-6 w-6 text-red-600" />
              3. Ticket Purchase & Payment
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {[
                { title: "Currency", desc: "All prices are displayed in Kenyan Shillings (KES) unless stated otherwise." },
                { title: "Payment Methods", desc: "We accept M-Pesa and Credit/Debit Cards. Payment is due immediately upon booking." },
                { title: "Confirmation", desc: "The sale is final only when you receive an SMS/Email with your unique QR Code." },
                { title: "Pricing Errors", desc: "We reserve the right to cancel orders and refund if a technical error occurs in pricing." }
              ].map((item, i) => (
                <div key={i} className="p-6 bg-gray-50 rounded-2xl border border-gray-100">
                  <h4 className="font-black text-gray-900 mb-2">{item.title}</h4>
                  <p className="text-sm text-gray-500 font-medium leading-relaxed">{item.desc}</p>
                </div>
              ))}
            </div>
          </section>

          {/* 4. Refunds & Cancellations */}
          <section className="bg-red-50 p-10 rounded-[3rem] border border-red-100">
            <h2 className="text-2xl font-black text-gray-900 mb-6 flex items-center gap-3">
              <AlertTriangle className="h-6 w-6 text-red-600" />
              4. Refunds, Cancellations & Postponements
            </h2>
            <p className="text-gray-700 font-bold mb-8 italic">All ticket sales are final. Refunds are governed by the following strict rules:</p>
            <div className="space-y-6">
              <div className="flex gap-4">
                <div className="h-6 w-6 bg-red-600 text-white rounded-full flex items-center justify-center text-[10px] font-black shrink-0">!</div>
                <p className="text-sm text-gray-600 font-medium"><strong className="text-gray-900">Change of Mind:</strong> We do not offer refunds if you change your mind, get sick, or cannot attend for personal reasons.</p>
              </div>
              <div className="flex gap-4">
                <div className="h-6 w-6 bg-red-600 text-white rounded-full flex items-center justify-center text-[10px] font-black shrink-0">!</div>
                <p className="text-sm text-gray-600 font-medium"><strong className="text-gray-900">Event Cancellation:</strong> If canceled by the Organizer, a refund is issued ONLY if the Organizer releases funds to Dijitickets. We are not liable if the Organizer becomes insolvent.</p>
              </div>
              <div className="flex gap-4">
                <div className="h-6 w-6 bg-red-600 text-white rounded-full flex items-center justify-center text-[10px] font-black shrink-0">!</div>
                <p className="text-sm text-gray-600 font-medium"><strong className="text-gray-900">Postponement:</strong> Tickets are usually valid for the new date. Refunds are at the sole discretion of the Event Organizer.</p>
              </div>
              <div className="flex gap-4">
                <div className="h-6 w-6 bg-red-600 text-white rounded-full flex items-center justify-center text-[10px] font-black shrink-0">!</div>
                <p className="text-sm text-gray-600 font-medium"><strong className="text-gray-900">Booking Fees:</strong> In any refund scenario, the "Service Fee" or "Booking Fee" is non-refundable as it covers transaction costs.</p>
              </div>
            </div>
          </section>

          {/* 5. Entry & Validity */}
          <section>
            <h2 className="text-2xl font-black text-gray-900 mb-8 flex items-center gap-3">
              <ShieldCheck className="h-6 w-6 text-red-600" />
              5. Entry & Validity
            </h2>
            <div className="space-y-8">
              <div className="flex items-start gap-6">
                <div className="bg-gray-100 p-4 rounded-2xl"><Ticket className="h-6 w-6 text-gray-400" /></div>
                <div>
                  <h4 className="font-black text-gray-900 mb-1">QR Code Security</h4>
                  <p className="text-sm text-gray-500 font-medium leading-relaxed">Your ticket contains a unique QR Code that can only be scanned once. Duplicate presentations will be rejected. <span className="text-red-600 font-black">Never post your QR code on social media.</span></p>
                </div>
              </div>
              <div className="flex items-start gap-6">
                <div className="bg-gray-100 p-4 rounded-2xl"><AlertCircle className="h-6 w-6 text-gray-400" /></div>
                <div>
                  <h4 className="font-black text-gray-900 mb-1">Right of Admission</h4>
                  <p className="text-sm text-gray-500 font-medium leading-relaxed">Organizers reserve the Right of Admission. We cannot guarantee entry if you are denied due to intoxication, behavior, or venue rules.</p>
                </div>
              </div>
            </div>
          </section>

          {/* 6 & 7. Changes & Liability */}
          <section className="grid grid-cols-1 md:grid-cols-2 gap-12">
            <div>
              <h2 className="text-2xl font-black text-gray-900 mb-6 flex items-center gap-3">
                <Calendar className="h-6 w-6 text-red-600" />
                6. Event Changes
              </h2>
              <p className="text-sm text-gray-500 font-medium leading-relaxed">
                The Event Organizer reserves the right to make reasonable changes to the lineup, venue, or schedule. Such changes do not entitle the Customer to a refund.
              </p>
            </div>
            <div>
              <h2 className="text-2xl font-black text-gray-900 mb-6 flex items-center gap-3">
                <Gavel className="h-6 w-6 text-red-600" />
                7. Limitation of Liability
              </h2>
              <p className="text-sm text-gray-500 font-medium leading-relaxed mb-4">
                To the fullest extent permitted by Kenyan Law, Dijitickets is not responsible for event quality, venue safety, or attendee behavior.
              </p>
              <div className="bg-gray-900 text-white p-6 rounded-2xl text-[11px] font-bold leading-relaxed">
                <span className="text-red-500 font-black uppercase tracking-widest block mb-2">Force Majeure</span>
                We are not liable for failures due to causes beyond our control, including acts of God, political unrest (Maandamano), ISP failures, or government restrictions.
              </div>
            </div>
          </section>

          {/* 8 & 9. Privacy & Law */}
          <section className="border-t border-gray-100 pt-16">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
              <div>
                <h2 className="text-xl font-black text-gray-900 mb-4">8. Data Privacy</h2>
                <p className="text-sm text-gray-500 font-medium leading-relaxed">
                  By purchasing a ticket, you consent to your data being processed in accordance with the <strong>Data Protection Act, 2019</strong>. We share details with Organizers for guest list management only.
                </p>
              </div>
              <div>
                <h2 className="text-xl font-black text-gray-900 mb-4">9. Governing Law</h2>
                <p className="text-sm text-gray-500 font-medium leading-relaxed">
                  These Terms shall be governed by the Laws of Kenya. Any disputes shall be subject to the exclusive jurisdiction of the courts located in <strong>Nairobi</strong>.
                </p>
              </div>
            </div>
          </section>

        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 mt-24 text-center">
        <div className="bg-gray-50 p-12 rounded-[3rem] border border-gray-100">
          <p className="text-gray-400 font-black text-xs uppercase tracking-[0.2em] mb-4">Official Agreement</p>
          <p className="text-gray-900 font-bold mb-8">Have questions regarding these terms?</p>
          <a href="mailto:info@dijitickets.co.ke" className="bg-gray-900 text-white px-10 py-4 rounded-2xl font-black text-sm hover:bg-black transition-all">
            Contact Legal Dept
          </a>
        </div>
      </div>
    </div>
  );
};

export default TermsOfService;
