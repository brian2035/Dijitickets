
import React, { useState, useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { 
  ArrowLeft, Wallet, Info, CheckCircle2, 
  Loader2, Smartphone, ShieldCheck, AlertCircle, TrendingUp
} from 'lucide-react';
import { authService } from '../services/authService';
import { eventService } from '../services/eventService';
import { formatCurrency } from '../constants';
import { User, Event } from '../types';

const WithdrawalRequest: React.FC = () => {
  const navigate = useNavigate();
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const [isProcessing, setIsProcessing] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  
  // Finance State
  const [totalRevenue, setTotalRevenue] = useState(0);
  const [commission, setCommission] = useState(0);
  const [availableBalance, setAvailableBalance] = useState(0);
  const [pendingBalance, setPendingBalance] = useState(0);

  useEffect(() => {
    // Fixed: Wrapped service call in an async function inside useEffect
    const fetchData = async () => {
      const currentUser = authService.getCurrentUser();
      if (!currentUser) {
        navigate('/login');
        return;
      }
      setUser(currentUser);

      const orgEvents = await eventService.getByOrganizer(currentUser.id);
      
      // Logic: 
      // Total Revenue is sum of all tickets sold.
      // Platform Commission is 5%.
      // Pending Balance is for events that haven't happened yet (let's simulate this).
      // Available Balance is revenue from completed events minus commission.
      
      let total = 0;
      let pending = 0;
      const now = new Date();

      orgEvents.forEach(ev => {
        const eventRevenue = ev.ticketTypes.reduce((sum, tt) => sum + (tt.sold * tt.price), 0);
        total += eventRevenue;
        
        const eventDate = new Date(ev.date);
        if (eventDate > now) {
          pending += eventRevenue;
        }
      });

      const totalCommission = total * 0.05;
      const netTotal = total - totalCommission;
      const netPending = pending * 0.95;
      const netAvailable = netTotal - netPending;

      setTotalRevenue(total);
      setCommission(totalCommission);
      setAvailableBalance(netAvailable);
      setPendingBalance(netPending);
      setLoading(false);
    };
    fetchData();
  }, [navigate]);

  const handleWithdraw = async () => {
    if (availableBalance <= 0) return;
    
    setIsProcessing(true);
    // Simulate API call to initiate M-Pesa B2C payout
    await new Promise(resolve => setTimeout(resolve, 2500));
    setIsProcessing(false);
    setIsSuccess(true);
  };

  if (loading) return null;

  return (
    <div className="max-w-4xl mx-auto px-4 py-8 md:py-16">
      <div className="mb-10 flex items-center gap-4">
        <button 
          onClick={() => navigate('/organizer')}
          className="p-2 bg-gray-100 hover:bg-gray-200 rounded-xl transition-all"
        >
          <ArrowLeft size={20} className="text-gray-600" />
        </button>
        <div>
          <h1 className="text-2xl md:text-4xl font-black text-gray-900 tracking-tight">Withdrawal Request</h1>
          <p className="text-gray-500 font-medium text-xs uppercase tracking-widest mt-1">Earnings & Payouts Console</p>
        </div>
      </div>

      {isSuccess ? (
        <div className="bg-white rounded-[3rem] border border-gray-100 shadow-2xl p-12 text-center animate-in zoom-in duration-500">
           <div className="bg-green-100 w-24 h-24 rounded-full flex items-center justify-center mx-auto mb-8">
              <CheckCircle2 size={48} className="text-green-600" />
           </div>
           <h2 className="text-3xl font-black text-gray-900 mb-4 tracking-tight">Withdrawal Initiated!</h2>
           <p className="text-gray-500 max-w-sm mx-auto font-medium leading-relaxed mb-10">
              Your payout of <span className="text-red-600 font-black">{formatCurrency(availableBalance)}</span> is being processed via M-Pesa. You will receive a confirmation SMS shortly.
           </p>
           <button 
             onClick={() => navigate('/organizer')}
             className="bg-gray-900 text-white px-10 py-4 rounded-2xl font-black text-sm uppercase tracking-widest hover:bg-black transition-all"
           >
             Return to Dashboard
           </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2 space-y-8">
            {/* Detailed Breakdown */}
            <div className="bg-white rounded-[2.5rem] border border-gray-100 shadow-sm overflow-hidden">
               <div className="p-8 border-b border-gray-50 flex items-center justify-between bg-gray-50/30">
                  <h3 className="font-black text-gray-900 uppercase tracking-widest text-xs flex items-center gap-2">
                    <TrendingUp size={16} className="text-red-600" /> Earnings Breakdown
                  </h3>
                  <span className="text-[10px] font-black text-gray-400 bg-white px-3 py-1 rounded-full border border-gray-100">Live Sync</span>
               </div>
               <div className="p-8 md:p-10 space-y-8">
                  <div className="flex justify-between items-end group">
                     <div>
                        <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1">Tickets Sold Revenue</p>
                        <p className="text-2xl md:text-3xl font-black text-gray-900">{formatCurrency(totalRevenue)}</p>
                     </div>
                     <span className="text-[10px] font-black text-green-600 bg-green-50 px-2 py-0.5 rounded opacity-0 group-hover:opacity-100 transition-opacity">Gross</span>
                  </div>

                  <div className="flex justify-between items-end group">
                     <div>
                        <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1">DijiTickets Commission (5%)</p>
                        <p className="text-xl md:text-2xl font-black text-red-600">-{formatCurrency(commission)}</p>
                     </div>
                     <span className="text-[10px] font-black text-gray-400 bg-gray-50 px-2 py-0.5 rounded opacity-0 group-hover:opacity-100 transition-opacity">Platform Fee</span>
                  </div>

                  <div className="pt-8 border-t border-gray-100 flex justify-between items-end">
                     <div>
                        <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1">Net Earnings</p>
                        <p className="text-3xl md:text-4xl font-black text-gray-900">{formatCurrency(totalRevenue - commission)}</p>
                     </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-8 pt-8 border-t border-gray-100">
                     <div className="p-6 bg-red-50/50 rounded-3xl border border-red-100/50">
                        <p className="text-[9px] font-black text-red-600 uppercase tracking-widest mb-1">Available for Withdrawal</p>
                        <p className="text-xl font-black text-gray-900">{formatCurrency(availableBalance)}</p>
                        <p className="text-[8px] text-gray-400 font-bold mt-2 leading-tight italic">Funds from completed events.</p>
                     </div>
                     <div className="p-6 bg-gray-50 rounded-3xl border border-gray-100">
                        <p className="text-[9px] font-black text-gray-400 uppercase tracking-widest mb-1">Pending Balance</p>
                        <p className="text-xl font-black text-gray-400">{formatCurrency(pendingBalance)}</p>
                        <p className="text-[8px] text-gray-400 font-bold mt-2 leading-tight italic">Locked until events are completed.</p>
                     </div>
                  </div>
               </div>
            </div>

            <div className="p-8 bg-amber-50 rounded-[2rem] border border-amber-100 flex gap-5">
               <Info className="text-amber-600 shrink-0 mt-1" size={24} />
               <div>
                  <h4 className="font-black text-amber-900 text-sm mb-1 uppercase tracking-tight">Security Hold Policy</h4>
                  <p className="text-amber-700/80 text-xs leading-relaxed font-medium">
                     For attendee protection, ticket revenue is released to your available balance <span className="font-black underline decoration-amber-300">24 hours after an event successfully concludes</span>. This prevents fraud and simplifies refund management if an event is canceled.
                  </p>
               </div>
            </div>
          </div>

          <div className="lg:col-span-1">
             <div className="bg-gray-900 text-white rounded-[2.5rem] p-8 md:p-10 shadow-2xl sticky top-24 overflow-hidden">
                <div className="relative z-10">
                   <div className="bg-red-600 w-14 h-14 rounded-2xl flex items-center justify-center mb-8 shadow-xl">
                      <Wallet size={28} className="text-white" />
                   </div>
                   <h3 className="text-2xl font-black mb-2 tracking-tight">Payout Method</h3>
                   <p className="text-gray-400 text-xs font-bold uppercase tracking-widest mb-8 flex items-center gap-2">
                     <Smartphone size={14} className="text-[#4CAF50]" /> M-Pesa B2C Transfer
                   </p>
                   
                   <div className="space-y-4 mb-10">
                      <div className="flex justify-between border-b border-white/10 pb-3">
                         <span className="text-[10px] font-black text-gray-500 uppercase tracking-widest">Phone</span>
                         <span className="font-bold text-white">0712 *** 343</span>
                      </div>
                      <div className="flex justify-between border-b border-white/10 pb-3">
                         <span className="text-[10px] font-black text-gray-500 uppercase tracking-widest">Processing Time</span>
                         <span className="font-bold text-white text-xs">Under 24 Hours</span>
                      </div>
                      <div className="flex justify-between">
                         <span className="text-[10px] font-black text-gray-500 uppercase tracking-widest">Withdrawal Amount</span>
                         <span className="font-black text-red-500 text-xl">{formatCurrency(availableBalance)}</span>
                      </div>
                   </div>

                   <button 
                     onClick={handleWithdraw}
                     disabled={availableBalance <= 0 || isProcessing}
                     className={`w-full py-5 rounded-2xl font-black text-sm uppercase tracking-widest transition-all flex items-center justify-center gap-3 active:scale-95 shadow-2xl ${
                        availableBalance <= 0 || isProcessing 
                          ? 'bg-white/5 text-white/20 cursor-not-allowed border border-white/10' 
                          : 'bg-red-600 text-white hover:bg-red-700 shadow-red-900/50'
                     }`}
                   >
                     {isProcessing ? (
                       <>
                         <Loader2 size={18} className="animate-spin" />
                         <span>Processing...</span>
                       </>
                     ) : (
                       <>
                         <ShieldCheck size={18} />
                         <span>Confirm Payout</span>
                       </>
                     )}
                   </button>
                   
                   {availableBalance <= 0 && (
                      <p className="mt-6 text-center text-[9px] font-black text-red-500 uppercase tracking-widest flex items-center justify-center gap-1.5 animate-pulse">
                        <AlertCircle size={10} /> Minimum KES 100 required
                      </p>
                   )}
                </div>
                
                {/* Decorative Pattern */}
                <div className="absolute top-0 right-0 w-32 h-32 bg-red-600/10 rounded-full blur-3xl pointer-events-none"></div>
                <div className="absolute bottom-0 left-0 w-48 h-48 bg-blue-600/5 rounded-full blur-[100px] pointer-events-none"></div>
             </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default WithdrawalRequest;
