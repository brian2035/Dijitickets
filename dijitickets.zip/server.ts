
import express from 'express';
import cors from 'cors';
import jwt from 'jsonwebtoken';
import { v4 as uuidv4 } from 'uuid';

const app = express();
const PORT = 3001;
const JWT_SECRET = 'dijitickets_master_secret_2026';

app.use(cors());
app.use(express.json());

// --- Mock Database (In production, replace with MongoDB/Prisma) ---
let data = {
  users: [
    { id: 'u1', name: 'Super Admin', email: 'admin@dijitickets.co.ke', role: 'admin', password: 'password123' },
    { id: 'u2', name: 'M-Pesa Events Ltd', email: 'events@mpesa.co.ke', role: 'organizer', password: 'password123' }
  ],
  events: [
    {
      id: 'e1',
      organizerId: 'u2',
      title: 'Nairobi Tech Week',
      description: 'The largest tech gathering in East Africa.',
      bannerImage: 'https://images.unsplash.com/photo-1540575861501-7ad058138a30?q=80&w=2070',
      date: '2026-05-15',
      time: '09:00',
      venue: 'Sarit Expo Centre, Nairobi',
      category: 'Conference',
      status: 'published',
      approvalStatus: 'approved',
      createdAt: new Date().toISOString(),
      ticketTypes: [
        { id: 'tt1', name: 'Standard', price: 1500, quantity: 500, sold: 120 },
        { id: 'tt2', name: 'VIP', price: 5000, quantity: 50, sold: 45 }
      ]
    }
  ],
  tickets: [],
  notifications: [],
  activityLogs: [],
  waitlist: []
};

// --- Middleware ---
const authenticateToken = (req: any, res: any, next: any) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];
  if (!token) return res.sendStatus(401);

  jwt.verify(token, JWT_SECRET, (err: any, user: any) => {
    if (err) return res.sendStatus(403);
    req.user = user;
    next();
  });
};

// --- Auth Routes ---
app.post('/api/auth/login', (req, res) => {
  const { email, password } = req.body;
  const user = data.users.find(u => u.email === email && u.password === password);
  if (!user) return res.status(401).json({ message: 'Invalid credentials' });

  const token = jwt.sign({ id: user.id, role: user.role }, JWT_SECRET, { expiresIn: '24h' });
  const { password: _, ...userPublic } = user;
  res.json({ user: userPublic, token });
});

app.post('/api/auth/signup', (req, res) => {
  const { name, email, password, role } = req.body;
  if (data.users.find(u => u.email === email)) return res.status(400).json({ message: 'Email already exists' });

  const newUser = { id: `u${Date.now()}`, name, email, password, role: role || 'organizer' };
  data.users.push(newUser as any);
  const token = jwt.sign({ id: newUser.id, role: newUser.role }, JWT_SECRET, { expiresIn: '24h' });
  const { password: _, ...userPublic } = newUser;
  res.json({ user: userPublic, token });
});

app.post('/api/auth/reset-password', (req, res) => {
  const { email } = req.body;
  const user = data.users.find(u => u.email === email);
  if (!user) return res.status(404).json({ message: 'User not found' });
  res.json({ message: 'Reset email sent' });
});

// --- Event Routes ---
app.get('/api/events', (req, res) => {
  res.json(data.events.filter(e => e.status === 'published' && e.approvalStatus === 'approved'));
});

app.get('/api/events/trending', (req, res) => {
  const published = data.events.filter(e => e.status === 'published' && e.approvalStatus === 'approved');
  
  const mostPopular = [...published].sort((a, b) => {
    const soldA = a.ticketTypes.reduce((sum, tt) => sum + tt.sold, 0);
    const soldB = b.ticketTypes.reduce((sum, tt) => sum + tt.sold, 0);
    return soldB - soldA;
  }).slice(0, 4);

  const fastSelling = [...published].sort((a, b) => {
    const getRatio = (ev: any) => {
      const sold = ev.ticketTypes.reduce((s: any, t: any) => s + t.sold, 0);
      const total = ev.ticketTypes.reduce((s: any, t: any) => s + t.quantity, 0);
      return total > 0 ? sold / total : 0;
    };
    return getRatio(b) - getRatio(a);
  }).slice(0, 4);

  const categoryStats: Record<string, number> = {};
  published.forEach(ev => {
    const sold = ev.ticketTypes.reduce((s, t) => s + t.sold, 0);
    categoryStats[ev.category] = (categoryStats[ev.category] || 0) + sold;
  });

  const topCategories = Object.entries(categoryStats)
    .sort(([, a], [, b]) => b - a)
    .slice(0, 4)
    .map(([name]) => name);

  res.json({ mostPopular, fastSelling, topCategories });
});

app.get('/api/events/organizer/:id', authenticateToken, (req, res) => {
  res.json(data.events.filter(e => e.organizerId === req.params.id));
});

app.get('/api/events/admin', authenticateToken, (req, res) => {
  if (req.user.role !== 'admin') return res.sendStatus(403);
  res.json(data.events);
});

app.get('/api/events/:id', (req, res) => {
  const event = data.events.find(e => e.id === req.params.id);
  if (!event) return res.sendStatus(404);
  res.json(event);
});

app.post('/api/events', authenticateToken, (req, res) => {
  const newEvent = { 
    ...req.body, 
    id: `e${Date.now()}`, 
    organizerId: req.user.id, 
    approvalStatus: 'approved',
    status: 'published',
    createdAt: new Date().toISOString() 
  };
  data.events.push(newEvent as any);
  res.json(newEvent);
});

app.put('/api/events/:id', authenticateToken, (req, res) => {
  const index = data.events.findIndex(e => e.id === req.params.id);
  if (index === -1) return res.sendStatus(404);
  
  const updatedEvent = { ...data.events[index], ...req.body };
  data.events[index] = updatedEvent;
  res.json(updatedEvent);
});

app.delete('/api/events/:id', authenticateToken, (req, res) => {
  data.events = data.events.filter(e => e.id !== req.params.id);
  res.sendStatus(204);
});

app.post('/api/events/:id/waitlist', (req, res) => {
  const { ticketTypeId, email, userId } = req.body;
  data.waitlist.push({ eventId: req.params.id, ticketTypeId, email, userId, id: `w${Date.now()}`, createdAt: new Date().toISOString() } as any);
  res.sendStatus(201);
});

app.post('/api/events/:id/approve', authenticateToken, (req, res) => {
  if (req.user.role !== 'admin') return res.sendStatus(403);
  const { status, reason } = req.body;
  const event = data.events.find(e => e.id === req.params.id);
  if (event) {
    event.approvalStatus = status;
    if (reason) (event as any).rejectionReason = reason;
  }
  res.sendStatus(200);
});

app.patch('/api/events/:id/status', authenticateToken, (req, res) => {
  const { status } = req.body;
  const event = data.events.find(e => e.id === req.params.id);
  if (event) event.status = status;
  res.sendStatus(200);
});

app.delete('/api/events/purge', authenticateToken, (req, res) => {
  if (req.user.role !== 'admin') return res.sendStatus(403);
  data.events = [];
  data.tickets = [];
  data.waitlist = [];
  res.sendStatus(204);
});

// --- M-Pesa Integration ---
app.post('/api/payments/stk-push', async (req, res) => {
  const { phone, amount, eventId, ticketTypeId, userId, guestInfo } = req.body;
  
  console.log(`[REAL BACKEND] Initiating STK Push for ${phone} - KES ${amount}`);
  
  // Simulation of async M-Pesa processing
  setTimeout(() => {
    const event = data.events.find(e => e.id === eventId);
    if (event) {
      const tt = event.ticketTypes.find((t: any) => t.id === ticketTypeId);
      if (tt && tt.sold < tt.quantity) {
        tt.sold += 1;
        
        const newTicket = {
          id: `tix-${Date.now()}`,
          eventId,
          buyerId: userId || `guest-${Date.now()}`,
          ticketTypeId,
          purchaseDate: new Date().toISOString(),
          qrCode: `DIJI-${Date.now()}-${userId || 'guest'}`,
          price: amount,
          status: 'valid'
        };
        data.tickets.push(newTicket as any);
        res.json({ success: true, ticket: newTicket });
      } else {
        res.status(400).json({ message: 'Ticket type sold out' });
      }
    } else {
      res.status(404).json({ message: 'Event not found' });
    }
  }, 1000);
});

app.listen(PORT, () => {
  console.log(`Backend server running at http://localhost:${PORT}`);
});
