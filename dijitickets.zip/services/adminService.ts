
import { DB } from '../db';
import { AdminActivity, User, Ticket, UserRole } from '../types';
import { authService } from './authService';

export const adminService = {
  logActivity: (action: string, targetId: string, targetType: AdminActivity['targetType'], status: AdminActivity['status'] = 'success') => {
    const admin = authService.getCurrentUser();
    if (!admin || admin.role !== UserRole.ADMIN) return;

    const logs = DB.getActivityLogs();
    
    // Attempt to make targetId more descriptive if possible
    let descriptiveTarget = targetId;
    if (targetType === 'event') {
      const ev = DB.getEvents().find(e => e.id === targetId);
      if (ev) descriptiveTarget = `${ev.title} (${targetId})`;
    } else if (targetType === 'user') {
      const u = DB.getUsers().find(u => u.id === targetId);
      if (u) descriptiveTarget = `${u.email} (${targetId})`;
    }

    const newLog: AdminActivity = {
      id: `log-${Date.now()}`,
      adminId: admin.id,
      adminName: admin.name,
      action: action.toUpperCase(),
      targetId: descriptiveTarget,
      targetType,
      timestamp: new Date().toISOString(),
      status
    };
    
    logs.unshift(newLog);
    DB.saveActivityLogs(logs.slice(0, 1000)); // Increased log buffer to 1000 entries
  },

  getLogs: () => DB.getActivityLogs(),

  verifyTicketAtGate: (ticketCode: string): { success: boolean, message: string, ticket?: Ticket } => {
    const tickets = DB.getTickets();
    const ticket = tickets.find(t => t.qrCode === ticketCode || t.id === ticketCode);

    if (!ticket) {
      return { success: false, message: "Ticket signature mismatch. Access denied." };
    }

    if (ticket.status === 'used') {
      return { success: false, message: "Entry duplicate detected. Ticket already scanned.", ticket };
    }

    if (ticket.status === 'refunded') {
      return { success: false, message: "Ticket void. Refund was processed.", ticket };
    }

    // Mark as used
    const updatedTickets = tickets.map(t => 
      t.id === ticket.id ? { ...t, status: 'used' as const } : t
    );
    DB.saveTickets(updatedTickets);

    adminService.logActivity('GATE_ACCESS_GRANTED', ticket.id, 'ticket');

    return { success: true, message: "Access Authorized. Welcome.", ticket: { ...ticket, status: 'used' } };
  }
};
