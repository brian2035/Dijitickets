
import { GoogleGenAI, Type } from "@google/genai";
import { CATEGORIES } from "../constants";

export const aiService = {
  /**
   * Generates a professional event description and suggested ticket tiers
   */
  generateDraft: async (title: string, category: string) => {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    
    const prompt = `You are a professional event organizer in Kenya. 
    Draft a compelling, high-conversion event description for an event titled "${title}" in the category "${category}". 
    The tone should be energetic and professional. Include why people should attend and what to expect.
    
    Also, suggest 3 ticket tiers (names like 'Early Bird', 'VIP', 'General') with prices in KES that are realistic for the Nairobi/Kenyan market.
    Return the result as JSON.`;

    try {
      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: prompt,
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              description: { type: Type.STRING },
              ticketTiers: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    name: { type: Type.STRING },
                    price: { type: Type.NUMBER },
                    quantity: { type: Type.NUMBER }
                  },
                  required: ["name", "price", "quantity"]
                }
              }
            },
            required: ["description", "ticketTiers"]
          }
        }
      });

      const text = response.text;
      return JSON.parse(text);
    } catch (error) {
      console.error("AI Generation failed:", error);
      throw error;
    }
  }
};
