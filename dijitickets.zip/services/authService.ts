
import { User, UserRole } from '../types';

const SESSION_KEY = 'dijitickets_session';
const TOKEN_KEY = 'dijitickets_token';
const API_BASE = '/api'; // In real prod, this would be your API URL

export const authService = {
  login: async (email: string, password?: string): Promise<User | null> => {
    try {
      const response = await fetch(`${API_BASE}/auth/login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password })
      });
      
      if (!response.ok) return null;
      
      const { user, token } = await response.json();
      localStorage.setItem(TOKEN_KEY, token);
      localStorage.setItem(SESSION_KEY, JSON.stringify(user));
      return user;
    } catch (err) {
      console.error('Login failed:', err);
      return null;
    }
  },
  
  signup: async (name: string, email: string, password?: string): Promise<User | null> => {
    try {
      const response = await fetch(`${API_BASE}/auth/signup`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, email, password })
      });
      
      if (!response.ok) return null;
      
      const { user, token } = await response.json();
      localStorage.setItem(TOKEN_KEY, token);
      localStorage.setItem(SESSION_KEY, JSON.stringify(user));
      return user;
    } catch (err) {
      console.error('Signup failed:', err);
      return null;
    }
  },

  resetPassword: async (email: string): Promise<boolean> => {
    try {
      const response = await fetch(`${API_BASE}/auth/reset-password`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email })
      });
      return response.ok;
    } catch (err) {
      console.error('Password reset failed:', err);
      return false;
    }
  },

  getCurrentUser: (): User | null => {
    const session = localStorage.getItem(SESSION_KEY);
    if (!session) return null;
    return JSON.parse(session);
  },

  getToken: () => localStorage.getItem(TOKEN_KEY),

  logout: () => {
    localStorage.removeItem(SESSION_KEY);
    localStorage.removeItem(TOKEN_KEY);
  }
};
