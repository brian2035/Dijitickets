
import { Event, TicketType } from '../types';
import { authService } from './authService';

const API_BASE = '/api';

export const eventService = {
  getAll: async (): Promise<Event[]> => {
    try {
      const response = await fetch(`${API_BASE}/events`);
      if (!response.ok) return [];
      return response.json();
    } catch (err) {
      console.error("Fetch events failed:", err);
      return [];
    }
  },
  
  getById: async (id: string): Promise<Event | null> => {
    try {
      const response = await fetch(`${API_BASE}/events/${id}`);
      if (!response.ok) return null;
      return response.json();
    } catch (err) {
      return null;
    }
  },
  
  create: async (eventData: Partial<Event>) => {
    const token = authService.getToken();
    const response = await fetch(`${API_BASE}/events`, {
      method: 'POST',
      headers: { 
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      },
      body: JSON.stringify(eventData)
    });
    return response.json();
  },

  update: async (eventId: string, eventData: Partial<Event>) => {
    const token = authService.getToken();
    const response = await fetch(`${API_BASE}/events/${eventId}`, {
      method: 'PUT',
      headers: { 
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      },
      body: JSON.stringify(eventData)
    });
    return response.json();
  },

  delete: async (eventId: string) => {
    const token = authService.getToken();
    await fetch(`${API_BASE}/events/${eventId}`, {
      method: 'DELETE',
      headers: { 'Authorization': `Bearer ${token}` }
    });
  },

  getTrending: async (): Promise<{ mostPopular: Event[], fastSelling: Event[], topCategories: string[] }> => {
    try {
      const response = await fetch(`${API_BASE}/events/trending`);
      if (!response.ok) return { mostPopular: [], fastSelling: [], topCategories: [] };
      return response.json();
    } catch (err) {
      return { mostPopular: [], fastSelling: [], topCategories: [] };
    }
  },

  getByOrganizer: async (organizerId: string): Promise<Event[]> => {
    try {
      const token = authService.getToken();
      const response = await fetch(`${API_BASE}/events/organizer/${organizerId}`, {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      if (!response.ok) return [];
      return response.json();
    } catch (err) {
      return [];
    }
  },

  subscribeToWaitlist: async (eventId: string, ticketTypeId: string, email: string, userId?: string): Promise<boolean> => {
    try {
      const response = await fetch(`${API_BASE}/events/${eventId}/waitlist`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ticketTypeId, email, userId })
      });
      return response.ok;
    } catch (err) {
      return false;
    }
  },

  getAllForAdmin: async (): Promise<Event[]> => {
    try {
      const token = authService.getToken();
      const response = await fetch(`${API_BASE}/events/admin`, {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      if (!response.ok) return [];
      return response.json();
    } catch (err) {
      return [];
    }
  },

  approveEvent: async (id: string, status: string, reason?: string): Promise<void> => {
    const token = authService.getToken();
    await fetch(`${API_BASE}/events/${id}/approve`, {
      method: 'POST',
      headers: { 
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      },
      body: JSON.stringify({ status, reason })
    });
  },

  updateStatus: async (id: string, status: string): Promise<void> => {
    const token = authService.getToken();
    await fetch(`${API_BASE}/events/${id}/status`, {
      method: 'PATCH',
      headers: { 
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      },
      body: JSON.stringify({ status })
    });
  },

  purgeAll: async (): Promise<void> => {
    const token = authService.getToken();
    await fetch(`${API_BASE}/events/purge`, {
      method: 'DELETE',
      headers: { 'Authorization': `Bearer ${token}` }
    });
  }
};
