
import { GoogleGenAI } from "@google/genai";

export const mapService = {
  searchLocation: async (query: string) => {
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      
      // Get current location for better grounding context if available
      let latLng = undefined;
      try {
        const position = await new Promise<GeolocationPosition>((resolve, reject) => {
          navigator.geolocation.getCurrentPosition(resolve, reject, { timeout: 5000 });
        });
        latLng = {
          latitude: position.coords.latitude,
          longitude: position.coords.longitude
        };
      } catch (e) {
        console.debug("Geolocation not available or denied, proceeding without it.");
      }

      const response = await ai.models.generateContent({
        model: "gemini-2.5-flash",
        contents: `Find the official name and precise address for this event venue in Kenya: ${query}. 
                   If there are multiple similar locations, list the most prominent ones. 
                   Format each as: Name | Address.`,
        config: {
          tools: [{ googleMaps: {} }],
          toolConfig: {
            retrievalConfig: {
              latLng: latLng
            }
          }
        },
      });

      return {
        text: response.text,
        groundingChunks: response.candidates?.[0]?.groundingMetadata?.groundingChunks || []
      };
    } catch (error) {
      console.error("Map search failed:", error);
      throw error;
    }
  }
};
