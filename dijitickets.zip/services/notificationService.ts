
import { DB } from '../db';
import { Notification, UserRole } from '../types';

export const notificationService = {
  getByUser: (userId: string) => {
    return DB.getNotifications()
      .filter(n => n.userId === userId)
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  },

  create: (userId: string, title: string, message: string, type: Notification['type'] = 'info', link?: string) => {
    const notifications = DB.getNotifications();
    const newNotification: Notification = {
      id: `n${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      userId,
      title,
      message,
      type,
      isRead: false,
      createdAt: new Date().toISOString(),
      link
    };
    notifications.push(newNotification);
    DB.saveNotifications(notifications);
    return newNotification;
  },

  markAsRead: (notificationId: string) => {
    const notifications = DB.getNotifications();
    const index = notifications.findIndex(n => n.id === notificationId);
    if (index !== -1) {
      notifications[index].isRead = true;
      DB.saveNotifications(notifications);
    }
  },

  markAllAsRead: (userId: string) => {
    const notifications = DB.getNotifications();
    const updated = notifications.map(n => n.userId === userId ? { ...n, isRead: true } : n);
    DB.saveNotifications(updated);
  },

  clearAll: (userId: string) => {
    const notifications = DB.getNotifications();
    const filtered = notifications.filter(n => n.userId !== userId);
    DB.saveNotifications(filtered);
  }
};
