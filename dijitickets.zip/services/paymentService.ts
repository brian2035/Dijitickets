
import { Ticket } from '../types';
import { authService } from './authService';

const API_BASE = '/api';

export const paymentService = {
  buyTicket: async (
    userId: string | null, 
    eventId: string, 
    ticketTypeId: string, 
    guestInfo: { name: string, email: string } | undefined,
    phone: string,
    amount: number
  ): Promise<Ticket | null> => {
    try {
      const token = authService.getToken();
      const response = await fetch(`${API_BASE}/payments/stk-push`, {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
          'Authorization': token ? `Bearer ${token}` : ''
        },
        body: JSON.stringify({ 
          phone, 
          amount, 
          eventId, 
          ticketTypeId, 
          userId, 
          guestInfo 
        })
      });

      if (!response.ok) return null;
      
      const result = await response.json();
      return result.ticket;
    } catch (err) {
      console.error('Payment processing failed:', err);
      return null;
    }
  }
};
