
export enum UserRole {
  ATTENDEE = 'attendee',
  ORGANIZER = 'organizer',
  ADMIN = 'admin'
}

export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  phone?: string;
  sessionStart?: string;
}

export interface TicketType {
  id: string;
  name: string;
  price: number;
  quantity: number;
  sold: number;
}

export interface Event {
  id: string;
  organizerId: string;
  title: string;
  description: string;
  bannerImage: string;
  date: string;
  time: string;
  venue: string;
  category: string;
  status: 'published' | 'draft' | 'cancelled';
  approvalStatus: 'pending' | 'approved' | 'rejected';
  rejectionReason?: string;
  ticketTypes: TicketType[];
  createdAt: string;
  facebookLink?: string;
  twitterLink?: string;
  instagramLink?: string;
}

export interface Ticket {
  id: string;
  eventId: string;
  buyerId: string;
  ticketTypeId: string;
  purchaseDate: string;
  qrCode: string;
  price: number;
  status: 'valid' | 'used' | 'refunded';
}

export interface WaitlistEntry {
  id: string;
  eventId: string;
  ticketTypeId: string;
  userId?: string;
  email: string;
  createdAt: string;
}

export interface Notification {
  id: string;
  userId: string;
  title: string;
  message: string;
  type: 'success' | 'info' | 'warning' | 'error';
  isRead: boolean;
  createdAt: string;
  link?: string;
}

export interface AdminActivity {
  id: string;
  adminId: string;
  adminName: string;
  action: string;
  targetId: string;
  targetType: 'event' | 'ticket' | 'user' | 'system';
  timestamp: string;
  status: 'success' | 'warning' | 'error';
}

export interface DashboardStats {
  totalRevenue: number;
  ticketsSold: number;
  activeEvents: number;
  averageTicketPrice?: number;
}
